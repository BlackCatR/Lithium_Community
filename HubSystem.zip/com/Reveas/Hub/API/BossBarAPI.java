package com.Reveas.Hub.API;

import org.bukkit.scheduler.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import java.util.*;

public class BossBarAPI extends BukkitRunnable
{
    public void run() {
        for (final Player all : Bukkit.getOnlinePlayers()) {
            org.inventivetalent.bossbar.BossBarAPI.getBossBar(all);
            org.inventivetalent.bossbar.BossBarAPI.setMessage(all, Main.F("&e&lReveas&6&lMC &7Network &8� &b&lNEW &eSurvivalGames !"));
        }
    }
}
