package com.Reveas.Hub.API;

import com.Reveas.Hub.Main.*;
import org.bukkit.configuration.file.*;
import java.io.*;

public class FileManager
{
    public static File WarpFile;
    public static FileConfiguration WarpConfig;
    public static File MySQLFile;
    public static FileConfiguration MySQLConfiguration;
    
    static {
        FileManager.WarpFile = new File(Main.getInstance().getDataFolder(), "Warp.yml");
        FileManager.WarpConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(FileManager.WarpFile);
        FileManager.MySQLFile = new File(Main.getInstance().getDataFolder(), "MySQL.yml");
        FileManager.MySQLConfiguration = (FileConfiguration)YamlConfiguration.loadConfiguration(FileManager.MySQLFile);
    }
    
    public static void createMySQLConfig() {
        try {
            if (Main.getInstance().getDataFolder().exists()) {
                if (!FileManager.MySQLFile.exists()) {
                    FileManager.MySQLFile.createNewFile();
                    FileManager.MySQLConfiguration.set("MySQL.Host", (Object)"Hostname");
                    FileManager.MySQLConfiguration.set("MySQL.Port", (Object)3306);
                    FileManager.MySQLConfiguration.set("MySQL.User", (Object)"Username");
                    FileManager.MySQLConfiguration.set("MySQL.Password", (Object)"Password");
                    FileManager.MySQLConfiguration.set("MySQL.DataBase", (Object)"DataBase");
                    FileManager.MySQLConfiguration.save(FileManager.MySQLFile);
                }
            }
            else {
                Main.getInstance().getDataFolder().mkdir();
                FileManager.MySQLFile.createNewFile();
                FileManager.MySQLConfiguration.set("MySQL.Host", (Object)"Hostname");
                FileManager.MySQLConfiguration.set("MySQL.Port", (Object)3306);
                FileManager.MySQLConfiguration.set("MySQL.User", (Object)"Username");
                FileManager.MySQLConfiguration.set("MySQL.Password", (Object)"Password");
                FileManager.MySQLConfiguration.set("MySQL.DataBase", (Object)"DataBase");
                FileManager.MySQLConfiguration.save(FileManager.MySQLFile);
            }
        }
        catch (IOException ex) {}
    }
    
    public static void createWarpConfig() {
        try {
            if (Main.getInstance().getDataFolder().exists()) {
                FileManager.WarpFile.createNewFile();
            }
            else if (!Main.getInstance().getDataFolder().exists()) {
                Main.getInstance().getDataFolder().mkdir();
                FileManager.WarpFile.createNewFile();
            }
        }
        catch (IOException ex) {}
    }
    
    public static void saveWarpConfig() {
        try {
            FileManager.WarpConfig.save(FileManager.WarpFile);
        }
        catch (IOException ex) {}
    }
}
