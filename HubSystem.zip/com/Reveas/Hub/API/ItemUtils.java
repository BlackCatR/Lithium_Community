package com.Reveas.Hub.API;

import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;

public class ItemUtils
{
    public static ItemStack getItem(final Material material, final String name, final String lore, final int damage, final int amount) {
        final ItemStack itemstack = new ItemStack(material, amount, (short)damage);
        final ItemMeta meta = itemstack.getItemMeta();
        if (lore != null) {
            if (lore.contains("\n")) {
                final ArrayList<String> lorelist = new ArrayList<String>();
                final String[] split;
                final String[] loresplit = split = lore.split("\n");
                String[] array;
                for (int length = (array = split).length, i = 0; i < length; ++i) {
                    final String text = array[i];
                    lorelist.add(text);
                }
                meta.setLore((List)lorelist);
            }
            else {
                meta.setLore((List)Arrays.asList(lore));
            }
        }
        meta.setDisplayName(name);
        itemstack.setItemMeta(meta);
        return itemstack;
    }
    
    public static ItemStack createSkull(final Material Material, final int Amount, final String Playername, final String Displayname) {
        final ItemStack I = new ItemStack(Material, Amount, (short)3);
        final SkullMeta Im = (SkullMeta)I.getItemMeta();
        Im.setDisplayName(Displayname);
        Im.setOwner(Playername);
        I.setItemMeta((ItemMeta)Im);
        return I;
    }
    
    public static ItemStack getItemWithID(final Integer ID, final String name, final String lore, final int damage, final int amount) {
        final ItemStack itemstack = new ItemStack(Material.getMaterial((int)ID), amount, (short)damage);
        final ItemMeta meta = itemstack.getItemMeta();
        if (lore != null) {
            if (lore.contains("\n")) {
                final ArrayList<String> lorelist = new ArrayList<String>();
                final String[] split;
                final String[] loresplit = split = lore.split("\n");
                String[] array;
                for (int length = (array = split).length, i = 0; i < length; ++i) {
                    final String text = array[i];
                    lorelist.add(text);
                }
                meta.setLore((List)lorelist);
            }
            else {
                meta.setLore((List)Arrays.asList(lore));
            }
        }
        meta.setDisplayName(name);
        itemstack.setItemMeta(meta);
        return itemstack;
    }
}
