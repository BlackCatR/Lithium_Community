package com.Reveas.Hub.API;

import org.bukkit.configuration.file.*;
import org.bukkit.entity.*;
import java.io.*;
import org.bukkit.*;

public class LocationAPI
{
    public static File ConfigFile;
    public static FileConfiguration Config;
    
    static {
        try {
            LocationAPI.ConfigFile = new File("plugins/ReveasSystem", "Location.yml");
            LocationAPI.Config = (FileConfiguration)YamlConfiguration.loadConfiguration(LocationAPI.ConfigFile);
        }
        catch (Exception ex) {}
    }
    
    public static void setLoc(final String Location, final Player p) {
        LocationAPI.Config.set("Spanws." + Location + ".x", (Object)p.getLocation().getX());
        LocationAPI.Config.set("Spanws." + Location + ".y", (Object)p.getLocation().getY());
        LocationAPI.Config.set("Spanws." + Location + ".z", (Object)p.getLocation().getZ());
        LocationAPI.Config.set("Spanws." + Location + ".yaw", (Object)p.getLocation().getYaw());
        LocationAPI.Config.set("Spanws." + Location + ".pitch", (Object)p.getLocation().getPitch());
        LocationAPI.Config.set("Spanws." + Location + ".world", (Object)p.getWorld().getName());
        try {
            LocationAPI.Config.save(LocationAPI.ConfigFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void World(final String Location, final Player p) {
        LocationAPI.Config.set("Spanws." + Location + ".x", (Object)p.getLocation().getX());
        LocationAPI.Config.set("Spanws." + Location + ".y", (Object)p.getLocation().getY());
        LocationAPI.Config.set("Spanws." + Location + ".z", (Object)p.getLocation().getZ());
        LocationAPI.Config.set("Spanws." + Location + ".yaw", (Object)p.getLocation().getYaw());
        LocationAPI.Config.set("Spanws." + Location + ".pitch", (Object)p.getLocation().getPitch());
        LocationAPI.Config.set("Spanws." + Location + ".world", (Object)p.getWorld().getName());
        try {
            LocationAPI.Config.save(LocationAPI.ConfigFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void setLocKit(final String Location, final Player p) {
        LocationAPI.Config.set("Spanws." + Location + ".y", (Object)p.getLocation().getY());
        try {
            LocationAPI.Config.save(LocationAPI.ConfigFile);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static Location getLoc(final String Location) {
        final double x = LocationAPI.Config.getDouble("Spanws." + Location + ".x");
        final double y = LocationAPI.Config.getDouble("Spanws." + Location + ".y");
        final double z = LocationAPI.Config.getDouble("Spanws." + Location + ".z");
        final double yaw = LocationAPI.Config.getDouble("Spanws." + Location + ".yaw");
        final double pitch = LocationAPI.Config.getDouble("Spanws." + Location + ".pitch");
        final String world = LocationAPI.Config.getString("Spanws." + Location + ".world");
        final World w = Bukkit.getWorld(world);
        final Location l = new Location(w, x, y, z, (float)yaw, (float)pitch);
        return l;
    }
}
