package com.Reveas.Hub.API;

public enum Rank
{
    UnRanked("UnRanked", 0, "UnRanked", 0, "UnRanked", 0, "�eUnRanked", 5000), 
    SilverI("SilverI", 1, "Silver I", 1, "Silver I", 1, "�7Silver I", 5000), 
    SilverII("SilverII", 2, "Silver II", 2, "Silver II", 2, "�7Silver II", 7000), 
    SilverIII("SilverIII", 3, "Silver III", 3, "Silver III", 3, "�7Silver III", 10000), 
    SilverIV("SilverIV", 4, "Silver IV", 4, "Silver IV", 4, "�7Silver IV", 14000), 
    SilverV("SilverV", 5, "Silver IV", 5, "Silver IV", 5, "�7Silver V", 19000), 
    GoldI("GoldI", 6, "Gold I", 6, "Gold I", 6, "�6Gold I", 25000), 
    GoldII("GoldII", 7, "Gold II", 7, "Gold II", 7, "�6Gold II", 27000), 
    GoldIII("GoldIII", 8, "Gold III", 8, "Gold III", 8, "�6Gold III", 30000), 
    GoldIV("GoldIV", 9, "Gold IV", 9, "Gold IV", 9, "�6Gold IV", 34000), 
    GoldV("GoldV", 10, "Gold V", 10, "Gold V", 10, "�6Gold V", 39000), 
    DiamondI("DiamondI", 11, "Diamond I", 11, "Diamond I", 11, "�bDiamond I", 45000), 
    DiamondII("DiamondII", 12, "Diamond II", 12, "Diamond II", 12, "�bDiamond II", 47000), 
    DiamondIII("DiamondIII", 13, "Diamond III", 13, "Diamond III", 13, "�bDiamond III", 50000), 
    DiamondIV("DiamondIV", 14, "Diamond IV", 14, "Diamond IV", 14, "�bDiamond IV", 54000), 
    DiamondV("DiamondV", 15, "Diamond V", 15, "Diamond V", 15, "�bDiamond V", 59000), 
    EmeraldI("EmeraldI", 16, "Emerald I", 16, "Emerald I", 16, "�aEmerald I", 65000), 
    EmeraldII("EmeraldII", 17, "Emerald II", 17, "Emerald II", 17, "�aEmerald II", 67000), 
    EmeraldIII("EmeraldIII", 18, "Emerald III", 18, "Emerald III", 18, "�aEmerald III", 70000), 
    EmeraldIV("EmeraldIV", 19, "Emerald IV", 19, "Emerald IV", 19, "�aEmerald IV", 74000), 
    EmeraldV("EmeraldV", 20, "Emerald V", 20, "Emerald V", 20, "�aEmerald V", 79000), 
    Legendary("Legendary", 21, "Legendary", 21, "Legendary", 21, "�5Legendary", 85000);
    
    private String name;
    private int Points;
    
    private Rank(final String s3, final int n3, final String s2, final int n2, final String s, final int n, final String name, final int Points) {
        this.name = name;
        this.Points = Points;
    }
    
    public String getName() {
        return this.name;
    }
    
    public static Rank getPRank(final int i) {
        Rank rank = null;
        if (i < 5000) {
            rank = Rank.UnRanked;
        }
        if (i == 5000 || (i > 5000 && i < 7000)) {
            rank = Rank.SilverI;
        }
        if (i == 7000 || (i > 7000 && i < 10000)) {
            rank = Rank.SilverII;
        }
        if (i == 10000 || (i > 10000 && i < 14000)) {
            rank = Rank.SilverIII;
        }
        if (i == 14000 || (i > 14000 && i < 19000)) {
            rank = Rank.SilverIV;
        }
        if (i == 19000 || (i > 19000 && i < 25000)) {
            rank = Rank.SilverV;
        }
        if (i == 25000 || (i > 25000 && i < 27000)) {
            rank = Rank.GoldI;
        }
        if (i == 27000 || (i > 27000 && i < 29000)) {
            rank = Rank.GoldII;
        }
        if (i == 29000 || (i > 29000 && i < 34000)) {
            rank = Rank.GoldIII;
        }
        if (i == 34000 || (i > 34000 && i < 39000)) {
            rank = Rank.GoldIV;
        }
        if (i == 39000 || (i > 39000 && i < 45000)) {
            rank = Rank.GoldV;
        }
        if (i == 45000 || (i > 45000 && i < 47000)) {
            rank = Rank.DiamondI;
        }
        if (i == 47000 || (i > 47000 && i < 50000)) {
            rank = Rank.DiamondII;
        }
        if (i == 50000 || (i > 50000 && i < 54000)) {
            rank = Rank.DiamondIII;
        }
        if (i == 54000 || (i > 54000 && i < 59000)) {
            rank = Rank.DiamondIV;
        }
        if (i == 59000 || (i > 59000 && i < 65000)) {
            rank = Rank.DiamondV;
        }
        if (i == 65000 || (i > 65000 && i < 67000)) {
            rank = Rank.EmeraldI;
        }
        if (i == 67000 || (i > 67000 && i < 70000)) {
            rank = Rank.EmeraldII;
        }
        if (i == 70000 || (i > 70000 && i < 74000)) {
            rank = Rank.EmeraldIII;
        }
        if (i == 74000 || (i > 74000 && i < 79000)) {
            rank = Rank.EmeraldIV;
        }
        if (i == 79000 || (i > 79000 && i < 85000)) {
            rank = Rank.EmeraldV;
        }
        if (i == 85000 || i > 85000) {
            rank = Rank.Legendary;
        }
        return rank;
    }
    
    public static Rank getNextRank(final Rank r) {
        Rank rank = null;
        switch (r) {
            case UnRanked: {
                rank = Rank.SilverI;
                break;
            }
            case SilverI: {
                rank = Rank.SilverII;
                break;
            }
            case SilverII: {
                rank = Rank.SilverIII;
                break;
            }
            case SilverIII: {
                rank = Rank.SilverIV;
                break;
            }
            case SilverIV: {
                rank = Rank.SilverV;
                break;
            }
            case SilverV: {
                rank = Rank.GoldI;
                break;
            }
            case GoldI: {
                rank = Rank.GoldII;
                break;
            }
            case GoldII: {
                rank = Rank.GoldIII;
                break;
            }
            case GoldIII: {
                rank = Rank.GoldIV;
                break;
            }
            case GoldIV: {
                rank = Rank.GoldV;
                break;
            }
            case GoldV: {
                rank = Rank.DiamondI;
                break;
            }
            case DiamondI: {
                rank = Rank.DiamondII;
                break;
            }
            case DiamondII: {
                rank = Rank.DiamondIII;
                break;
            }
            case DiamondIII: {
                rank = Rank.DiamondIV;
                break;
            }
            case DiamondIV: {
                rank = Rank.DiamondV;
                break;
            }
            case DiamondV: {
                rank = Rank.EmeraldI;
                break;
            }
            case EmeraldI: {
                rank = Rank.EmeraldII;
                break;
            }
            case EmeraldII: {
                rank = Rank.EmeraldIII;
                break;
            }
            case EmeraldIII: {
                rank = Rank.EmeraldIV;
                break;
            }
            case EmeraldIV: {
                rank = Rank.EmeraldV;
                break;
            }
            case EmeraldV: {
                rank = Rank.Legendary;
                break;
            }
            case Legendary: {
                rank = Rank.Legendary;
                break;
            }
        }
        return rank;
    }
    
    public int getRankKills() {
        return this.Points;
    }
}
