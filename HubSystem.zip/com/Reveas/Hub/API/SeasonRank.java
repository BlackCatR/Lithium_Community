package com.Reveas.Hub.API;

public enum SeasonRank
{
    Stray("Stray", 0, "Stray", 0, "Stray", 0, "�7Stray", 0), 
    Wanderer("Wanderer", 1, "Wanderer", 1, "Wanderer", 1, "�dWanderer", 5), 
    Defender("Defender", 2, "Defender", 2, "Defender", 2, "�aDefender", 20), 
    Solider("Solider", 3, "Solider", 3, "Solider", 3, "�3Solider", 50), 
    Champion("Champion", 4, "Champion", 4, "Champion", 4, "�c�lChampion", 100), 
    Sargeant("Sargeant", 5, "Sargeant", 5, "Sargeant", 5, "�4�lSargeant", 150), 
    WarHero("WarHero", 6, "WarHero", 6, "War Hero", 6, "�6�lWar Hero", 200), 
    Veteran("Veteran", 7, "Veteran", 7, "Veteran", 7, "�d�lVeteran", 300), 
    Guardian("Guardian", 8, "Guardian", 8, "Guardian", 8, "�kx �5�lGuardian", 500), 
    Reveaser("Reveaser", 9, "Reveaser", 9, "Reveaser", 9, "�kx �e�lReveaser �kx", 1000);
    
    private String name;
    private int wins;
    
    private SeasonRank(final String s3, final int n3, final String s2, final int n2, final String s, final int n, final String name, final int wins) {
        this.name = name;
        this.wins = wins;
    }
    
    public String getName() {
        return this.name;
    }
    
    public static SeasonRank getByWins(final int i) {
        SeasonRank rank = null;
        if (i < 5) {
            rank = SeasonRank.Stray;
        }
        if (i == 5 || (i > 5 && i < 10)) {
            rank = SeasonRank.Wanderer;
        }
        if (i == 10 || (i > 10 && i < 30)) {
            rank = SeasonRank.Defender;
        }
        if (i == 30 || (i > 30 && i < 50)) {
            rank = SeasonRank.Solider;
        }
        if (i == 50 || (i > 50 && i < 70)) {
            rank = SeasonRank.Champion;
        }
        if (i == 70 || (i > 70 && i < 100)) {
            rank = SeasonRank.Sargeant;
        }
        if (i == 150 || (i > 150 && i < 200)) {
            rank = SeasonRank.WarHero;
        }
        if (i == 200 || (i > 200 && i < 300)) {
            rank = SeasonRank.WarHero;
        }
        if (i >= 300) {
            rank = SeasonRank.Reveaser;
        }
        return rank;
    }
    
    public static SeasonRank getNextRank(final SeasonRank r) {
        SeasonRank rank = null;
        switch (r) {
            case Stray: {
                rank = SeasonRank.Wanderer;
                break;
            }
            case Wanderer: {
                rank = SeasonRank.Defender;
                break;
            }
            case Defender: {
                rank = SeasonRank.Solider;
                break;
            }
            case Solider: {
                rank = SeasonRank.Champion;
                break;
            }
            case Champion: {
                rank = SeasonRank.Sargeant;
                break;
            }
            case Sargeant: {
                rank = SeasonRank.WarHero;
                break;
            }
            case WarHero: {
                rank = SeasonRank.Veteran;
                break;
            }
            case Veteran: {
                rank = SeasonRank.Guardian;
                break;
            }
            case Guardian: {
                rank = SeasonRank.Reveaser;
                break;
            }
        }
        return rank;
    }
    
    public int getRankWins() {
        return this.wins;
    }
}
