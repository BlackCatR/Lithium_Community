package com.Reveas.Hub.API;

import java.nio.charset.*;
import java.net.*;
import java.io.*;

public final class ServerListPing
{
    private String address;
    private int port;
    private int timeout;
    private int pingVersion;
    private int protocolVersion;
    private String gameVersion;
    private String motd;
    private int playersOnline;
    private int maxPlayers;
    
    public ServerListPing() {
        this.timeout = 2000;
    }
    
    public ServerListPing(final String address) {
        this();
        this.setAddress(address);
    }
    
    public ServerListPing(final String address, final int port) {
        this(address);
        this.setPort(port);
    }
    
    public ServerListPing(final String address, final int port, final int timeout) {
        this(address, port);
        this.setTimeout(timeout);
    }
    
    public void setAddress(final String address) {
        this.address = address;
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public void setPort(final int port) {
        this.port = port;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public void setTimeout(final int timeout) {
        this.timeout = timeout;
    }
    
    public int getTimeout() {
        return this.timeout;
    }
    
    private void setPingVersion(final int pingVersion) {
        this.pingVersion = pingVersion;
    }
    
    public int getPingVersion() {
        return this.pingVersion;
    }
    
    private void setProtocolVersion(final int protocolVersion) {
        this.protocolVersion = protocolVersion;
    }
    
    public int getProtocolVersion() {
        return this.protocolVersion;
    }
    
    private void setGameVersion(final String gameVersion) {
        this.gameVersion = gameVersion;
    }
    
    public String getGameVersion() {
        return this.gameVersion;
    }
    
    private void setMotd(final String motd) {
        this.motd = motd;
    }
    
    public String getMotd() {
        return this.motd;
    }
    
    private void setPlayersOnline(final int playersOnline) {
        this.playersOnline = playersOnline;
    }
    
    public int getPlayersOnline() {
        return this.playersOnline;
    }
    
    private void setMaxPlayers(final int maxPlayers) {
        this.maxPlayers = maxPlayers;
    }
    
    public int getMaxPlayers() {
        return this.maxPlayers;
    }
    
    public boolean fetchData() {
        try {
            final Socket socket = new Socket();
            socket.setSoTimeout(this.timeout);
            socket.connect(new InetSocketAddress(this.getAddress(), this.getPort()), this.getTimeout());
            final OutputStream outputStream = socket.getOutputStream();
            final DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            final InputStream inputStream = socket.getInputStream();
            final InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-16BE"));
            dataOutputStream.write(new byte[] { -2, 1 });
            final int packetId = inputStream.read();
            if (packetId == -1) {
                throw new IOException("Premature end of stream.");
            }
            if (packetId != 255) {
                throw new IOException("Invalid packet ID (" + packetId + ").");
            }
            final int length = inputStreamReader.read();
            if (length == -1) {
                throw new IOException("Premature end of stream.");
            }
            if (length == 0) {
                throw new IOException("Invalid string length.");
            }
            final char[] chars = new char[length];
            if (inputStreamReader.read(chars, 0, length) != length) {
                throw new IOException("Premature end of stream.");
            }
            final String string = new String(chars);
            if (string.startsWith("�")) {
                final String[] data = string.split("\u0000");
                this.setPingVersion(Integer.parseInt(data[0].substring(1)));
                this.setProtocolVersion(Integer.parseInt(data[1]));
                this.setGameVersion(data[2]);
                this.setMotd(data[3]);
                this.setPlayersOnline(Integer.parseInt(data[4]));
                this.setMaxPlayers(Integer.parseInt(data[5]));
            }
            else {
                final String[] data = string.split("�");
                this.setMotd(data[0]);
                this.setPlayersOnline(Integer.parseInt(data[1]));
                this.setMaxPlayers(Integer.parseInt(data[2]));
            }
            dataOutputStream.close();
            outputStream.close();
            inputStreamReader.close();
            inputStream.close();
            socket.close();
        }
        catch (SocketException exception) {
            return false;
        }
        catch (IOException exception2) {
            return false;
        }
        return true;
    }
}
