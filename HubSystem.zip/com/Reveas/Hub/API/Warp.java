package com.Reveas.Hub.API;

import org.bukkit.configuration.file.*;
import org.bukkit.*;

public class Warp
{
    public static FileConfiguration Cfg;
    
    static {
        Warp.Cfg = FileManager.WarpConfig;
    }
    
    public static Location get(final String Path) {
        if (FileManager.WarpFile.exists() && Warp.Cfg.get(Path) != null) {
            final World World = Bukkit.getWorld(Warp.Cfg.getString(String.valueOf(String.valueOf(Path)) + ".World"));
            final double X = Warp.Cfg.getDouble(String.valueOf(String.valueOf(Path)) + ".X");
            final double Y = Warp.Cfg.getDouble(String.valueOf(String.valueOf(Path)) + ".Y");
            final double Z = Warp.Cfg.getDouble(String.valueOf(String.valueOf(Path)) + ".Z");
            final float Yaw = (float)Warp.Cfg.getDouble(String.valueOf(String.valueOf(Path)) + ".Yaw");
            final float Pitch = (float)Warp.Cfg.getDouble(String.valueOf(String.valueOf(Path)) + ".Pitch");
            return new Location(World, X, Y, Z, Yaw, Pitch);
        }
        return null;
    }
    
    public static void set(final Location Loc, final String Path) {
        if (FileManager.WarpFile.exists()) {
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".World", (Object)Loc.getWorld().getName());
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".X", (Object)Loc.getX());
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".Y", (Object)Loc.getY());
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".Z", (Object)Loc.getZ());
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".Yaw", (Object)Loc.getYaw());
            Warp.Cfg.set(String.valueOf(String.valueOf(Path)) + ".Pitch", (Object)Loc.getPitch());
            FileManager.saveWarpConfig();
        }
    }
}
