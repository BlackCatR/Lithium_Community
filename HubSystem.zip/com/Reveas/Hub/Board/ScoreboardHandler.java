package com.Reveas.Hub.Board;

import org.bukkit.entity.*;
import org.bukkit.scoreboard.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Utils.*;
import org.bukkit.*;
import com.Reveas.api.util.*;
import java.util.*;

public class ScoreboardHandler
{
    public static void getJoin(final Player p) {
        final ScoreboardManager manager = Bukkit.getScoreboardManager();
        final Scoreboard board = manager.getNewScoreboard();
        final Objective o = board.registerNewObjective("lobby", "dummy");
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        o.setDisplayName("�e�lNix �3Network");
        o.getScore("�a ").setScore(15);
        o.getScore("�7\u267c �c�lRank").setScore(14);
        final com.Reveas.Hub.Main.Player info = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        o.getScore("�8\u279f " + info.getRankColor() + info.getRankName().replace("SrMod", "Senior Mod")).setScore(13);
        o.getScore("�a �a ").setScore(12);
        o.getScore("�6\u272a �a�lTokens").setScore(11);
        if (board.getTeam("Tokens") == null) {
            final Team tt = board.registerNewTeam("Tokens");
            tt.addPlayer(Bukkit.getOfflinePlayer(ChatColor.BLACK.toString()));
            tt.setPrefix("�8\u279f �7" + info.getTokens());
            o.getScore(ChatColor.BLACK.toString()).setScore(10);
        }
        o.getScore("�a �a �a ").setScore(9);
        o.getScore("�7\u27b2 �3�lLevel").setScore(8);
        o.getScore("�8\u279f �7" + info.getLevel()).setScore(7);
        o.getScore("�a �a �a �a ").setScore(6);
        o.getScore("�f\u272a �b�lXP").setScore(5);
        o.getScore("�8\u279f �7" + info.getExp() + "/" + info.getLevelMax()).setScore(4);
        o.getScore("�a �a �a �a �a ").setScore(3);
        o.getScore("�8----------------").setScore(2);
        o.getScore("�6play.�eNixMC�6.com").setScore(1);
        p.setScoreboard(board);
    }
    
    public static void getBoard(final Player p) {
        final com.Reveas.Hub.Main.Player info = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        final Integer playerTokens = info.getTokens();
        final Team team2 = p.getScoreboard().getTeam("Tokens");
        team2.setPrefix(Main.F("�8\u279f �7" + playerTokens));
    }
    
    public static void RegisterTag(final Scoreboard board) {
        if (board.getTeam("a_Owner") == null) {
            board.registerNewTeam("a_Owner");
            board.getTeam("a_Owner").setPrefix("�e");
        }
        if (board.getTeam("b_HeadAdmin") == null) {
            board.registerNewTeam("b_HeadAdmin");
            board.getTeam("b_HeadAdmin").setPrefix("�4");
        }
        if (board.getTeam("d_Admin") == null) {
            board.registerNewTeam("d_Admin");
            board.getTeam("d_Admin").setPrefix("�4");
        }
        if (board.getTeam("c_Dev") == null) {
            board.registerNewTeam("c_Dev");
            board.getTeam("c_Dev").setPrefix("�7");
        }
        if (board.getTeam("e_SrMod") == null) {
            board.registerNewTeam("e_SrMod");
            board.getTeam("e_SrMod").setPrefix("�4");
        }
        if (board.getTeam("f_Builder") == null) {
            board.registerNewTeam("f_Builder");
            board.getTeam("f_Builder").setPrefix("�2");
        }
        if (board.getTeam("g_Mod") == null) {
            board.registerNewTeam("g_Mod");
            board.getTeam("g_Mod").setPrefix("�c");
        }
        if (board.getTeam("h_Emerald") == null) {
            board.registerNewTeam("h_Emerald");
            board.getTeam("h_Emerald").setPrefix("�a");
        }
        if (board.getTeam("i_Diamond") == null) {
            board.registerNewTeam("i_Diamond");
            board.getTeam("i_Diamond").setPrefix("�b");
        }
        if (board.getTeam("j_Gold") == null) {
            board.registerNewTeam("j_Gold");
            board.getTeam("j_Gold").setPrefix("�6");
        }
        if (board.getTeam("h_VIP") == null) {
            board.registerNewTeam("h_VIP");
            board.getTeam("h_VIP").setPrefix("�5");
        }
        if (board.getTeam("k_Member") == null) {
            board.registerNewTeam("k_Member");
            board.getTeam("k_Member").setPrefix("�9");
        }
        for (final Player p : Bukkit.getOnlinePlayers()) {
            final com.Reveas.Hub.Main.Player RS = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
            if (ArrayAndHash.ToggleRank.contains(p.getName())) {
                board.getTeam("k_Member").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.OWNER.toString()) {
                board.getTeam("a_Owner").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.HEADADMIN.toString()) {
                board.getTeam("b_HeadAdmin").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.ADMIN.toString()) {
                board.getTeam("d_Admin").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.DEVELOPER.toString()) {
                board.getTeam("c_Dev").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.SRMOD.toString()) {
                board.getTeam("e_SrMod").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.BUILDER.toString()) {
                board.getTeam("f_Builder").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.MOD.toString()) {
                board.getTeam("g_Mod").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.EMERALD.toString()) {
                board.getTeam("h_Emerald").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.DIAMOND.toString()) {
                board.getTeam("i_Diamond").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.GOLD.toString()) {
                board.getTeam("j_Gold").addPlayer((OfflinePlayer)p);
            }
            else if (RS.getRank() == Rank.VIP.toString()) {
                board.getTeam("h_VIP").addPlayer((OfflinePlayer)p);
            }
            else {
                if (RS.getRank() != Rank.MEMBER.toString()) {
                    continue;
                }
                board.getTeam("k_Member").addPlayer((OfflinePlayer)p);
            }
        }
    }
}
