package com.Reveas.Hub.Chat;

import org.bukkit.entity.*;
import com.Reveas.api.*;
import net.md_5.bungee.api.chat.*;
import com.Reveas.api.util.*;
import java.util.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.event.block.*;

public class Chat implements Listener
{
    public static void chat(final Player p, final PlayerChatEvent e) {
        final ReveasPlayer RS = Reveas.getPlayer(p.getName());
        final String name = p.getName();
        final String dname = p.getDisplayName();
        final String msg = e.getMessage();
        final String color = RS.getRank().getTabPrefix();
        final String rank = RS.getRank().getName();
        final int level2 = RS.getLevel();
        TextComponent chatMessage = new TextComponent("null");
        if (!rank.equals(Rank.MEMBER)) {
            chatMessage = new TextComponent("�8\u2503 �e" + level2 + " �8\u2503 " + rank + " �8\u2503 " + color + dname + " �8��f " + msg);
        }
        else {
            chatMessage = new TextComponent("�8\u2503 �e" + level2 + " �8\u2503 " + color + dname + " �8� " + "�f" + msg);
        }
        chatMessage.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("�3UserName �e� �e" + color + name + "\n" + "�3Rank �e� �e" + color + rank + "\n" + "�3Level �e� �e" + level2 + "\n" + "�3XP �e� �7" + RS.getXP()).create()));
        for (final Player pa : e.getRecipients()) {
            pa.spigot().sendMessage((BaseComponent)chatMessage);
        }
        e.getRecipients().clear();
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onPlayer(final PlayerChatEvent e) {
        final Player p = e.getPlayer();
        final String msg = e.getMessage();
        final ReveasPlayer RM = Reveas.getPlayer(p.getName());
        if (Main.muted.contains(p)) {
            if (Reveas.getPlayer(p.getName()).getRank().getLevel() >= Rank.SRMOD.getLevel()) {
                e.setCancelled(false);
            }
            else {
                e.setCancelled(true);
                final String broadcast = Main.plugin.getConfig().getString("Globalmute.DenyChat").replace("&", "�");
                p.sendMessage(broadcast);
            }
        }
        else {
            e.setCancelled(false);
        }
        if (Main.muted.contains(p)) {
            e.setCancelled(true);
            final String nowmuted = Main.plugin.getConfig().getString("Message.nowmuted").replace("&", "�");
            p.sendMessage(nowmuted);
        }
        else {
            e.setCancelled(false);
        }
        e.setCancelled(true);
        final com.Reveas.Hub.Main.Player RS = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        chat(p, e);
    }
    
    @EventHandler
    public void onPlayer2(final AsyncPlayerChatEvent e) {
        final Player p = e.getPlayer();
        if (Reveas.checkPermission(p.getName(), Rank.SRMOD)) {
            e.setMessage(ChatColor.translateAlternateColorCodes('&', e.getMessage()));
        }
    }
    
    @EventHandler
    public void onSign(final SignChangeEvent e) {
        e.setLine(0, ChatColor.translateAlternateColorCodes('&', e.getLine(0)));
        e.setLine(1, ChatColor.translateAlternateColorCodes('&', e.getLine(1)));
        e.setLine(2, ChatColor.translateAlternateColorCodes('&', e.getLine(2)));
        e.setLine(3, ChatColor.translateAlternateColorCodes('&', e.getLine(3)));
    }
}
