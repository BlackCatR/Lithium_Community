package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.api.util.*;
import com.Reveas.api.*;
import org.bukkit.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.inventory.*;

public class Boots_cmd implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 45, "�8\u279f�e Boots");
        final ItemStack Back = new ItemStack(Material.REDSTONE_BLOCK);
        final ItemMeta Back2 = Back.getItemMeta();
        Back2.setDisplayName("�7\u279f�c Remove Boots");
        Back.setItemMeta(Back2);
        inv.setItem(40, Back);
        p.openInventory(inv);
        final ItemStack love1 = new ItemStack(Material.ARROW);
        final ItemMeta lovemeta1 = love1.getItemMeta();
        lovemeta1.setDisplayName("�cBack!");
        love1.setItemMeta(lovemeta1);
        inv.setItem(44, love1);
        p.openInventory(inv);
        final ItemStack Shop = new ItemStack(Material.BOOK);
        final ItemMeta Shop2 = Shop.getItemMeta();
        Shop2.setDisplayName("�8��a Store");
        Shop.setItemMeta(Shop2);
        inv.setItem(36, Shop);
        p.openInventory(inv);
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack love2 = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta lovemeta2 = (LeatherArmorMeta)love2.getItemMeta();
            lovemeta2.setColor(Color.fromRGB(255, 0, 0));
            lovemeta2.setDisplayName("�4Love Boots");
            lovemeta2.addEnchant(Enchantment.DURABILITY, 10, true);
            love2.setItemMeta((ItemMeta)lovemeta2);
            inv.addItem(new ItemStack[] { love2 });
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack l = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta ll = (LeatherArmorMeta)l.getItemMeta();
            ll.setColor(Color.fromRGB(255, 133, 122));
            ll.setDisplayName("�5Music �6Boots");
            ll.addEnchant(Enchantment.DURABILITY, 10, true);
            l.setItemMeta((ItemMeta)ll);
            inv.setItem(1, l);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack u = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta uu = (LeatherArmorMeta)u.getItemMeta();
            uu.setColor(Color.fromRGB(255, 20, 147));
            uu.setDisplayName("�5Ender Boots");
            uu.addEnchant(Enchantment.DURABILITY, 10, true);
            u.setItemMeta((ItemMeta)uu);
            inv.setItem(2, u);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack f = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta ff = (LeatherArmorMeta)f.getItemMeta();
            ff.setColor(Color.fromRGB(100, 100, 100));
            ff.setDisplayName("�3Angry Boots");
            ff.addEnchant(Enchantment.DURABILITY, 10, true);
            f.setItemMeta((ItemMeta)ff);
            inv.setItem(3, f);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack s = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta ss = (LeatherArmorMeta)s.getItemMeta();
            ss.setColor(Color.fromRGB(180, 100, 120));
            ss.setDisplayName("�7Smoke Boots");
            ss.addEnchant(Enchantment.DURABILITY, 10, true);
            s.setItemMeta((ItemMeta)ss);
            inv.setItem(4, s);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack j = new ItemStack(Material.DIAMOND_BOOTS);
            final ItemMeta jj = j.getItemMeta();
            jj.setDisplayName("�cJetPack Boots");
            jj.addEnchant(Enchantment.DURABILITY, 10, true);
            j.setItemMeta(jj);
            inv.setItem(5, j);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack m = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta mm = (LeatherArmorMeta)m.getItemMeta();
            mm.setColor(Color.fromRGB(205, 133, 63));
            mm.setDisplayName("�6Fire Boots");
            mm.addEnchant(Enchantment.DURABILITY, 10, true);
            m.setItemMeta((ItemMeta)mm);
            inv.setItem(6, m);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack k = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta kk = (LeatherArmorMeta)k.getItemMeta();
            kk.setColor(Color.fromRGB(85, 255, 255));
            kk.setDisplayName("�3Wather Boots");
            kk.addEnchant(Enchantment.DURABILITY, 10, true);
            k.setItemMeta((ItemMeta)kk);
            inv.setItem(7, k);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack t = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta tt = (LeatherArmorMeta)t.getItemMeta();
            tt.setColor(Color.fromRGB(0, 0, 0));
            tt.setDisplayName("�dMystic Boots");
            tt.addEnchant(Enchantment.DURABILITY, 10, true);
            t.setItemMeta((ItemMeta)tt);
            inv.setItem(8, t);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack i = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta ii = (LeatherArmorMeta)i.getItemMeta();
            ii.setColor(Color.fromRGB(255, 255, 255));
            ii.setDisplayName("�fIce Boots");
            ii.addEnchant(Enchantment.DURABILITY, 10, true);
            i.setItemMeta((ItemMeta)ii);
            inv.setItem(9, i);
            p.openInventory(inv);
        }
        if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack o = new ItemStack(Material.LEATHER_BOOTS);
            final LeatherArmorMeta oo = (LeatherArmorMeta)o.getItemMeta();
            oo.setColor(Color.fromRGB(170, 0, 0));
            oo.setDisplayName("�2Speed Boots");
            oo.addEnchant(Enchantment.DURABILITY, 10, true);
            o.setItemMeta((ItemMeta)oo);
            inv.setItem(10, o);
            p.openInventory(inv);
        }
        return false;
    }
}
