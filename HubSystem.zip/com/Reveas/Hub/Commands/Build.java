package com.Reveas.Hub.Commands;

import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.command.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import java.util.*;

public class Build implements CommandExecutor
{
    public static ArrayList<Player> build;
    public static HashMap<Player, HashMap<Integer, ItemStack>> builditems;
    
    static {
        Build.build = new ArrayList<Player>();
        Build.builditems = new HashMap<Player, HashMap<Integer, ItemStack>>();
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            return false;
        }
        final Player p = (Player)sender;
        if (p.hasPermission("lobby.command.*") || p.hasPermission("lobby.command.build")) {
            if (args.length == 0) {
                if (Build.build.contains(p)) {
                    Build.build.remove(p);
                    p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�7You have been build now �c�oDisable");
                    p.setGameMode(GameMode.SURVIVAL);
                    p.getInventory().clear();
                    p.getInventory().setArmorContents((ItemStack[])null);
                    if (Build.builditems.containsKey(p)) {
                        final HashMap<Integer, ItemStack> items = Build.builditems.get(p);
                        for (final int i : items.keySet()) {
                            p.getInventory().setItem(i, (ItemStack)items.get(i));
                        }
                        Build.builditems.remove(p);
                    }
                }
                else {
                    Build.build.add(p);
                    final HashMap<Integer, ItemStack> items = new HashMap<Integer, ItemStack>();
                    try {
                        for (int i = 0; i < p.getInventory().getSize(); ++i) {
                            items.put(i, p.getInventory().getItem(i));
                        }
                    }
                    catch (Exception ex) {}
                    Build.builditems.put(p, items);
                    p.getInventory().clear();
                    p.getInventory().setArmorContents((ItemStack[])null);
                    p.setGameMode(GameMode.CREATIVE);
                    p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�7You have been build now �a�oEnable");
                }
            }
            else {
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�7/build");
            }
        }
        else {
            p.sendMessage(String.valueOf(Main.Perm));
        }
        return false;
    }
}
