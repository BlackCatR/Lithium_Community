package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import com.Reveas.api.*;
import com.Reveas.api.util.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import java.util.*;

public class CommandTp implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (sender instanceof Player) {
            final Player p = (Player)sender;
            if (Reveas.getPlayer(p.getName()).getRank().getLevel() >= Rank.ADMIN.getLevel()) {
                for (final Player all : Bukkit.getOnlinePlayers()) {
                    if (all != p) {
                        all.teleport((Entity)p);
                    }
                    all.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aYou teleported all the players to " + p.getName() + "�a!");
                }
            }
        }
        else {
            final Player p = (Player)sender;
            sender.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aYou teleported all the players to" + p.getName() + "!");
        }
        return false;
    }
}
