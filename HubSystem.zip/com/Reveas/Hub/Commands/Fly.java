package com.Reveas.Hub.Commands;

import java.util.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.api.util.*;
import com.Reveas.api.*;
import com.Reveas.Hub.Main.*;

public class Fly implements CommandExecutor
{
    public static ArrayList<UUID> fly;
    
    static {
        Fly.fly = new ArrayList<UUID>();
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String alias, final String[] args) {
        if (cmd.getName().equalsIgnoreCase("fly")) {
            final Player p = (Player)sender;
            if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
                if (Fly.fly.contains(p.getUniqueId())) {
                    p.setAllowFlight(false);
                    p.setFlying(false);
                    Fly.fly.remove(p.getUniqueId());
                    p.sendMessage(String.valueOf(Main.prefix) + "�bYou can't fly now!");
                    return true;
                }
                Fly.fly.add(p.getUniqueId());
                p.setAllowFlight(true);
                p.setFlying(true);
                p.sendMessage(String.valueOf(Main.prefix) + "�6You can fly now!");
            }
        }
        return false;
    }
}
