package com.Reveas.Hub.Commands;

import org.bukkit.event.*;
import com.Reveas.Hub.Main.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.command.*;
import org.bukkit.*;

public class ForceField implements Listener, CommandExecutor
{
    private Main plugin;
    public static HashMap<Player, Player> ForceField;
    
    static {
        com.Reveas.Hub.Commands.ForceField.ForceField = new HashMap<Player, Player>();
    }
    
    public ForceField(final Main hub) {
        this.plugin = hub;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String alias, final String[] args) {
        if (sender instanceof Player) {
            final Player player = (Player)sender;
            if (command.getName().equalsIgnoreCase("forcefield")) {
                if (args.length <= 0) {
                    if (sender.hasPermission("forcefield.self") || sender.isOp()) {
                        if (com.Reveas.Hub.Commands.ForceField.ForceField.containsKey(player)) {
                            com.Reveas.Hub.Commands.ForceField.ForceField.remove(player);
                            sender.sendMessage(String.valueOf(Main.prefix) + Main.F + Main.F + "&cYou no longer have a forcefield.");
                        }
                        else {
                            com.Reveas.Hub.Commands.ForceField.ForceField.put(player, player);
                            sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&aYou now have a forcefield.");
                        }
                    }
                    else {
                        sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&cYou dont have the permission &bforcefield.self");
                    }
                }
                if (args.length == 1) {
                    if (sender.hasPermission("forcefield.others") || sender.isOp()) {
                        final Player target = Bukkit.getServer().getPlayer(args[0]);
                        if (target == null) {
                            sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&cYou must supply an online players name.");
                        }
                        else if (com.Reveas.Hub.Commands.ForceField.ForceField.containsKey(target)) {
                            com.Reveas.Hub.Commands.ForceField.ForceField.remove(target);
                            target.sendMessage(String.valueOf(Main.prefix) + Main.F + "&cYou no longer have a forcefield.");
                            sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&b" + target.getName() + " &cno longer has a forcefield.");
                        }
                        else if (!com.Reveas.Hub.Commands.ForceField.ForceField.containsKey(target)) {
                            com.Reveas.Hub.Commands.ForceField.ForceField.put(target, target);
                            target.sendMessage(String.valueOf(Main.prefix) + Main.F + "&aYou now have a forcefield.");
                            sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&b" + target.getName() + " &anow has a forcefield.");
                        }
                    }
                    else {
                        sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&cYou dont have the permission &bforcefield.others");
                    }
                }
                else if (args.length >= 2) {
                    sender.sendMessage(String.valueOf(Main.prefix) + Main.F + "&c/ForceField [target]");
                }
            }
        }
        return true;
    }
}
