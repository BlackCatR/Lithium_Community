package com.Reveas.Hub.Commands;

import org.bukkit.event.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.plugin.*;

public class Force_Handler implements Listener
{
    private Main plugin;
    
    public Force_Handler(final Main hub) {
        this.plugin = hub;
        this.forcefield();
    }
    
    public void forcefield() {
        Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)this.plugin, (Runnable)new Runnable() {
            @Override
            public void run() {
                for (final Player player : Bukkit.getOnlinePlayers()) {
                    final List<Entity> nearbyPlayers = (List<Entity>)player.getNearbyEntities(3.0, 3.0, 3.0);
                    for (final Entity entity : nearbyPlayers) {
                        if (entity instanceof Player) {
                            if (ForceField.ForceField.containsKey(player) && ForceField.ForceField.containsKey(entity)) {
                                return;
                            }
                            if (!ForceField.ForceField.containsKey(player)) {
                                continue;
                            }
                            entity.setVelocity(entity.getLocation().getDirection().multiply(-1.5).setY(1));
                        }
                    }
                }
            }
        }, 0L, 5L);
    }
}
