package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import com.Reveas.Hub.Main.*;
import java.util.*;

public class GiveAll implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String lable, final String[] args) {
        final Player p = (Player)sender;
        if (p.hasPermission("cassy.command.giveall")) {
            for (final Player all : Bukkit.getOnlinePlayers()) {
                all.getInventory().addItem(new ItemStack[] { new ItemStack(p.getItemInHand()) });
            }
        }
        else {
            p.sendMessage(Main.Perm);
        }
        return false;
    }
}
