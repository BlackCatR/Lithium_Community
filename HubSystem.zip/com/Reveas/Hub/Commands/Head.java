package com.Reveas.Hub.Commands;

import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;

public class Head implements CommandExecutor
{
    public static ItemStack CreatePlayerSkull(final String playerName, final String name, final String... lore) {
        final ItemStack i = new ItemStack(Material.SKULL_ITEM, 1, (short)SkullType.PLAYER.ordinal());
        final ItemMeta im = i.getItemMeta();
        ((SkullMeta)im).setOwner(playerName);
        im.setDisplayName(name);
        im.setLore((List)Arrays.asList(lore));
        i.setItemMeta(im);
        return i;
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only Player's Can Execute This Command.");
            return true;
        }
        if (args.length == 0) {
            final Player p = (Player)sender;
            p.sendMessage(String.valueOf(Main.prefix) + "�8�m--------------[�e�lRM�8�m]--------------");
            p.sendMessage(String.valueOf(Main.prefix) + "�e/Head <name>");
            p.sendMessage(String.valueOf(Main.prefix) + "�8�m--------------�8�m------------------");
        }
        final Player player = (Player)sender;
        if (player.hasPermission("Owner")) {}
        if (cmd.getName().equalsIgnoreCase("head") && args.length == 2) {
            final Player newPlayer = Bukkit.getPlayer(args[0]);
            newPlayer.getInventory().addItem(new ItemStack[] { CreatePlayerSkull(args[1], ChatColor.RESET + args[1], new String[0]) });
            player.sendMessage("Successfully gave " + args[1] + " a skull.");
            newPlayer.sendMessage("You received a skull from " + player.getName());
            return true;
        }
        return false;
    }
}
