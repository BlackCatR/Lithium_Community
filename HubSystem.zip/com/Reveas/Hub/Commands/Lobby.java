package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.Reveas.Hub.Main.*;

public class Lobby implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        p.teleport(Bukkit.getServer().getWorld("Hub").getSpawnLocation());
        p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aYou have been sent to the Hub");
        return false;
    }
}
