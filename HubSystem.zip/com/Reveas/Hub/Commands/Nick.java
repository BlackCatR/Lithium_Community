package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;

public class Nick implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        p.sendMessage(String.valueOf(Main.prefix) + Main.F("�7You can't toggle your �5Nick �7in the lobby!"));
        return false;
    }
}
