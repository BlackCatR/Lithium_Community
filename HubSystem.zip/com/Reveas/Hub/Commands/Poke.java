package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.api.*;
import com.Reveas.api.managers.*;
import org.bukkit.*;
import org.bukkit.potion.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.util.*;

public class Poke implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        final Player p = (Player)sender;
        if (p.hasPermission("poke")) {
            if (args.length == 0) {
                if (p.hasPermission("poke")) {
                    sender.sendMessage("�8\u258e �6Poke �8\u258f �cUsage: /poke [username]");
                }
                return true;
            }
            final Player p2 = Bukkit.getServer().getPlayer(args[0]);
            final com.Reveas.Hub.Main.Player R1 = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
            final com.Reveas.Hub.Main.Player R2 = new com.Reveas.Hub.Main.Player(p2.getName(), p2.getUniqueId().toString());
            final ReveasPlayer rp1 = Reveas.getPlayer(p2.getName());
            final ReveasPlayer rp2 = Reveas.getPlayer(p.getName());
            if (p2 == null) {
                sender.sendMessage("�8\u258e �6Poke �8\u258f Player �e" + args[0] + " �cis not online!");
                return true;
            }
            if (R1.getRankLevel() > R2.getRankLevel()) {
                return true;
            }
            if (p2.hasPermission("Poke")) {
                TitleAPI.sendTitle(p2, Integer.valueOf(20), Integer.valueOf(40), Integer.valueOf(20), "�7� �6Poke�7 �", "�3You have been �eweekup �3by �e" + sender.getName());
                p2.playSound(p2.getLocation(), Sound.BLAZE_DEATH, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.BAT_IDLE, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.ANVIL_BREAK, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.AMBIENCE_CAVE, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.ENDERMAN_HIT, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.DOOR_OPEN, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.HORSE_ZOMBIE_HIT, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.MAGMACUBE_WALK2, 10.0f, 10.0f);
                p2.playSound(p2.getLocation(), Sound.ZOMBIE_HURT, 10.0f, 10.0f);
                p2.playEffect(p2.getLocation(), Effect.WITCH_MAGIC, 10);
                p2.playEffect(p2.getLocation(), Effect.EXPLOSION, 10);
                p2.playEffect(p2.getLocation(), Effect.CLOUD, 10);
                p2.playEffect(p2.getLocation(), Effect.SMALL_SMOKE, 10);
                p2.playEffect(p2.getLocation(), Effect.EXPLOSION_LARGE, 10);
                p2.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 4, 4));
                p2.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 4, 4));
                p2.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 4, 4));
                p2.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 4, 4));
                p2.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 4, 4));
                sender.sendMessage("�8\u258e �6Poke �8\u258f �3You poked �3" + p2.getDisplayName());
                p2.sendMessage("�8\u258e �6Poke �8\u258f �3You have been �eweekup �3by �e" + sender.getName());
                return true;
            }
            p2.sendMessage(Main.Perm);
        }
        return false;
    }
}
