package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import java.util.*;
import com.Reveas.Hub.API.*;
import org.bukkit.craftbukkit.v1_8_R3.entity.*;
import com.Reveas.api.*;
import org.bukkit.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.inventory.*;
import com.Reveas.api.util.*;

public class Records implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("Records")) {
            final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 45, "�3Records");
            final ItemStack SG = new ItemStack(Material.PAPER);
            final ItemMeta m2 = SG.getItemMeta();
            m2.setDisplayName("�c\u2694 �8� �3SurvivalGames");
            final List<String> Survivalgames = Arrays.asList("�3UserName �8��e " + p.getName(), "�3Points �8��e " + Stats_SG.getPoints(p.getUniqueId().toString()), "�3Kills �8��e " + Stats_SG.getKills(p.getUniqueId().toString()), "�3Deaths �8��e " + Stats_SG.getDeaths(p.getUniqueId().toString()), "�3Games Played �8��e " + Stats_SG.getPlayed(p.getUniqueId().toString()), "�3Crates Opened �8��e " + Stats_SG.getChest(p.getUniqueId().toString()), "�3Victories �8��e " + Stats_SG.getWins(p.getUniqueId().toString()));
            m2.setLore((List)Survivalgames);
            SG.setItemMeta(m2);
            inv.setItem(12, SG);
            p.openInventory(inv);
            final ItemStack F1 = new ItemStack(Material.PAPER);
            final ItemMeta m3 = F1.getItemMeta();
            m3.setDisplayName("�c\u2694 �8� �e�lPVP");
            final List<String> PVPlore = Arrays.asList("�3PVP Rank �8��e " + Rank.getPRank(Stats_FFA.getPoints(p.getUniqueId().toString())).getName(), "�3Ranking �8��e " + Stats_FFA.getRanking(p.getUniqueId().toString()), "�3UserName �8��e " + p.getName(), "�3Points �8��e " + Stats_FFA.getPoints(p.getUniqueId().toString()), "�3Kills �8��e " + Stats_FFA.getKills(p.getUniqueId().toString()), "�3Deaths �8��e " + Stats_FFA.getDeaths(p.getUniqueId().toString()), "�3Killsreaks �8��e " + Stats_FFA.getKillstreak(p.getUniqueId().toString()), "�3K/D �8��e " + Stats_FFA.getDeaths(p.getUniqueId().toString()));
            m3.setLore((List)PVPlore);
            F1.setItemMeta(m3);
            inv.setItem(24, F1);
            p.openInventory(inv);
            final ItemStack F2 = new ItemStack(Material.ARROW);
            final ItemMeta m4 = F1.getItemMeta();
            m4.setDisplayName("�8� �c�lExit to Back");
            final List<String> Exit = Arrays.asList(new String[0]);
            m4.setLore((List)Exit);
            F2.setItemMeta(m4);
            inv.setItem(44, F2);
            p.openInventory(inv);
            final ItemStack v = new ItemStack(Material.PAPER);
            final ItemMeta vv = v.getItemMeta();
            vv.setDisplayName("�c\u2694 �8� �b�l1�a�lvs�b�l1");
            final List<String> vs = Arrays.asList("�31vs1 Rank �8��e " + SeasonRank.getByWins(Stats_OvO.getWins(p.getUniqueId().toString())).getName(), "�3Ranking �8��e " + Stats_OvO.getRanking(p.getUniqueId().toString(), ""), "�3UserName �8��e " + p.getDisplayName(), "�3Points �8��e " + Stats_OvO.getPoints(p.getUniqueId().toString()), "�3Kills �8��e " + Stats_OvO.getKills(p.getUniqueId().toString()), "�3Deaths �8��e " + Stats_OvO.getDeaths(p.getUniqueId().toString()), "�3Rounds �8��e " + Stats_OvO.getRounds(p.getUniqueId().toString()), "�3K/D �8��e " + Stats_FFA.getDeaths(p.getUniqueId().toString()));
            vv.setLore((List)vs);
            v.setItemMeta(vv);
            inv.setItem(30, v);
            p.openInventory(inv);
            final ItemStack GG = new ItemStack(Material.PAPER);
            final ItemMeta GG2 = GG.getItemMeta();
            GG2.setDisplayName("�c\u2694 �8� �b�lGun�a�lGame");
            final List<String> GGlore = Arrays.asList("�3UserName �8��e " + p.getName(), "�3Points �8��e " + Stats_GG.getPoints(p.getUniqueId()), "�3Kills �8��e " + Stats_GG.getKills(p.getUniqueId()), "�3Deaths �8��e " + Stats_GG.getDeaths(p.getUniqueId()));
            GG2.setLore((List)GGlore);
            GG.setItemMeta(GG2);
            inv.setItem(14, GG);
            p.openInventory(inv);
            final ItemStack Lobby = new ItemStack(Material.PAPER);
            final ItemMeta mh = Lobby.getItemMeta();
            mh.setDisplayName("�6\u2734 �8� �aHub");
            final int ping = ((CraftPlayer)p).getHandle().ping;
            final List<String> Hub = Arrays.asList("�3Rank �8��e " + Reveas.getPlayer(p.getName()).getRank().getName(), "�3UserName �8��e " + p.getName(), "�3Adress �8��e " + p.getAddress().getHostString(), "�3Onlinetime �8��e  Coming Soon", "�3Ping �8��e " + ping, "�3Account's �8��e 2", "�3Server �8��e " + p.getWorld().getName());
            mh.setLore((List)Hub);
            Lobby.setItemMeta(mh);
            inv.setItem(20, Lobby);
            p.openInventory(inv);
            final ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
            final SkullMeta i = (SkullMeta)skull.getItemMeta();
            i.setOwner(p.getName());
            final ReveasPlayer hp = Reveas.getPlayer(p.getName());
            i.setDisplayName("�8\u2022 �e�lReveas�6�lMC �8\u2022");
            final List<String> lore = Arrays.asList("�3UserName �8� �e" + p.getName(), "�3Rank �8� " + hp.getRank().getTabPrefix() + hp.getRank().getName(), ChatColor.WHITE + "�3Tokens �8� �e" + Stats_HubSystem.getTokens(p.getUniqueId().toString()), "�3Credits�8 � �e" + Stats_HubSystem.getCredits(p.getUniqueId().toString()), "�3Enchant Crystals�8 � �e" + Stats_HubSystem.getCrystals(p.getUniqueId().toString()));
            i.setLore((List)lore);
            skull.setItemMeta((ItemMeta)i);
            inv.setItem(22, skull);
            p.openInventory(inv);
        }
        return false;
    }
}
