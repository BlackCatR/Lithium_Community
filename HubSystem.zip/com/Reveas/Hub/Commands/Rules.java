package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;

public class Rules implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandlabel, final String[] Args) {
        final Player P = (Player)sender;
        if (cmd.getName().equalsIgnoreCase("Rules")) {
            P.sendMessage("�8�m--------------[ �4Rules �8]�m--------------");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�41�7] �7Don't Advertise Any Server Abd Don't Swear");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�42�7] �7Respect Other Members and Staff's Don't Spam");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�43�7] �7Don't Use Any Hacks Client ,Or Use Any Glitch");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�44�7] �7Team Not Allowed FFA");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�45�7] �7Don't Target Players");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�46�7] �7Don't Ask For Any Ranks ");
            P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7[�47�7] �7Don't say respect ");
            P.sendMessage("�8�m-------------------------------------------");
        }
        return false;
    }
}
