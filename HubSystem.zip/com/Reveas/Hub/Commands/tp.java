package com.Reveas.Hub.Commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;

public class tp implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player player = (Player)sender;
        if (player.hasPermission("tp")) {
            if (args.length == 1) {
                final String targetname = args[0];
                final Player target = Bukkit.getPlayer(targetname);
                if (Bukkit.getPlayer(targetname) != null) {
                    player.teleport(target.getLocation());
                    player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aYou were teleported to �6" + targetname);
                    player.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1.0f, 1.0f);
                }
                else {
                    player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�cThis player is not online");
                    player.playSound(player.getLocation(), Sound.ANVIL_BREAK, 1.0f, 1.0f);
                }
            }
            else if (args.length == 2) {
                final String teleportedname = args[0];
                final Player teleported = Bukkit.getPlayer(teleportedname);
                final String targetname2 = args[1];
                final Player target2 = Bukkit.getPlayer(targetname2);
                if (Bukkit.getPlayer(targetname2) != null || Bukkit.getPlayer(teleportedname) != null) {
                    teleported.teleport(target2.getLocation());
                    player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aYou were teleported to �6" + targetname2);
                    teleported.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1.0f, 1.0f);
                    player.playSound(player.getLocation(), Sound.ENDERMAN_TELEPORT, 1.0f, 1.0f);
                }
                else {
                    player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�cThis player is not online " + target2);
                    player.playSound(player.getLocation(), Sound.ANVIL_BREAK, 1.0f, 1.0f);
                }
            }
            else {
                player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�aUsage: /tp [player] [target]");
            }
        }
        else {
            player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�cYou do not have permission to execute this command.");
        }
        return true;
    }
}
