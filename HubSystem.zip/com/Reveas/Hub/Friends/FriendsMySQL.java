package com.Reveas.Hub.Friends;

import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import java.io.*;
import org.bukkit.configuration.file.*;
import java.sql.*;

public class FriendsMySQL
{
    private Main friends;
    private static String pr;
    private static String HOST;
    private static String DATABASE;
    private static String USER;
    private static String PASSWORD;
    private static String PORT;
    private static Connection con;
    private boolean ic;
    
    static {
        FriendsMySQL.pr = "�eRM�8> ";
        FriendsMySQL.HOST = "localhost";
        FriendsMySQL.DATABASE = "ReveasSystem";
        FriendsMySQL.USER = "ReveasSystem";
        FriendsMySQL.PASSWORD = "13";
        FriendsMySQL.PORT = "3306";
    }
    
    public FriendsMySQL(final Main friends) {
        this.friends = friends;
    }
    
    public boolean isConnected() {
        return this.ic;
    }
    
    public void createMySQLFile(final String path) {
        this.friends.getAPI().createNewFile("mysql.yml", path);
        final File f = this.friends.getAPI().getFile("mysql.yml", path);
        final FileConfiguration cfg = this.friends.getAPI().getConfiguration("mysql.yml", path);
        cfg.options().copyDefaults(true);
        cfg.addDefault("username", (Object)"ReveasSystem");
        cfg.addDefault("password", (Object)"13");
        cfg.addDefault("database", (Object)"ReveasSystem");
        cfg.addDefault("host", (Object)"localhost");
        cfg.addDefault("port", (Object)"3306");
        try {
            cfg.save(f);
        }
        catch (IOException e) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�cCould not save file 'mysql.yml'.");
        }
        FriendsMySQL.USER = cfg.getString("username");
        FriendsMySQL.PASSWORD = cfg.getString("password");
        FriendsMySQL.DATABASE = cfg.getString("database");
        FriendsMySQL.HOST = cfg.getString("host");
        FriendsMySQL.PORT = cfg.getString("port");
        this.connect();
    }
    
    public void connect() {
        try {
            FriendsMySQL.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ReveasSystem?autoReconnect=true", "ReveasSystem", "13");
            Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�aSuccessfully connected to MySQL-Database.");
            this.ic = true;
        }
        catch (SQLException e) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�cCould not connect to MySQL-Database, please check your MySQL-Settings.");
            this.ic = false;
        }
    }
    
    public void close() {
        try {
            if (FriendsMySQL.con != null) {
                FriendsMySQL.con.close();
                Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�aSuccessfully closed MySQL-Connection.");
                this.ic = false;
            }
            else {
                Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�cThere is no running connection to MySQL-Database.");
            }
        }
        catch (SQLException e) {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(FriendsMySQL.pr))) + "�cCould not close MySQL-Connection, ERROR-CODE: " + e.getMessage());
        }
    }
    
    public void update(final String qry) {
        try {
            final Statement st = FriendsMySQL.con.createStatement();
            st.executeUpdate(qry);
            st.close();
        }
        catch (SQLException e) {
            System.err.println(e);
        }
    }
    
    public ResultSet getResult(final String qry) {
        ResultSet rs = null;
        try {
            final Statement st = FriendsMySQL.con.createStatement();
            rs = st.executeQuery(qry);
        }
        catch (SQLException e) {
            System.err.println(e);
        }
        return rs;
    }
}
