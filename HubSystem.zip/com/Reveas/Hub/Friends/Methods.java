package com.Reveas.Hub.Friends;

import com.Reveas.Hub.Main.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import java.util.*;
import java.sql.*;

public class Methods implements Listener
{
    public static Main friends;
    public static HashMap<String, Integer> pageindex;
    
    public Methods(final Main friends) {
        Methods.pageindex = new HashMap<String, Integer>();
        Methods.friends = friends;
    }
    
    @EventHandler
    public void onClickInventory(final InventoryClickEvent event, final int page) {
        final Player player = (Player)event.getWhoClicked();
        if (event.getCurrentItem().getType() == Material.SKULL_ITEM && event.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7Next �")) {
            loadFriends(player, 0, 36);
        }
    }
    
    public static void loadFriendInventory(final Player player, final int page) {
        List<String> friendlist;
        if (page == 1) {
            friendlist = loadFriends(player, 0, 36);
        }
        else {
            friendlist = loadFriends(player, (page - 1) * 36 + 1, page * 36);
        }
        Methods.pageindex.put(player.getName(), page);
        final Inventory inventory = Bukkit.createInventory((InventoryHolder)null, 36, "�8� �6Friends");
        for (int fs = 0; fs < 36; ++fs) {
            if (fs >= friendlist.size()) {
                inventory.setItem(fs, new ItemStack(Material.AIR));
            }
            else {
                final String friend = friendlist.get(fs);
                final ItemStack item = Methods.friends.getAPI().createHead(friend, null, "�9" + friend);
                final ItemMeta itemmeta = item.getItemMeta();
                final ArrayList<String> lore = new ArrayList<String>();
                Main.getFriendManager();
                if (getSetting(friend, "FcOnline")) {
                    lore.add("�a\u2714 �8\u258e �7Online �8� �e" + get(friend, "Name", "FServer", "cFriends_Users"));
                    itemmeta.setDisplayName("�9" + friend);
                    itemmeta.setLore((List)lore);
                }
                else {
                    lore.add("�4\u2716 �8\u258e �7Last Online �8� �e" + getLastTimeOnline((long)get(friend, "Name", "FConnect", "cFriends_Users")));
                    itemmeta.setDisplayName("�9" + friend);
                    itemmeta.setLore((List)lore);
                }
                item.setItemMeta(itemmeta);
                inventory.setItem(fs, item);
            }
        }
        if (page != 1) {
            inventory.setItem(27, Methods.friends.getAPI().createHead("MHF_ArrowLeft", null, "�7� Back"));
        }
        else {
            inventory.setItem(35, Methods.friends.getAPI().createHead("MHF_Question", null, "�c"));
        }
        inventory.setItem(29, Methods.friends.getAPI().createItemwithMaterial(Material.NETHER_STAR, 0, 1, "�cSettings", null));
        final ArrayList<String> lore2 = new ArrayList<String>();
        final int size = getFriends(player.getName());
        if (size == 1) {
            lore2.add("�7You currently have �e1 �7friend!");
        }
        else {
            lore2.add("�7You currently have �e" + size + " �7friends!");
        }
        inventory.setItem(31, Methods.friends.getAPI().createHead(player.getName(), lore2, "�9" + player.getName()));
        inventory.setItem(33, Methods.friends.getAPI().createItemwithMaterial(Material.PAPER, 0, 1, "�eRequests �7\u00d7 " + getRequests(player.getName()) + " \u00d7", null));
        inventory.setItem(35, Methods.friends.getAPI().createHead("MHF_ArrowRight", null, "�7Next �"));
        player.openInventory(inventory);
    }
    
    public static List<String> loadFriends(final Player player, final int from, final int to) {
        final HashMap<String, List<String>> f = getList(player.getName());
        final List<String> friendlist = combine(f.get("online"), f.get("offline"));
        final List<String> toreturn = new ArrayList<String>();
        for (int i = from; i < to; ++i) {
            if (friendlist.size() > i) {
                toreturn.add(friendlist.get(i));
            }
        }
        return toreturn;
    }
    
    public void loadRequestInventory(final Player player) {
        final Inventory inventory = Bukkit.createInventory((InventoryHolder)null, 36, "�9Requests �7[" + getRequests(player.getName()) + "]");
        for (final String request : this.getRequestList(player.getName())) {
            final String name = getNamebyUUID(request, "cFriends_Users");
            final ArrayList<String> lore = new ArrayList<String>();
            lore.add("�7What do you want to do?");
            lore.add("�8- �7Request Accept �7(left click)");
            lore.add("�8- �7Deny Request �7(Right Click)");
            inventory.addItem(new ItemStack[] { Methods.friends.getAPI().createHead(name, lore, "�9" + name) });
        }
        inventory.setItem(27, Methods.friends.getAPI().createItemwithMaterial(Material.NETHER_STAR, 0, 1, "�cSettings", null));
        inventory.setItem(30, Methods.friends.getAPI().createItemwithID(159, 14, 1, "�cDeny all", null));
        final ArrayList<String> lore2 = new ArrayList<String>();
        final int size = getRequests(player.getName());
        if (size == 1) {
            lore2.add("�7You currently have �e1 �7Friend request!");
        }
        else {
            lore2.add("�7You currently have �e" + size + " �7Friend request!");
        }
        inventory.setItem(35, Methods.friends.getAPI().createHead("MHF_ArrowLeft", null, "�7Back �"));
        inventory.setItem(31, Methods.friends.getAPI().createHead(player.getName(), lore2, "�9" + player.getName()));
        inventory.setItem(32, Methods.friends.getAPI().createItemwithID(159, 13, 1, "�aAccept all", null));
        player.openInventory(inventory);
    }
    
    public static void loadSettingsInventory(final Player player) {
        final Inventory inventory = Bukkit.createInventory((InventoryHolder)null, 36, "�9Settings");
        final ArrayList<String> lr = new ArrayList<String>();
        lr.add("�7Make a choice if you have a friend request");
        final ItemStack request = Methods.friends.getAPI().createItemwithMaterial(Material.PAPER, 0, 1, "�9Friend requests", null);
        inventory.setItem(12, request);
        final ArrayList<String> lj = new ArrayList<String>();
        lj.add("�7Make sure your friends can jump to you.");
        final ItemStack jump = Methods.friends.getAPI().createItemwithMaterial(Material.IRON_PLATE, 0, 1, "�9Jump to you", null);
        inventory.setItem(13, jump);
        final ArrayList<String> ln = new ArrayList<String>();
        ln.add("�7Check if you are online or offline");
        ln.add("�7Receive messages.");
        final ItemStack online = Methods.friends.getAPI().createItemwithMaterial(Material.BOOK, 0, 1, "�9Online / offline messages", null);
        inventory.setItem(14, online);
        final ArrayList<String> ls = new ArrayList<String>();
        ls.add("�7Do you want to have server changes messages ?");
        final ItemStack serverswitch = Methods.friends.getAPI().createItemwithMaterial(Material.COMPASS, 0, 1, "�9Server switching messages", null);
        inventory.setItem(11, serverswitch);
        final boolean rq = getSetting(player.getName(), "FRequest");
        final boolean jmp = getSetting(player.getName(), "FJump");
        final boolean onl = getSetting(player.getName(), "FOnline");
        final boolean swtch = getSetting(player.getName(), "FSwitch");
        inventory.setItem(20, Methods.friends.getAPI().createItemwithID(159, rq ? 13 : 14, 1, rq ? "�a" : "�c", lr));
        inventory.setItem(21, Methods.friends.getAPI().createItemwithID(159, jmp ? 13 : 14, 1, jmp ? "�a" : "�c", lj));
        inventory.setItem(22, Methods.friends.getAPI().createItemwithID(159, onl ? 13 : 14, 1, onl ? "�a" : "�c", ln));
        inventory.setItem(23, Methods.friends.getAPI().createItemwithID(159, swtch ? 13 : 14, 1, swtch ? "�a" : "�c", ls));
        inventory.setItem(27, Methods.friends.getAPI().createHead(player.getName(), null, "�9" + player.getName() + "'s Settings"));
        inventory.setItem(35, Methods.friends.getAPI().createHead("MHF_ArrowLeft", null, "�7� Back"));
        player.openInventory(inventory);
    }
    
    public static String getLastTimeOnline(final long endmillis) {
        final long current = System.currentTimeMillis();
        long millis = current - endmillis;
        long seconds = 0L;
        long minutes = 0L;
        long hours = 0L;
        long days = 0L;
        long weeks = 0L;
        long months = 0L;
        long years = 0L;
        while (millis > 1000L) {
            millis -= 1000L;
            ++seconds;
        }
        while (seconds > 60L) {
            seconds -= 60L;
            ++minutes;
        }
        while (minutes > 60L) {
            minutes -= 60L;
            ++hours;
        }
        while (hours > 24L) {
            hours -= 24L;
            ++days;
        }
        while (days > 7L) {
            days -= 7L;
            ++weeks;
        }
        while (weeks > 4L) {
            weeks -= 4L;
            ++months;
        }
        while (months > 12L) {
            months -= 12L;
            ++years;
        }
        if (years != 0L) {
            if (years == 1L) {
                return "�e1 Year";
            }
            return "�e" + years + " Years";
        }
        else if (months != 0L) {
            if (months == 1L) {
                return "�e1 Month";
            }
            return "�e" + months + " Months";
        }
        else if (weeks != 0L) {
            if (weeks == 1L) {
                return "�e1 Week";
            }
            return "�e" + weeks + " Weeks";
        }
        else if (days != 0L) {
            if (days == 1L) {
                return "�e1 Day";
            }
            return "�e" + days + " Days";
        }
        else if (hours != 0L) {
            if (hours == 1L) {
                return "�e1 Hour";
            }
            return "�e" + hours + " Hours";
        }
        else if (minutes != 0L) {
            if (minutes == 1L) {
                return "�e1 Minute";
            }
            return "�e" + minutes + " Minutes";
        }
        else {
            if (seconds == 0L) {
                return "�cERROR CALCULATING DATA";
            }
            if (seconds == 1L) {
                return "�e1 Second";
            }
            return "�e" + seconds + " Seconds";
        }
    }
    
    public static ArrayList<String> combine(final List<String> first, final List<String> second) {
        final ArrayList<String> toreturn = new ArrayList<String>();
        for (final String entry : first) {
            toreturn.add(entry);
        }
        for (final String entry : second) {
            toreturn.add(entry);
        }
        return toreturn;
    }
    
    public int getPage(final Player player) {
        return Methods.pageindex.get(player.getName());
    }
    
    public static boolean getSetting(final String name, final String type) {
        return Boolean.valueOf(String.valueOf(get(name, "Name", type, "cFriends_Users")));
    }
    
    public void setSetting(final String name, final String type, final String value) {
        Main.getMySQL().update("UPDATE cFriends_Users SET " + type + "='" + value + "' WHERE Name='" + name + "'");
    }
    
    public static HashMap<String, List<String>> getList(final String name) {
        final List<String> friendlist = getFriendList(name);
        final List<String> fl = new ArrayList<String>();
        for (final String uuid : friendlist) {
            fl.add(getNamebyUUID(uuid, "cFriends_Users"));
        }
        final List<String> offline = new ArrayList<String>();
        final List<String> online = new ArrayList<String>();
        for (final String entry : fl) {
            if (Bukkit.getPlayer(entry) != null) {
                online.add(entry);
            }
            else {
                offline.add(entry);
            }
        }
        Collections.sort(offline);
        Collections.sort(online);
        final HashMap<String, List<String>> hash = new HashMap<String, List<String>>();
        hash.put("offline", offline);
        hash.put("online", online);
        return hash;
    }
    
    public static String getFriendListRAW(final String name) {
        return String.valueOf(get(name, "Name", "FList", "cFriends_Users"));
    }
    
    public static List<String> getFriendList(final String name) {
        final String friendlist = getFriendListRAW(name);
        final List<String> toreturn = new ArrayList<String>();
        if (friendlist.isEmpty()) {
            return toreturn;
        }
        final String[] friends = friendlist.split(";");
        for (int i = 0; i < friends.length; ++i) {
            toreturn.add(friends[i]);
        }
        return toreturn;
    }
    
    public static int getFriends(final String name) {
        final String friendlist = getFriendListRAW(name);
        if (friendlist.isEmpty()) {
            return 0;
        }
        final String[] friends = friendlist.split(";");
        return friends.length;
    }
    
    public static String getRequestListRAW(final String name) {
        return String.valueOf(get(name, "Name", "FRequests", "cFriends_Users"));
    }
    
    public List<String> getRequestList(final String name) {
        final String requestlist = getRequestListRAW(name);
        final List<String> toreturn = new ArrayList<String>();
        if (requestlist.isEmpty()) {
            return toreturn;
        }
        final String[] req = requestlist.split(";");
        for (int i = 0; i < req.length; ++i) {
            toreturn.add(req[i]);
        }
        return toreturn;
    }
    
    public static int getRequests(final String name) {
        final String requestlist = getRequestListRAW(name);
        if (requestlist.isEmpty()) {
            return 0;
        }
        final String[] req = requestlist.split(";");
        return req.length;
    }
    
    public String getUUIDbyName(final String playername, final String database) {
        String i = "";
        try {
            final ResultSet rs = Main.getMySQL().getResult("SELECT * FROM " + database + " WHERE Name= '" + playername + "'");
            if (rs.next()) {
                String.valueOf(rs.getString("UUID"));
            }
            i = rs.getString("UUID");
        }
        catch (SQLException ex) {}
        return i;
    }
    
    public static String getNamebyUUID(final String playername, final String database) {
        String i = "";
        try {
            final ResultSet rs = Main.getMySQL().getResult("SELECT * FROM " + database + " WHERE UUID= '" + playername + "'");
            if (rs.next()) {
                String.valueOf(rs.getString("Name"));
            }
            i = rs.getString("Name");
        }
        catch (SQLException ex) {}
        return i;
    }
    
    public static Object get(final String whereresult, final String where, final String select, final String database) {
        final ResultSet rs = Main.getMySQL().getResult("SELECT " + select + " FROM " + database + " WHERE " + where + "='" + whereresult + "'");
        try {
            if (rs.next()) {
                final Object v = rs.getObject(select);
                return v;
            }
        }
        catch (SQLException e) {
            return "ERROR";
        }
        return "ERROR";
    }
}
