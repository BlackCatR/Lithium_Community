package com.Reveas.Hub.Friends;

import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import java.util.*;
import java.sql.*;

public class TheMySQLClass
{
    public boolean getSetting(final String name, final String type) {
        return Boolean.valueOf(String.valueOf(this.get(name, "Name", type, "cFriends_Users")));
    }
    
    public void setSetting(final String name, final String type, final String value) {
        Main.getMySQL().update("UPDATE cFriends_Users SET " + type + "='" + value + "' WHERE Name='" + name + "'");
    }
    
    public HashMap<String, List<String>> getList(final String name) {
        final List<String> friendlist = this.getFriendList(name);
        final List<String> fl = new ArrayList<String>();
        for (final String uuid : friendlist) {
            fl.add(this.getNamebyUUID(uuid, "cFriends_Users"));
        }
        final List<String> offline = new ArrayList<String>();
        final List<String> online = new ArrayList<String>();
        for (final String entry : fl) {
            if (Bukkit.getPlayer(entry) != null) {
                online.add(entry);
            }
            else {
                offline.add(entry);
            }
        }
        Collections.sort(offline);
        Collections.sort(online);
        final HashMap<String, List<String>> hash = new HashMap<String, List<String>>();
        hash.put("offline", offline);
        hash.put("online", online);
        return hash;
    }
    
    public String getFriendListRAW(final String name) {
        return String.valueOf(this.get(name, "Name", "FList", "cFriends_Users"));
    }
    
    public List<String> getFriendList(final String name) {
        final String friendlist = this.getFriendListRAW(name);
        final List<String> toreturn = new ArrayList<String>();
        if (friendlist.isEmpty()) {
            return toreturn;
        }
        final String[] friends = friendlist.split(";");
        for (int i = 0; i < friends.length; ++i) {
            toreturn.add(friends[i]);
        }
        return toreturn;
    }
    
    public int getFriends(final String name) {
        final String friendlist = this.getFriendListRAW(name);
        if (friendlist.isEmpty()) {
            return 0;
        }
        final String[] friends = friendlist.split(";");
        return friends.length;
    }
    
    public String getRequestListRAW(final String name) {
        return String.valueOf(this.get(name, "Name", "FRequests", "cFriends_Users"));
    }
    
    public List<String> getRequestList(final String name) {
        final String requestlist = this.getRequestListRAW(name);
        final List<String> toreturn = new ArrayList<String>();
        if (requestlist.isEmpty()) {
            return toreturn;
        }
        final String[] req = requestlist.split(";");
        for (int i = 0; i < req.length; ++i) {
            toreturn.add(req[i]);
        }
        return toreturn;
    }
    
    public int getRequests(final String name) {
        final String requestlist = this.getRequestListRAW(name);
        if (requestlist.isEmpty()) {
            return 0;
        }
        final String[] req = requestlist.split(";");
        return req.length;
    }
    
    public String getUUIDbyName(final String playername, final String database) {
        String i = "";
        try {
            final ResultSet rs = Main.getMySQL().getResult("SELECT * FROM " + database + " WHERE Name= '" + playername + "'");
            if (rs.next()) {
                String.valueOf(rs.getString("UUID"));
            }
            i = rs.getString("UUID");
        }
        catch (SQLException ex) {}
        return i;
    }
    
    public String getNamebyUUID(final String playername, final String database) {
        String i = "";
        try {
            final ResultSet rs = Main.getMySQL().getResult("SELECT * FROM " + database + " WHERE UUID= '" + playername + "'");
            if (rs.next()) {
                String.valueOf(rs.getString("Name"));
            }
            i = rs.getString("Name");
        }
        catch (SQLException ex) {}
        return i;
    }
    
    public Object get(final String whereresult, final String where, final String select, final String database) {
        final ResultSet rs = Main.getMySQL().getResult("SELECT " + select + " FROM " + database + " WHERE " + where + "='" + whereresult + "'");
        try {
            if (rs.next()) {
                final Object v = rs.getObject(select);
                return v;
            }
        }
        catch (SQLException e) {
            return "ERROR";
        }
        return "ERROR";
    }
}
