package com.Reveas.Hub.Gadgets;

import org.bukkit.entity.*;
import java.util.*;
import com.Reveas.Hub.Utils.*;

public class Data
{
    String prefix;
    String noPlayer;
    String noPerms;
    String nogePrefix;
    String nogeNoPerms;
    String nogeNoPlayer;
    String getJoinMessage;
    String getNogeJoinMessage;
    boolean getJoinEnable;
    String getLeaveMessage;
    String getNogeLeaveMessage;
    boolean getLeaveEnable;
    String Title;
    String nogeTitle;
    boolean TitleEnable;
    public static ArrayList<Player> bloodhelx;
    public static ArrayList<Player> silent;
    public static ArrayList<Player> hearth;
    public static ArrayList<Player> flame;
    public static ArrayList<Player> smoke;
    public static ArrayList<Player> telekom;
    public static ArrayList<Player> water;
    public static ArrayList<Player> EmeraldAura;
    public static ArrayList<Player> lava;
    public static ArrayList<Player> build;
    public static HashMap<UUID, BallonFunc> ballon;
    
    static {
        Data.bloodhelx = new ArrayList<Player>();
        Data.EmeraldAura = new ArrayList<Player>();
        Data.silent = new ArrayList<Player>();
        Data.hearth = new ArrayList<Player>();
        Data.flame = new ArrayList<Player>();
        Data.smoke = new ArrayList<Player>();
        Data.telekom = new ArrayList<Player>();
        Data.water = new ArrayList<Player>();
        Data.lava = new ArrayList<Player>();
        Data.build = new ArrayList<Player>();
        Data.ballon = new HashMap<UUID, BallonFunc>();
    }
    
    public static void removeFromAllArrays(final Player p) {
        Data.hearth.remove(p);
        Data.flame.remove(p);
        Data.smoke.remove(p);
        Data.telekom.remove(p);
        Data.water.remove(p);
        Data.lava.remove(p);
    }
    
    public void setNoPerms(final String noPerms) {
        this.noPerms = noPerms;
    }
    
    public void setNoPlayer(final String noPlayer) {
        this.noPlayer = noPlayer;
    }
    
    public void setPrefix(final String prefix) {
        this.prefix = prefix;
    }
    
    public void setNogePrefix(final String nogePrefix) {
        this.nogePrefix = nogePrefix;
    }
    
    public void setNogeNoPlayer(final String nogeNoPlayer) {
        this.nogeNoPlayer = nogeNoPlayer;
    }
    
    public void setNogeNoPerms(final String nogeNoPerms) {
        this.nogeNoPerms = nogeNoPerms;
    }
    
    public void setGetLeaveMessage(final String getLeaveMessage) {
        this.getLeaveMessage = getLeaveMessage;
    }
    
    public void setGetLeaveEnable(final boolean getLeaveEnable) {
        this.getLeaveEnable = getLeaveEnable;
    }
    
    public void setGetJoinMessage(final String getJoinMessage) {
        this.getJoinMessage = getJoinMessage;
    }
    
    public void setGetJoinEnable(final boolean getJoinEnable) {
        this.getJoinEnable = getJoinEnable;
    }
    
    public void setGetNogeLeaveMessage(final String getNogeLeaveMessage) {
        this.getNogeLeaveMessage = getNogeLeaveMessage;
    }
    
    public void setGetNogeJoinMessage(final String getNogeJoinMessage) {
        this.getNogeJoinMessage = getNogeJoinMessage;
    }
    
    public void setNogeTitle(final String nogeTitle) {
        this.nogeTitle = nogeTitle;
    }
    
    public void setTitle(final String title) {
        this.Title = title;
    }
    
    public void setTitleEnable(final boolean titleEnable) {
        this.TitleEnable = titleEnable;
    }
}
