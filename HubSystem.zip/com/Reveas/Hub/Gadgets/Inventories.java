package com.Reveas.Hub.Gadgets;

import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.inventory.*;
import com.Reveas.Hub.API.*;
import org.bukkit.*;
import org.bukkit.plugin.*;

public class Inventories
{
    public static void openGadgets(final Player player) {
        final Inventory gadgets = Bukkit.createInventory((InventoryHolder)null, 9, "�7[RM] This your fun gadgets");
        Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
            @Override
            public void run() {
                gadgets.setItem(0, ItemUtils.getItem(Material.ENDER_PEARL, "�bEnderpearl �8\u2014 �7Ender-Gadget", "�7Teleport yourself\n�7Across the lobby!", 0, 1));
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        gadgets.setItem(1, ItemUtils.getItem(Material.SLIME_BALL, "�bJumpBoost �8\u2014 �7Rabbit-Gadget", "�7Jump with it\n �7Through the lobby!", 0, 1));
                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                        Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                gadgets.setItem(2, ItemUtils.getItem(Material.BLAZE_ROD, "�6FunGun �8\u2014 �7HaveFun-Gadget", "�7You want to frighten your fellow players times? \n�7 Then this item is the right thing for you!", 0, 1));
                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                    @Override
                                    public void run() {
                                        gadgets.setItem(3, ItemUtils.getItem(Material.SNOW_BALL, "�f�lSnowball �8\u2014 �7Christmas-Gadget", "�7More than the normal Vanilla Snowball", 0, 1));
                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                        Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                            @Override
                                            public void run() {
                                                gadgets.setItem(8, ItemUtils.getItem(Material.BARRIER, "�cRemove!", "�7 \n �7Click to equip", 0, 1));
                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                            }
                                        }, 3L);
                                    }
                                }, 3L);
                            }
                        }, 3L);
                    }
                }, 3L);
            }
        }, 3L);
        player.openInventory(gadgets);
    }
}
