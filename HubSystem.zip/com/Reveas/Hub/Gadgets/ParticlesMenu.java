package com.Reveas.Hub.Gadgets;

import org.bukkit.inventory.meta.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.Reveas.Hub.API.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.util.*;
import org.bukkit.inventory.*;
import org.bukkit.event.*;
import com.yapzhenyie.GadgetsMenu.cosmetics.particles.*;

public class ParticlesMenu implements Listener
{
    public static ItemStack a(final Material a, final String b) {
        final ItemStack i = new ItemStack(a);
        final ItemMeta m = i.getItemMeta();
        m.setDisplayName(b);
        i.setItemMeta(m);
        return i;
    }
    
    @EventHandler
    public void is(final InventoryClickEvent e) {
        final ItemStack Item = e.getCurrentItem();
        final Player p = (Player)e.getWhoClicked();
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �5Particles") && Item.getType().equals((Object)Material.MAGMA_CREAM)) {
            final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 45, "[RM] Select a Particles");
            final ItemStack Exit = ItemUtils.getItem(Material.ARROW, "�cBack!", "", 0, 1);
            final ItemStack Store = ItemUtils.getItem(Material.BOOK, "�8� �a�lStore", "", 0, 1);
            final com.Reveas.Hub.Main.Player RS = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
            final ItemStack Remove = ItemUtils.getItem(Material.BARRIER, Main.F("&8� &c&l\u2716 &4Remove &8�"), "", 0, 1);
            if (RS.checkPermission(e.getWhoClicked().getName(), Rank.GOLD)) {
                inv.addItem(new ItemStack[] { a(Material.EMERALD, "�a�lGreen") });
                inv.addItem(new ItemStack[] { a(Material.EYE_OF_ENDER, "�a�lEnder") });
                inv.addItem(new ItemStack[] { a(Material.CLAY_BALL, "�d�lWitch") });
            }
            if (RS.checkPermission(e.getWhoClicked().getName(), Rank.DIAMOND)) {
                inv.addItem(new ItemStack[] { a(Material.MAGMA_CREAM, "�5�lMagic") });
                inv.addItem(new ItemStack[] { a(Material.COAL, "�8�lAngry") });
                inv.addItem(new ItemStack[] { a(Material.NETHER_STAR, "�7�lSpark") });
                inv.addItem(new ItemStack[] { a(Material.BLAZE_POWDER, "�c�lFlame") });
                inv.addItem(new ItemStack[] { a(Material.REDSTONE, "�c�lHeart") });
            }
            if (RS.checkPermission(e.getWhoClicked().getName(), Rank.EMERALD)) {
                inv.addItem(new ItemStack[] { a(Material.JUKEBOX, "�5Music") });
                inv.addItem(new ItemStack[] { a(Material.FIREWORK_CHARGE, "�8Smoke") });
                inv.addItem(new ItemStack[] { a(Material.FIREWORK, "�aW�ba�cv�de�a") });
                inv.addItem(new ItemStack[] { a(Material.BAKED_POTATO, "�2�lDNA") });
                inv.addItem(new ItemStack[] { a(Material.WATER_BUCKET, "�1�lWater") });
                inv.addItem(new ItemStack[] { a(Material.LAVA_BUCKET, "�4�lLava") });
                inv.addItem(new ItemStack[] { a(Material.CARROT_ITEM, "�3�lCrit") });
            }
            inv.setItem(40, Remove);
            inv.setItem(44, Exit);
            inv.setItem(36, Store);
            ((Player)e.getWhoClicked()).openInventory(inv);
        }
    }
    
    @EventHandler
    public void inv(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getTitle().equals("[RM] Select a Particles")) {
            e.setCancelled(true);
            if (e.getSlot() == 40) {
                ParticleManager.unequipParticle(p);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully remove particles &a&l"));
                Main.Particles.remove(p.getName());
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�3�lCrit")) {
                ParticleManager.equipParticle(p, ParticleType.CRIT);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Crit");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4�lLava")) {
                ParticleManager.equipParticle(p, ParticleType.DRIP_LAVA);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Lava");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�1�lWater")) {
                ParticleManager.equipParticle(p, ParticleType.WATER_SPLASH);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Water");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�a�lGreen")) {
                ParticleManager.equipParticle(p, ParticleType.SLIME);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Green");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�a�lEnder")) {
                ParticleManager.equipParticle(p, ParticleType.PORTAL);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Ender");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�d�lWitch")) {
                ParticleManager.equipParticle(p, ParticleType.SPELL_WITCH);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Witch");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�5�lMagic")) {
                ParticleManager.equipParticle(p, ParticleType.CRIT_MAGIC);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Magic");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8�lAngry")) {
                ParticleManager.equipParticle(p, ParticleType.VILLAGER_ANGRY);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Angry");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7�lSpark")) {
                ParticleManager.equipParticle(p, ParticleType.FIREWORKS_SPARK);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Spark");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�c�lFlame")) {
                ParticleManager.equipParticle(p, ParticleType.FLAME);
                Main.Particles.put(p.getName(), "Flame");
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�c�lHeart")) {
                ParticleManager.equipParticle(p, ParticleType.HEART);
                Main.Particles.put(p.getName(), "Love");
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8Smoke")) {
                ParticleManager.equipParticle(p, ParticleType.SMOKE_NORMAL);
                Main.Particles.put(p.getName(), "Smoke");
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�aW�ba�cv�de�a")) {
                ParticleManager.equipParticle(p, ParticleType.TOWN_AURA);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "Wave");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�2�lDNA")) {
                ParticleManager.equipParticle(p, ParticleType.REDSTONE);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "dna");
                p.closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�5Music")) {
                ParticleManager.equipParticle(p, ParticleType.NOTE);
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou have successfully Particle &a&l" + e.getCurrentItem().getItemMeta().getDisplayName()));
                Main.Particles.put(p.getName(), "music");
                p.closeInventory();
            }
        }
    }
}
