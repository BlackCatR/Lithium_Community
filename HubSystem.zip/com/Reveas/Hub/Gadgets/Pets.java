package com.Reveas.Hub.Gadgets;

import org.bukkit.inventory.*;
import org.bukkit.*;
import com.Reveas.Hub.API.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.event.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import com.Reveas.Hub.Utils.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import org.bukkit.event.inventory.*;
import com.dsh105.echopet.api.*;
import com.dsh105.echopet.compat.api.entity.*;
import com.dsh105.echopet.api.pet.type.*;
import com.Reveas.api.util.*;

public class Pets implements Listener
{
    private static ItemStack cat;
    private static ItemStack dog;
    private static ItemStack zombie;
    private static ItemStack pigman;
    private static ItemStack skeleton;
    private static ItemStack creeper;
    private static ItemStack rabbit;
    private static ItemStack horse;
    private static ItemStack ender;
    private static ItemStack cavespider;
    private static ItemStack spider;
    private static ItemStack cow;
    private static ItemStack polar;
    private static ItemStack clear;
    public static HashMap<UUID, Entity> Pet;
    private static Inventory inv;
    
    public Pets() {
        Pets.Pet = new HashMap<UUID, Entity>();
    }
    
    public static void Petsinv(final Player p) {
        Pets.inv = Bukkit.getServer().createInventory((InventoryHolder)null, 45, "�7[RM] This your barn pets ");
        final ItemStack Exit = ItemUtils.getItem(Material.ARROW, "�cBack!", "", 0, 1);
        final ItemStack Store = ItemUtils.getItem(Material.BOOK, "�8� �a�lStore", "", 0, 1);
        Pets.inv.setItem(44, Exit);
        Pets.inv.setItem(36, Store);
        final ItemStack NoPerm = ItemUtils.getItem(Material.REDSTONE_BLOCK, "�7You dont have any pets ;(", "", 0, 1);
        Pets.cat = createItem(Material.MONSTER_EGG, (short)98, "�a�lCat Pet");
        Pets.dog = createItem2(Material.MONSTER_EGG, (short)95, "�a�lWolf Pet");
        Pets.zombie = createItem4(Material.MONSTER_EGG, (short)54, "�a�lZombie Pet");
        Pets.pigman = createItem5(Material.MONSTER_EGG, (short)57, "�a�lPigman Pet");
        Pets.skeleton = createItem6(Material.MONSTER_EGG, (short)51, "�a�lSkeleton Pet");
        Pets.creeper = createItem7(Material.MONSTER_EGG, (short)50, "�a�lCreeper Pet");
        Pets.rabbit = createItem8(Material.MONSTER_EGG, (short)101, "�a�lRabbit Pet");
        Pets.horse = createItem9(Material.MONSTER_EGG, (short)100, "�a�lHorse Pet");
        Pets.polar = createItem10(Material.MONSTER_EGG, (short)56, "�a�lBlaze Bear Pet");
        Pets.cow = createItem10(Material.MONSTER_EGG, (short)92, "�a�lCow Pet");
        Pets.ender = createItem10(Material.MONSTER_EGG, (short)58, "�a�lEnder Man Pet");
        Pets.spider = createItem10(Material.MONSTER_EGG, (short)52, "�a�lSpider Pet");
        Pets.cavespider = createItem10(Material.MONSTER_EGG, (short)56, "�a�lCave Spider Pet");
        Pets.clear = createItem3(Material.BARRIER, Main.F("&3"));
        Pets.inv.setItem(40, Pets.clear);
        if (Reveas.getPlayer(p.getName()).getRank() == Rank.MEMBER) {
            Pets.inv.setItem(40, NoPerm);
        }
        else {
            if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.cat });
            }
            if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.dog });
            }
            if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.zombie });
            }
            if (Reveas.checkPermission(p.getName(), Rank.DIAMOND)) {
                Pets.inv.addItem(new ItemStack[] { Pets.pigman });
            }
            if (Reveas.checkPermission(p.getName(), Rank.DIAMOND)) {
                Pets.inv.addItem(new ItemStack[] { Pets.skeleton });
            }
            if (Reveas.checkPermission(p.getName(), Rank.DIAMOND)) {
                Pets.inv.addItem(new ItemStack[] { Pets.creeper });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.rabbit });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.horse });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.polar });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.cavespider });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.spider });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.cow });
            }
            if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                Pets.inv.addItem(new ItemStack[] { Pets.ender });
            }
        }
        p.openInventory(Pets.inv);
    }
    
    @EventHandler
    public void onPlayerClick(final PlayerInteractEvent event) {
        final Player player = event.getPlayer();
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock().getType().equals((Object)Material.ANVIL) && event.getAction().equals((Object)Action.RIGHT_CLICK_BLOCK) && !player.hasPermission("anvilblock.use")) {
            event.setCancelled(true);
            if (event.getClickedBlock().getType().equals((Object)Material.ANVIL) || event.getClickedBlock().getType().equals((Object)Material.CHEST) || event.getClickedBlock().getType().equals((Object)Material.ENDER_CHEST) || event.getClickedBlock().getType().equals((Object)Material.WOOD_DOOR)) {
                event.setCancelled(true);
                player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + Main.F("&c&lYour not allowed open"));
            }
        }
    }
    
    @EventHandler
    public void ondamge2(final EntityDamageEvent e) {
        final EntityDamageEvent.DamageCause cause = e.getCause();
        e.getCause();
        if (cause == EntityDamageEvent.DamageCause.FIRE_TICK) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onFire(final EntityCombustEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onTarget(final EntityTargetEvent e) {
        e.setCancelled(true);
    }
    
    private static ItemStack createItem(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)98);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Cat", "�7�oSpawns a pet Cat!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem2(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)95);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Wolf", "�7�oSpawns a pet Wolf!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem3(final Material mat, final String name) {
        final ItemStack i = new ItemStack(Material.BARRIER, 1);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(ItemUtil.format("&8� &c&l\u2716 &4Remove Pets &8�"));
        meta.setLore((List)Arrays.asList("", null, "�7", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem4(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)54);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Zombie", "�7�oSpawns a pet Zombie!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem5(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)57);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Pigman", "�7�oSpawns a pet Pigman!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem6(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)51);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Skeleton", "�7�oSpawns a pet Skeleton!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem7(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)50);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Creeper", "�7�oSpawns a pet Creeper!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem8(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)101);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Rabbit", "�7�oSpawns a pet Rabbit!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem9(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)100);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Horse", "�7�oSpawns a pet Horse!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem10(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)56);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oPet Blaze", "�7�oSpawns a pet Blaze!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem11(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)56);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oCave Spider Blaze", "�7�oSpawns a pet Cave Spider!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem12(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)56);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oSpider Blaze", "�7�oSpawns a pet Cave Spider!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem13(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)56);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oCow Spider Blaze", "�7�oSpawns a pet Cave Spider!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    private static ItemStack createItem14(final Material mat, final short s, final String name) {
        final ItemStack i = new ItemStack(Material.MONSTER_EGG, 1, (short)56);
        final ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList("", "�a�oEnder Man Blaze", "�7�oSpawns a pet Cave Spider!", ""));
        i.setItemMeta(meta);
        return i;
    }
    
    public void show(final Player p) {
        p.openInventory(Pets.inv);
    }
    
    @EventHandler
    public void onDamage(final EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof Blaze && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Rabbit && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Horse && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Skeleton && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Creeper && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof PigZombie && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Player && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Ocelot && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Wolf && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
        if (e.getEntity() instanceof Zombie && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onInventoryClickEvent(final InventoryClickEvent e) {
        final EchoPetAPI a = EchoPetAPI.getAPI();
        final ReveasPlayer rp = Reveas.getPlayer(((Player)e.getWhoClicked()).getName());
        try {
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Cat Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Cat has been spawned."));
                a.givePet(p, PetType.OCELOT, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Wolf Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Wolf has been spawned."));
                a.givePet(p, PetType.WOLF, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Zombie Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Zombie has been spawned."));
                a.givePet(p, PetType.ZOMBIE, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Pigman Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                final PigPet pigmPet = new PigPet(p);
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Pigman has been spawned."));
                a.givePet(p, PetType.PIGZOMBIE, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Skeleton Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                final SkeletonPet skelPet = new SkeletonPet(p);
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Skeleton has been spawned."));
                a.givePet(p, PetType.SKELETON, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Creeper Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Creeper has been spawned."));
                a.givePet(p, PetType.CREEPER, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Rabbit Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Rabbit has been spawned."));
                a.givePet(p, PetType.RABBIT, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Horse Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Horse has been spawned."));
                a.givePet(p, PetType.HORSE, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Blaze Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Zombie has been spawned."));
                a.givePet(p, PetType.BLAZE, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Spider Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                a.givePet(p, PetType.SPIDER, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Cave Spider Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Cave Spider has been spawned."));
                a.givePet(p, PetType.CAVESPIDER, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Cow Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Cow has been spawned."));
                a.givePet(p, PetType.COW, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Ender Man Pet")) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&aYour pet Ender man has been spawned."));
                a.givePet(p, PetType.ENDERMAN, false).setPetName(String.valueOf(String.valueOf(rp.getRank().getTabPrefix())) + rp.getPlayername() + " �7's Friend");
                e.getWhoClicked().closeInventory();
            }
            if (!e.getInventory().getName().equalsIgnoreCase(Pets.inv.getName())) {
                return;
            }
            if (e.getCurrentItem().getItemMeta() == null) {
                return;
            }
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(ItemUtil.format("&8� &c&l\u2716 &4Remove Pets &8�"))) {
                e.setCancelled(true);
                final Player p = (Player)e.getWhoClicked();
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + ItemUtil.format("&cYour pet has been removed."));
                if (a.hasPet(p)) {
                    a.removePet(p, false, true);
                }
                e.getWhoClicked().closeInventory();
            }
        }
        catch (Exception ex) {}
    }
}
