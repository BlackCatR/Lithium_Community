package com.Reveas.Hub.Gadgets;

import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.block.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.potion.*;
import org.bukkit.plugin.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.*;

public class gadget implements Listener
{
    private ArrayList<String> playersInCooldown;
    
    public gadget() {
        this.playersInCooldown = new ArrayList<String>();
    }
    
    public static ItemStack FunGun() {
        final ItemStack I = new ItemStack(Material.STICK, 1);
        final ItemMeta Im = I.getItemMeta();
        final ArrayList<String> Lore = new ArrayList<String>();
        Im.setDisplayName("�b�lFunGun �8� �dMeowBalls");
        Lore.add("�8\u25ba �7�o(Right-Click) to shoot fun things!");
        Im.setLore((List)Lore);
        I.setItemMeta(Im);
        return I;
    }
    
    public static boolean onItem(final ItemStack I, final String DisplayName, final Material ItemType) {
        return I != null && I.hasItemMeta() && I.getItemMeta().getDisplayName().equalsIgnoreCase(DisplayName) && I.getType() == ItemType;
    }
    
    @EventHandler
    public void onFunGun(final PlayerInteractEvent e) {
        final Player P = e.getPlayer();
        final ItemStack I = P.getItemInHand();
        if ((e.getAction() != Action.RIGHT_CLICK_BLOCK && e.getAction() != Action.RIGHT_CLICK_AIR) || !onItem(I, "�b�lFunGun �8� �dMeowBalls", Material.STICK)) {
            return;
        }
        Main.Gun = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
            @Override
            public void run() {
                P.getInventory().setItem(1, gadget.FunGun());
                P.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 10, 5));
            }
        }, 40L);
        P.getInventory().setItem(1, (ItemStack)null);
        P.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 10, 5));
        P.resetPlayerTime();
        P.resetPlayerWeather();
        final Snowball Snowballs = (Snowball)P.launchProjectile((Class)Snowball.class);
        final EnderPearl EnderPearls = (EnderPearl)P.launchProjectile((Class)EnderPearl.class);
        Snowballs.setVelocity(P.getEyeLocation().getDirection());
        EnderPearls.setVelocity(P.getEyeLocation().getDirection());
        P.playSound(P.getLocation(), Sound.CAT_MEOW, 1.0f, 0.0f);
    }
    
    @EventHandler
    public void projectiles(final ProjectileHitEvent event) {
        final Projectile projectile = event.getEntity();
        if (projectile instanceof Snowball) {
            final Snowball snowball = (Snowball)projectile;
            snowball.getWorld().playSound(snowball.getLocation(), Sound.CAT_MEOW, 2.0f, 1.0f);
            snowball.getWorld().playSound(snowball.getLocation(), Sound.WOLF_BARK, 2.0f, 1.0f);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.POTION_BREAK, 30);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.BLAZE_SHOOT, 10);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.ENDER_SIGNAL, 20);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.EXTINGUISH, 20);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.MOBSPAWNER_FLAMES, 50);
            snowball.getWorld().playEffect(snowball.getLocation(), Effect.ENDER_SIGNAL, 15);
        }
    }
    
    @EventHandler
    public void onTeleport(final PlayerTeleportEvent e) {
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
            e.setCancelled(true);
        }
    }
}
