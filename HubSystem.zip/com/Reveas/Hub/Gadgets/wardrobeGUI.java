package com.Reveas.Hub.Gadgets;

import org.bukkit.entity.*;
import com.Reveas.Hub.API.*;
import com.Reveas.api.util.*;
import org.bukkit.inventory.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.*;

public class wardrobeGUI implements Listener
{
    public static Inventory imbracaminte;
    
    public static void GUI(final Player p) {
        (wardrobeGUI.imbracaminte = Bukkit.createInventory((InventoryHolder)null, 45, "�7[RM] Select a wardrobe")).setItem(0, foc());
        final ItemStack Exit = ItemUtils.getItem(Material.ARROW, "�cBack!", "", 0, 1);
        final ItemStack Store = ItemUtils.getItem(Material.BOOK, "�8� �aStore", "", 0, 1);
        wardrobeGUI.imbracaminte.setItem(0, sa());
        wardrobeGUI.imbracaminte.setItem(36, Exit);
        wardrobeGUI.imbracaminte.setItem(9, Store);
        p.openInventory(wardrobeGUI.imbracaminte);
        final com.Reveas.Hub.Main.Player info = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(10, ca());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(19, pa());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(28, paa());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(37, papa());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(11, cp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(20, pp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(29, pap());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(38, ppp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(12, cr());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(21, pr());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(30, par());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(39, prp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(13, cal());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(22, pal());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(31, paal());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(40, palp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(14, cv());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(23, pv());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(32, pav());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(41, pvp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(15, cvi());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(24, pvi());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(33, pavi());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(42, pvip());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(16, cn());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(25, pn());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(34, pan());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
        if (info.checkPermission(p.getName(), Rank.GOLD)) {
            wardrobeGUI.imbracaminte.setItem(43, pnp());
            p.openInventory(wardrobeGUI.imbracaminte);
        }
    }
    
    @EventHandler
    public void onImbracaminteClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getTitle().equals("�7[RM] Select a wardrobe")) {
            try {
                if (e.getCurrentItem() == null) {
                    return;
                }
                if (e.getCurrentItem().getItemMeta() == null) {
                    return;
                }
                if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�9�lBlue Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(ca());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7You dont have any wardrobe ;(")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.BURP, 1.0f, 1.0f);
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7You dont have any hats ;(")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.BURP, 1.0f, 1.0f);
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�9�lBlue Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pa());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�9�lBlue Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(paa());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�9�lBlue Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(papa());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�6�lOrange Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�6�lOrange Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�6�lOrange Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(pap());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�6�lOrange Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(ppp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�4�lRed Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cr());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�4�lRed Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pr());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�4�lRed Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(par());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�4�lRed Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(prp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�f�lWhite Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cal());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�f�lWhite Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pal());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�f�lWhite Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(paal());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�f�lWhite Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(palp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�2�lGreen Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cv());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�2�lGreen Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pv());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�2�lGreen Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(pav());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�2�lGreen Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(pvp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�5�lPurple Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cvi());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�5�lPurple Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pvi());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�5�lPurple Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(pavi());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�5�lPurple Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(pvip());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7�lBlack Helmet")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setHelmet(cn());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7�lBlack Chestplate")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setChestplate(pn());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7�lBlack Leggings")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setLeggings(pan());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�8� �aStore")) {
                    e.setCancelled(true);
                    p.closeInventory();
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�8� �a�lStore")) {
                    e.setCancelled(true);
                    p.closeInventory();
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�7�lBlack Boots")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setBoots(pnp());
                }
                else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("�3�lRemove Armor")) {
                    e.setCancelled(true);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.FIREWORK_TWINKLE2, 1.0f, 1.0f);
                    p.getInventory().setArmorContents((ItemStack[])null);
                    p.closeInventory();
                }
            }
            catch (Exception ex) {}
        }
    }
    
    public static ItemStack inchidemeniu() {
        final ItemStack is = new ItemStack(Material.ARROW);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�c�lBack!");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack ca() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLUE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�9�lBlue Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pa() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLUE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�9�lBlue Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack paa() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLUE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�9�lBlue Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack papa() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLUE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�9�lBlue Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cp() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.ORANGE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�6�lOrange Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pp() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.ORANGE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�6�lOrange Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pap() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.ORANGE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�6�lOrange Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack ppp() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.ORANGE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�6�lOrange Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cr() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.RED);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�4�lRed Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pr() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.RED);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�4�lRed Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack par() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.RED);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�4�lRed Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack prp() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.RED);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�4�lRed Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cal() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.WHITE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�f�lWhite Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pal() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.WHITE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�f�lWhite Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack paal() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.WHITE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�f�lWhite Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack palp() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.WHITE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�f�lWhite Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cv() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.GREEN);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�2�lGreen Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pv() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.GREEN);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�2�lGreen Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pav() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.GREEN);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�2�lGreen Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pvp() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.GREEN);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�2�lGreen Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cvi() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.PURPLE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�5�lPurple Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pvi() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.PURPLE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�5�lPurple Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pavi() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.PURPLE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�5�lPurple Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pvip() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.PURPLE);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�5�lPurple Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack cn() {
        final ItemStack is = new ItemStack(Material.LEATHER_HELMET);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLACK);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�7�lBlack Helmet");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pn() {
        final ItemStack is = new ItemStack(Material.LEATHER_CHESTPLATE);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLACK);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�7�lBlack Chestplate");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pan() {
        final ItemStack is = new ItemStack(Material.LEATHER_LEGGINGS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLACK);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�7�lBlack Leggings");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack pnp() {
        final ItemStack is = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lam = (LeatherArmorMeta)is.getItemMeta();
        lam.setColor(Color.BLACK);
        is.setItemMeta((ItemMeta)lam);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�7�lBlack Boots");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack foc() {
        final ItemStack is = new ItemStack(Material.ARROW);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�c�lExit");
        is.setItemMeta(im);
        return is;
    }
    
    public static ItemStack sa() {
        final ItemStack is = new ItemStack(Material.REDSTONE_BLOCK);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName("�3�lRemove Armor");
        is.setItemMeta(im);
        return is;
    }
}
