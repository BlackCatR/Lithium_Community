package com.Reveas.Hub.Games;

import java.sql.*;

public class MySQL_FFA
{
    private String HOST;
    private String DATABASE;
    private String USER;
    private String PASSWORD;
    public static Connection con;
    
    public MySQL_FFA(final String host, final String database, final String user, final String password) {
        this.HOST = "";
        this.DATABASE = "";
        this.USER = "";
        this.PASSWORD = "";
        this.HOST = host;
        this.DATABASE = database;
        this.USER = user;
        this.PASSWORD = password;
        this.connect();
    }
    
    public void connect() {
        try {
            MySQL_FFA.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ReveasGames?autoReconnect=true", "ReveasGames", "13");
            System.out.println("[FFAMySQL] Connect to Driver Successfully");
        }
        catch (SQLException ex) {
            System.out.println("[FFAMySQL] Disconnected from Deiver reason :" + ex.getMessage());
        }
    }
    
    public void close() {
        try {
            if (MySQL_FFA.con != null) {
                MySQL_FFA.con.close();
                System.out.println("[FFAMySQL] MySQL was closed.");
            }
        }
        catch (SQLException ex) {
            System.out.println("[FFAMySQL] Erorr while we close MySQL " + ex.getMessage());
        }
    }
    
    public void update(final String s) {
        try {
            final Statement statement = MySQL_FFA.con.createStatement();
            statement.executeUpdate(s);
            statement.close();
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
    }
    
    public ResultSet query(final String s) {
        ResultSet executeQuery = null;
        try {
            executeQuery = MySQL_FFA.con.createStatement().executeQuery(s);
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
        return executeQuery;
    }
}
