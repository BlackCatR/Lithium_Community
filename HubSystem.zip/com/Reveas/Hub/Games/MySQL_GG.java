package com.Reveas.Hub.Games;

import org.bukkit.*;
import java.sql.*;

public class MySQL_GG
{
    public static Connection conn;
    
    public static void connect() {
        if (!isConnected()) {
            try {
                MySQL_GG.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ReveasGames?autoReconnect=true", "ReveasGames", "13");
                Bukkit.getConsoleSender().sendMessage("�8[�6MySQL_GG�8] �aMySQL_GG �a�l+.");
            }
            catch (SQLException e) {
                MySQL_GG.conn = null;
                e.printStackTrace();
            }
        }
    }
    
    public ResultSet query(final String s) {
        ResultSet executeQuery = null;
        try {
            executeQuery = MySQL_GG.conn.createStatement().executeQuery(s);
        }
        catch (SQLException ex) {
            connect();
            System.err.println(ex);
        }
        return executeQuery;
    }
    
    public static void disconnect() {
        if (isConnected()) {
            try {
                MySQL_GG.conn.close();
                Bukkit.getConsoleSender().sendMessage("�8[�6MySQL_GG�8] �c�l-");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean isConnected() {
        return MySQL_GG.conn != null;
    }
    
    public static Connection getConnection() {
        return MySQL_GG.conn;
    }
}
