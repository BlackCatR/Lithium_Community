package com.Reveas.Hub.Games;

import org.bukkit.*;
import com.Reveas.api.*;
import java.sql.*;

public class MySQL_HubSystem
{
    public static Connection con;
    
    public static Connection connect() {
        if (!hasConnection()) {
            try {
                MySQL_HubSystem.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ReveasSystem?autoReconnect=true", "ReveasSystem", "13");
                Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.PREFIX).replaceAll("&", "�"))))))) + "�aSuccessfully connected to MySQL.");
                Bukkit.broadcastMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.PREFIX).replaceAll("&", "�"))))))) + "�aSuccesfully connected to MySQL.�7�o(Tokens)");
            }
            catch (SQLException e) {
                Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.PREFIX).replaceAll("&", "�"))))))) + "�cFailed to connect to MySQL: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return MySQL_HubSystem.con;
    }
    
    public static void close() {
        if (hasConnection()) {
            try {
                if (MySQL_HubSystem.con != null) {
                    MySQL_HubSystem.con.close();
                    Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.PREFIX).replaceAll("&", "�"))))))) + "�cSuccessfully disconnected from MySQL.");
                }
            }
            catch (SQLException e) {
                Bukkit.getConsoleSender().sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.PREFIX).replaceAll("&", "�"))))))) + "�cFailed to disconnect from MySQL: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    private static boolean hasConnection() {
        return MySQL_HubSystem.con != null;
    }
    
    public static void update(final String query) {
        if (hasConnection()) {
            try {
                MySQL_HubSystem.con.prepareStatement(query).executeUpdate();
            }
            catch (SQLException ex) {}
        }
    }
    
    public static ResultSet getResult(final String query) {
        if (hasConnection()) {
            try {
                return MySQL_HubSystem.con.prepareStatement(query).executeQuery();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
    
    public static void createTables() {
        if (hasConnection()) {
            try {
                MySQL_HubSystem.con.createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS Hub(UUID VARCHAR(100), Rank VARCHAR(100), Level int, Tokens int, Credits int, Crystals int, Pets int, Mounts int, Particels int, ToggleRank VARCHAR(64), Scramble VARCHAR(64), PVP VARCHAR(64), SG VARCHAR(64), Creative VARCHAR(64), Package VARCHAR(64), NAME VARCHAR(64) );");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
