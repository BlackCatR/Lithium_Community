package com.Reveas.Hub.Games;

import org.bukkit.plugin.*;
import java.util.concurrent.*;
import java.sql.*;
import java.util.function.*;
import org.bukkit.*;

public class MySQL_OS
{
    private Connection con;
    private ExecutorService executor;
    private Plugin plugin;
    
    public MySQL_OS() {
        this.executor = Executors.newCachedThreadPool();
        this.connect();
    }
    
    public boolean isClosed() {
        return this.con == null;
    }
    
    public boolean isConnected() {
        return this.con != null;
    }
    
    public void connect() {
        try {
            this.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ReveasGames?autoReconnect=true", "ReveasGames", "13");
            System.out.println("�a[OneShot] Connect to Driver Successfully");
        }
        catch (SQLException e) {
            System.out.println("�c[OneShot] Disconnected from Deiver reason :" + e.getMessage());
        }
    }
    
    public void close() {
        try {
            if (this.con != null) {
                this.con.close();
                System.out.println("�a[OneShot] The connect drivr succssfully close!");
            }
        }
        catch (SQLException e) {
            System.out.println("�ac[OneShot] Erorr while we conect to MySQL " + e.getMessage());
        }
    }
    
    public void update(final String qry) {
        try {
            final Statement st = this.con.createStatement();
            st.executeUpdate(qry);
            st.close();
        }
        catch (SQLException e) {
            this.connect();
            System.err.println(e);
        }
    }
    
    public ResultSet query(final String qry) {
        ResultSet rs = null;
        try {
            final Statement st = this.con.createStatement();
            rs = st.executeQuery(qry);
        }
        catch (SQLException e) {
            this.connect();
            System.err.println(e);
        }
        return rs;
    }
    
    public ResultSet Aquery(final String queryA) {
        try {
            return this.queryA(this.con.prepareStatement(queryA));
        }
        catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public ResultSet queryA(final PreparedStatement stat) {
        try {
            return stat.executeQuery();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void Anquery(final String statment, final Consumer<ResultSet> consumer) {
        final ResultSet rs1;
        this.executor.execute(() -> {
            rs1 = this.query(statment);
            Bukkit.getScheduler().runTask(this.plugin, () -> consumer.accept(rs1));
        });
    }
}
