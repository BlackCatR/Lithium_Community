package com.Reveas.Hub.Games;

import java.sql.*;

public class MySQL_SG
{
    private String HOST;
    private String DATABASE;
    private String USER;
    private String PORT;
    private String PASSWORD;
    private Connection con;
    
    public MySQL_SG(final String host, final String database, final String user, final String password) {
        this.HOST = "localhost";
        this.DATABASE = "ReveasGames";
        this.USER = "ReveasGames";
        this.PORT = "3306";
        this.PASSWORD = "13";
        this.connect();
    }
    
    public void connect() {
        try {
            this.con = DriverManager.getConnection("jdbc:mysql://" + this.HOST + ":" + this.PORT + "/" + this.DATABASE + "?autoReconnect=true", this.USER, this.PASSWORD);
            System.out.println("[ReveasSG] Connect to Driver Successfully");
        }
        catch (SQLException ex) {
            System.out.println("[SurvivalGamesMySQL] Disconnected from Deiver reason :" + ex.getMessage());
        }
    }
    
    public boolean isclose() {
        try {
            if (this.con != null) {
                this.con.close();
                System.out.println("[ReveasSQL] Join player.");
            }
        }
        catch (SQLException ex) {
            System.out.println("[SurvivalGamesMySQL] Erorr while we close MySQL " + ex.getMessage());
        }
        return false;
    }
    
    public void close() {
        try {
            if (this.con != null) {
                this.con.close();
                System.out.println("[SurvivalGamesMySQL] MySQL was closed.");
            }
        }
        catch (SQLException ex) {
            System.out.println("[SurvivalGamesMySQL] Erorr while we close MySQL " + ex.getMessage());
        }
    }
    
    public void update(final String s) {
        try {
            final Statement statement = this.con.createStatement();
            statement.executeUpdate(s);
            statement.close();
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
    }
    
    public ResultSet query(final String s) {
        ResultSet executeQuery = null;
        try {
            executeQuery = this.con.createStatement().executeQuery(s);
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
        return executeQuery;
    }
}
