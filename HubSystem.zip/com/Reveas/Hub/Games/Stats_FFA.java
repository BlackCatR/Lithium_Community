package com.Reveas.Hub.Games;

import com.Reveas.Hub.Main.*;
import java.sql.*;
import java.util.*;
import org.bukkit.*;
import com.Reveas.api.*;

public class Stats_FFA
{
    public static boolean playerExists(final String s) {
        try {
            final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
            return query.next() && query.getString("UUID") != null;
        }
        catch (SQLException ex) {
            ex.printStackTrace();
            return (boolean)false;
        }
    }
    
    public static ArrayList<String> getTopPlayers() {
        final ArrayList<String> Top = new ArrayList<String>();
        final ResultSet Result = Main.mysql.query("SELECT * FROM PVPStats ORDER BY POINTS desc LIMIT 10");
        try {
            while (Result.next()) {
                Top.add(Result.getString("UUID"));
            }
        }
        catch (SQLException ex) {}
        return Top;
    }
    
    public static void createPlayer(final String uuid) {
        if (!playerExists(uuid)) {
            Main.mysql.update("INSERT INTO PVPStats(UUID, KILLS, DEATHS, POINTS , KILLSSTREAK, NAME, TYPE, KIT) VALUES ('" + uuid + "', '0', '0', '100','0', '" + Bukkit.getPlayer(UUID.fromString(uuid)).getName() + "', '" + Reveas.getPlayer(Bukkit.getPlayer(UUID.fromString(uuid)).getName()).getRank().getName() + "', 'NULL');");
            Main.mysql.update("INSERT INTO PVPTraills (UUID, LAVAPOP, SMOKE, HEARTS, Trail, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'Null', 'Null');");
            Main.mysql.update("INSERT INTO PVPSounds (UUID, FIREWORK, LEVELUP, DONKEY, Sound, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'Null', 'Null');");
            Main.mysql.update("INSERT INTO PVPSettings (UUID, Save, SaveKit, KitGold, AutoScramble, AutoToggleRank , TNT, Cowbeb, NAME) VALUES ('" + uuid + "', 'false', 'false', 'Null', 'false', 'false', 'false', 'false', 'Null');");
        }
    }
    
    public static Integer getKillstreak(final String s) {
        Integer n = 0;
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getInt("KILLSSTREAK");
                }
                n = query.getInt("KILLSSTREAK");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static void setks(final String database, final String uuid, final String param, final int value) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
    }
    
    public static void setKillsstreak(final String s, final Integer n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET KILLSSTREAK= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static void addKillsstreak(final String s, final Integer n) {
        if (playerExists(s)) {
            setKillsstreak(s, getKillstreak(s) + n);
        }
    }
    
    public static boolean getBoolean(final String database, final String uuid, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        return i;
    }
    
    public static String getString(final String database, final String uuid, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        return i;
    }
    
    public static Integer getKills(final String s) {
        Integer n = 0;
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getInt("KILLS");
                }
                n = query.getInt("KILLS");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static Integer getDeaths(final String s) {
        Integer n = 0;
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getInt("DEATHS");
                }
                n = query.getInt("DEATHS");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static void setParam(final String database, final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
    }
    
    public static Integer getPoints(final String s) {
        Integer n = 0;
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getInt("POINTS");
                }
                n = query.getInt("POINTS");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static String getKit(final String s) {
        String n = "";
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getString("KIT");
                }
                n = query.getString("KIT");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static boolean HaveKit(final String s) {
        if (playerExists(s)) {
            final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
            try {
                return query.next() && query.getString("KIT") != null;
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    
    public static String getName(final String s) {
        String n = "";
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM PVPStats WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getString("NAME");
                }
                n = query.getString("NAME");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return n;
    }
    
    public static void setKills(final String s, final Integer n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET KILLS= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static void setDeaths(final String s, final Integer n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET DEATHS= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static void setPoints(final String s, final Integer n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET POINTS= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static void addKills(final String s, final Integer n) {
        if (playerExists(s)) {
            setKills(s, getKills(s) + n);
        }
    }
    
    public static void addDeaths(final String s, final Integer n) {
        if (playerExists(s)) {
            setDeaths(s, getDeaths(s) + n);
        }
    }
    
    public static void addPoints(final String s, final Integer n) {
        if (playerExists(s)) {
            setPoints(s, getPoints(s) + n);
        }
    }
    
    public static void setKit(final String s, final String n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET KIT= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static void setName(final String s, final String n) {
        if (playerExists(s)) {
            Main.mysql.update("UPDATE PVPStats SET NAME= '" + n + "' WHERE UUID= '" + s + "';");
        }
    }
    
    public static int getRanking(final String uuid) {
        int Ranking = 1;
        if (playerExists(uuid)) {
            final ResultSet Result = Main.mysql.query("SELECT * FROM PVPStats ORDER BY KILLS desc");
            try {
                while (Result.next()) {
                    if (Result.getString("UUID").equalsIgnoreCase(uuid)) {
                        return Ranking;
                    }
                    ++Ranking;
                }
            }
            catch (SQLException ex) {}
        }
        return Ranking;
    }
    
    public static double round(final double D, final int C) {
        final double P = Math.pow(10.0, C);
        return Math.round(D * P) / P;
    }
    
    public static float getKD(final String Playername) {
        final float Kills = getKills(Playername);
        final float Deaths = getDeaths(Playername);
        if (Kills == 0.0f && Deaths == 0.0f) {
            return 0.0f;
        }
        if (Kills > 0.0f && Deaths == 0.0f) {
            return Kills;
        }
        if (Deaths > 0.0f && Kills == 0.0f) {
            return 0.0f;
        }
        if (Kills / Deaths > 1.0E-4) {
            Math.round(0.1);
            return (float)round(Kills / Deaths, 2);
        }
        if (Kills > Deaths) {
            return Kills / Deaths;
        }
        if (Deaths / Kills > 1.0E-4) {
            Math.round(0.1);
            return (float)round(Deaths / Kills, 2);
        }
        if (Deaths > Kills) {
            return Deaths / Kills;
        }
        return Kills / Deaths;
    }
}
