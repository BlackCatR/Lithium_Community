package com.Reveas.Hub.Games;

import java.sql.*;
import java.util.*;
import com.Reveas.Hub.Main.*;

public class Stats_GG
{
    public static boolean isUserExist(final UUID uuid) {
        try {
            if (!MySQL_GG.isConnected()) {
                try {
                    MySQL_GG.connect();
                }
                catch (Exception e2) {
                    System.err.println("[GunGame] Could not connect to MySQL_GG.");
                }
            }
            final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT KILLS FROM Stats WHERE UUID = ?");
            ps.setString(1, uuid.toString());
            final ResultSet rs = ps.executeQuery();
            return rs.next();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static int ranking(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT rn.ranking, rn.points, rn.uuid FROM ( SELECT @ranking := @ranking + 1 as ranking, n.points, n.uuid FROM Stats n, (SELECT @ranking := 0) r ORDER BY n.points DESC ) rn WHERE uuid = ?;");
                ps.setString(1, uuid.toString());
                final ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("ranking");
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
    
    public static ArrayList<String> getTopPlayers() {
        final ArrayList<String> Top = new ArrayList<String>();
        final ResultSet Result = Main.mysql_gg.query("SELECT * FROM Stats ORDER BY POINTS desc LIMIT 10");
        try {
            while (Result.next()) {
                Top.add(Result.getString("UUID"));
            }
        }
        catch (SQLException ex) {}
        return Top;
    }
    
    public static String getRanking(final int pos) {
        try {
            final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT rn.ranking, rn.points, rn.uuid FROM ( SELECT @ranking := @ranking + 1 as ranking, n.points, n.uuid FROM Stats n, (SELECT @ranking := 0) r ORDER BY n.points DESC ) rn WHERE ranking = ?;");
            ps.setInt(1, pos);
            final ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("uuid");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return "Niemand";
    }
    
    public static void updateKills(final UUID uuid, final int wert) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET KILLS = ? WHERE UUID = ?");
                ps.setInt(1, wert);
                ps.setString(2, uuid.toString());
                ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void updatePoints(final UUID uuid, final int wert) {
        if (isUserExist(uuid)) {
            try {
                if (MySQL_GG.isConnected()) {
                    final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET POINTS = ? WHERE UUID = ?");
                    ps.setInt(1, wert);
                    ps.setString(2, uuid.toString());
                    ps.executeUpdate();
                }
                else {
                    MySQL_GG.connect();
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void updateDeaths(final UUID uuid, final int wert) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET DEATHS = ? WHERE UUID = ?");
                ps.setInt(1, wert);
                ps.setString(2, uuid.toString());
                ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void setMaxLVL(final UUID uuid, final int lvl) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET MAXLVL = ? WHERE UUID = ?");
                ps.setInt(1, lvl);
                ps.setString(2, uuid.toString());
                ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void delete(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("DELETE FROM Stats WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void reset(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET POINTS = 0 WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
                final PreparedStatement ps2 = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET WINS = 0 WHERE UUID = ?");
                ps2.setString(1, uuid.toString());
                ps2.executeUpdate();
                final PreparedStatement ps3 = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET DEATHS = 0 WHERE UUID = ?");
                ps3.setString(1, uuid.toString());
                ps3.executeUpdate();
                final PreparedStatement ps4 = MySQL_GG.getConnection().prepareStatement("UPDATE Stats SET KILLS = 0 WHERE UUID = ?");
                ps4.setString(1, uuid.toString());
                ps4.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void createUser(final UUID uuid) {
        if (!isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("INSERT INTO Stats (UUID, POINTS, KILLS, DEATHS, MAXLVL) VALUES(?,0,0,0,0)");
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static int getKills(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT KILLS FROM Stats WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                final ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("KILLS");
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
    
    public static int getPoints(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT POINTS FROM Stats WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                final ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("POINTS");
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
    
    public static int getDeaths(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT DEATHS FROM Stats WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                final ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("DEATHS");
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
    
    public static int getMaxLvl(final UUID uuid) {
        if (isUserExist(uuid)) {
            try {
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("SELECT MAXLVL FROM Stats WHERE UUID = ?");
                ps.setString(1, uuid.toString());
                final ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getInt("MAXLVL");
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
}
