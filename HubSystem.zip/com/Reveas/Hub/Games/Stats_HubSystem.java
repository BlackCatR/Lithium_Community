package com.Reveas.Hub.Games;

import java.sql.*;
import java.util.*;

public class Stats_HubSystem
{
    public static boolean getBoolean(final String database, final String uuid, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getBoolean(database, uuid, param);
        }
        return i;
    }
    
    public static String getName(final String uuid) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    Integer.valueOf(rs.getString("NAME"));
                }
                i = rs.getString("NAME");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }
    
    public static String setParamPlayer(final String database, final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        return value;
    }
    
    public static void setParam(final String database, final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setParam(database, uuid, param, value);
        }
    }
    
    public static void setName(final String uuid, final String name) {
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE Hub SET NAME= '" + name + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setName(uuid, name);
        }
    }
    
    public static String getString(final String database, final String uuid, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getString(database, uuid, param);
        }
        return i;
    }
    
    public static Integer getTokens(final String uuid) {
        createPlayer(uuid);
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("Tokens");
                }
                i = rs.getInt("Tokens");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }
    
    public static void setTokens(final String uuid, final Integer Tokens) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE Hub SET Tokens= '" + Tokens + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            MySQL_HubSystem.update("UPDATE Hub SET Tokens= '" + Tokens + "' WHERE UUID= '" + uuid + "';");
        }
    }
    
    public static void addTokens(final String uuid, final Integer Tokens, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setTokens(uuid, getTokens(uuid) + Tokens);
        }
        else {
            setTokens(uuid, getTokens(uuid) + Tokens);
        }
    }
    
    public static void removeTokens(final String uuid, final Integer Tokens, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setTokens(uuid, getTokens(uuid) - Tokens);
        }
        else {
            setTokens(uuid, getTokens(uuid) - Tokens);
        }
    }
    
    public static Integer getCredits(final String uuid) {
        createPlayer(uuid);
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("Credits");
                }
                i = rs.getInt("Credits");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("Credits");
                }
                i = rs.getInt("Credits");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }
    
    public static void setCredits(final String uuid, final Integer Credits) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE Hub SET Credits= '" + Credits + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            MySQL_HubSystem.update("UPDATE Hub SET Credits= '" + Credits + "' WHERE UUID= '" + uuid + "';");
        }
    }
    
    public static void addCredits(final String uuid, final Integer Credits, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setCredits(uuid, getCredits(uuid) + Credits);
        }
        else {
            setCredits(uuid, getCredits(uuid) + Credits);
        }
    }
    
    public static void removeCredits(final String uuid, final Integer Credits, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setCredits(uuid, getCredits(uuid) - Credits);
        }
        else {
            setCredits(uuid, getCredits(uuid) - Credits);
        }
    }
    
    public static Integer getCrystals(final String uuid) {
        createPlayer(uuid);
        int i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("Crystals");
                }
                i = rs.getInt("Crystals");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("Crystals");
                }
                i = rs.getInt("Crystals");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }
    
    public static void setCrystals(final String uuid, final Integer Credits) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            MySQL_HubSystem.update("UPDATE Hub SET Crystals= '" + Credits + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            MySQL_HubSystem.update("UPDATE Hub SET Crystals= '" + Credits + "' WHERE UUID= '" + uuid + "';");
        }
    }
    
    public static void addCrystals(final String uuid, final Integer Credits, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setCrystals(uuid, getCrystals(uuid) + Credits);
        }
        else {
            setCrystals(uuid, getCrystals(uuid) + Credits);
        }
    }
    
    public static void removeCrystals(final String uuid, final Integer Credits, final boolean notify) {
        createPlayer(uuid);
        if (playerExists(uuid)) {
            setCrystals(uuid, getCrystals(uuid) - Credits);
        }
        else {
            setCrystals(uuid, getCrystals(uuid) - Credits);
        }
    }
    
    public static boolean playerExists(final String uuid) {
        try {
            final ResultSet rs = MySQL_HubSystem.getResult("SELECT * FROM Hub WHERE UUID= '" + uuid + "'");
            if (rs.next()) {
                return rs.getString("UUID") != null;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public static void createPlayer(final String uuid) {
        if (!playerExists(uuid)) {
            MySQL_HubSystem.update("INSERT INTO Hub(UUID, Rank, Level, Tokens, Credits, Crystals, Pets, Mounts, Particels, NAME) VALUES ('" + uuid + "', 'Null' ,'0', '0', '0', '0', '0', '0', '0', 'Null');");
            MySQL_HubSystem.update("INSERT INTO HubSettings(UUID, ToggleRank, Scramble, PVP, SG, Creative , Package, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false', 'Null');");
            MySQL_HubSystem.update("INSERT INTO ReveasRank(UUID, RM, Events, Gift, Diamond, Gold, Emerald, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false', 'Null');");
        }
    }
    
    public static String getCrystals(final UUID uniqueId) {
        return null;
    }
}
