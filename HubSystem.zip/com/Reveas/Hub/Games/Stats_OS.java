package com.Reveas.Hub.Games;

import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import java.sql.*;
import com.Reveas.api.*;
import java.util.*;

public class Stats_OS
{
    public static boolean getBoolean(final String database, final String uuid, final Player p, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid, p);
            getBoolean(database, uuid, p, param);
        }
        return i;
    }
    
    public static boolean playerExists(final String uuid) {
        try {
            final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
            return rs.next() && rs.getString("UUID") != null;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return (boolean)false;
        }
    }
    
    public static String getString(final String table, final String uuid, final Player p, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM " + table + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid, p);
            getString(table, uuid, p, param);
        }
        return i;
    }
    
    public static void createPlayer(final String uuid, final Player p) {
        if (!playerExists(uuid)) {
            Main.mysql_os.update("INSERT INTO OneShot(UUID, KILLS, DEATHS, POINTS, KIT, NAME) VALUES ('" + uuid + "', '0', '0', '1000', '" + Reveas.getPlayer(p.getName()).getName() + "', '" + p.getName() + "');");
        }
    }
    
    public static String getKit(final String uuid, final Player p) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    Integer.valueOf(rs.getString("KIT"));
                }
                i = rs.getString("KIT");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid, p);
            getName(uuid, p);
        }
        return i;
    }
    
    public static String getName(final String uuid, final Player p) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    Integer.valueOf(rs.getString("NAME"));
                }
                i = rs.getString("NAME");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid, p);
            getName(uuid, p);
        }
        return i;
    }
    
    public static void setParam(final String uuid, final Player p, final String param, final String value) {
        if (playerExists(uuid)) {
            Main.mysql_os.update("UPDATE OneShot SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid, p);
            setParam(uuid, p, param, value);
        }
    }
    
    public static void setName(final String uuid, final Player p, final String name) {
        if (playerExists(uuid)) {
            Main.mysql_os.update("UPDATE OneShot SET NAME= '" + name + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid, p);
            setName(uuid, p, name);
        }
    }
    
    public static Integer getKills(final String uuid, final Player p) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("KILLS");
                }
                i = rs.getInt("KILLS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid, p);
            getKills(uuid, p);
        }
        return i;
    }
    
    public static Integer getDeaths(final String uuid, final Player p) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("DEATHS");
                }
                i = rs.getInt("DEATHS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid, p);
            getDeaths(uuid, p);
        }
        return i;
    }
    
    public static Integer getPoints(final String uuid, final Player p) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("POINTS");
                }
                i = rs.getInt("POINTS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid, p);
            getPoints(uuid, p);
        }
        return i;
    }
    
    public static void setKit(final String uuid, final Player p, final String kit) {
        if (playerExists(uuid)) {
            Main.mysql_os.update("UPDATE OneShot SET KIT= '" + kit + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid, p);
            setKit(uuid, p, kit);
        }
    }
    
    public static double round(final double D, final int C) {
        final double P = Math.pow(10.0, C);
        return Math.round(D * P) / P;
    }
    
    public static int getRanking(final String Playername, final String DATA) {
        int Ranking = 1;
        if (playerExists(Playername)) {
            final ResultSet Result = Main.mysql_os.query("SELECT * FROM OneShot ORDER BY " + DATA + " desc");
            try {
                while (Result.next()) {
                    if (Result.getString("UUID").equalsIgnoreCase(Playername)) {
                        return Ranking;
                    }
                    ++Ranking;
                }
            }
            catch (SQLException ex) {}
        }
        return Ranking;
    }
    
    public static float getKD(final String uuid, final Player p) {
        final float KILLS = getKills(uuid, p);
        final float DEATHS = getDeaths(uuid, p);
        if (KILLS == 0.0f && DEATHS == 0.0f) {
            return 0.0f;
        }
        if (KILLS > 0.0f && DEATHS == 0.0f) {
            return KILLS;
        }
        if (DEATHS > 0.0f && KILLS == 0.0f) {
            return 0.0f;
        }
        if (KILLS / DEATHS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(KILLS / DEATHS, 2);
        }
        if (KILLS > DEATHS) {
            return KILLS / DEATHS;
        }
        if (DEATHS / KILLS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(DEATHS / KILLS, 2);
        }
        if (DEATHS > KILLS) {
            return DEATHS / KILLS;
        }
        return KILLS / DEATHS;
    }
    
    public static ArrayList<UUID> getTopPlayers() {
        final ArrayList<UUID> top = new ArrayList<UUID>();
        final ResultSet rs = Main.mysql_os.query("SELECT * FROM OneShot ORDER BY KILLS desc LIMIT 10");
        try {
            while (rs.next()) {
                top.add(UUID.fromString(rs.getString("UUID")));
            }
        }
        catch (SQLException ex) {}
        return top;
    }
}
