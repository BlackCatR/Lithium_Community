package com.Reveas.Hub.Games;

import com.Reveas.Hub.Main.*;
import java.sql.*;
import java.util.*;

public class Stats_OvO
{
    public static boolean getBoolean(final String database, final String uuid, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getBoolean(database, uuid, param);
        }
        return i;
    }
    
    public static boolean playerExists(final String uuid) {
        try {
            final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
            return rs.next() && rs.getString("UUID") != null;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return (boolean)false;
        }
    }
    
    public static String getString(final String database, final String uuid, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getString(database, uuid, param);
        }
        return i;
    }
    
    public static void createPlayer(final String uuid) {
        if (!playerExists(uuid)) {
            Main.mysql.update("INSERT INTO 1vs1(UUID, KILLS, DEATHS, GAMESPLAYED, POINTS, WINS, ROUNDS, NAME) VALUES ('" + uuid + "', '0', '0', '0', '1000', '0', '0', 'Null');");
        }
    }
    
    public static String getName(final String s) {
        String n = "";
        if (playerExists(s)) {
            try {
                final ResultSet query = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + s + "'");
                if (query.next()) {
                    query.getString("NAME");
                }
                n = query.getString("NAME");
            }
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        else {
            createPlayer(s);
            getName(s);
        }
        return n;
    }
    
    public static void setParam(final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setParam(uuid, param, value);
        }
    }
    
    public static void setName(final String uuid, final String name) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET NAME= '" + name + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setName(uuid, name);
        }
    }
    
    public static Integer getKills(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("KILLS");
                }
                i = rs.getInt("KILLS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getKills(uuid);
        }
        return i;
    }
    
    public static Integer getDeaths(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("DEATHS");
                }
                i = rs.getInt("DEATHS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getDeaths(uuid);
        }
        return i;
    }
    
    public static Integer getGamesPlayed(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("GAMESPLAYED");
                }
                i = rs.getInt("GAMESPLAYED");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getGamesPlayed(uuid);
        }
        return i;
    }
    
    public static Integer getRounds(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("ROUNDS");
                }
                i = rs.getInt("ROUNDS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getRounds(uuid);
        }
        return i;
    }
    
    public static Integer getPoints(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("POINTS");
                }
                i = rs.getInt("POINTS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getPoints(uuid);
        }
        return i;
    }
    
    public static Integer getWins(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("WINS");
                }
                i = rs.getInt("WINS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getWins(uuid);
        }
        return i;
    }
    
    public static void setKills(final String uuid, final Integer kills) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET KILLS= '" + kills + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setKills(uuid, kills);
        }
    }
    
    public static void setRounds(final String uuid, final Integer rounds) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET ROUNDS= '" + rounds + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setRounds(uuid, rounds);
        }
    }
    
    public static void setDeaths(final String uuid, final Integer deaths) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET DEATHS= '" + deaths + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setDeaths(uuid, deaths);
        }
    }
    
    public static void setGamesPlayed(final String uuid, final Integer played) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET GAMESPLAYED= '" + played + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setGamesPlayed(uuid, played);
        }
    }
    
    public static void setPoints(final String uuid, final Integer points) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET POINTS= '" + points + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setPoints(uuid, points);
        }
    }
    
    public static void setWins(final String uuid, final Integer wins) {
        if (playerExists(uuid)) {
            Main.mysql.update("UPDATE 1vs1 SET WINS= '" + wins + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setWins(uuid, wins);
        }
    }
    
    public static void addKills(final String uuid, final Integer kills) {
        if (playerExists(uuid)) {
            setKills(uuid, getKills(uuid) + kills);
        }
        else {
            createPlayer(uuid);
            addKills(uuid, kills);
        }
    }
    
    public static void addRounds(final String uuid, final Integer deathmatch) {
        if (playerExists(uuid)) {
            setRounds(uuid, getRounds(uuid) + deathmatch);
        }
        else {
            createPlayer(uuid);
            addRounds(uuid, deathmatch);
        }
    }
    
    public static void addDeaths(final String uuid, final Integer deaths) {
        if (playerExists(uuid)) {
            setDeaths(uuid, getDeaths(uuid) + deaths);
        }
        else {
            createPlayer(uuid);
            addDeaths(uuid, deaths);
        }
    }
    
    public static void addGamesPlayed(final String uuid, final Integer played) {
        if (playerExists(uuid)) {
            setGamesPlayed(uuid, getGamesPlayed(uuid) + played);
        }
        else {
            createPlayer(uuid);
            addGamesPlayed(uuid, played);
        }
    }
    
    public static void addPoints(final String uuid, final Integer points) {
        if (playerExists(uuid)) {
            setPoints(uuid, getPoints(uuid) + points);
        }
        else {
            createPlayer(uuid);
            addPoints(uuid, points);
        }
    }
    
    public static void addWins(final String uuid, final Integer wins) {
        if (playerExists(uuid)) {
            setWins(uuid, getWins(uuid) + wins);
        }
        else {
            createPlayer(uuid);
            addWins(uuid, wins);
        }
    }
    
    public static double round(final double D, final int C) {
        final double P = Math.pow(10.0, C);
        return Math.round(D * P) / P;
    }
    
    public static int getRanking(final String Playername, final String DATA) {
        int Ranking = 1;
        if (playerExists(Playername)) {
            final ResultSet Result = Main.mysql.query("SELECT * FROM 1vs1 ORDER BY " + DATA + " desc");
            try {
                while (Result.next()) {
                    if (Result.getString("UUID").equalsIgnoreCase(Playername)) {
                        return Ranking;
                    }
                    ++Ranking;
                }
            }
            catch (SQLException ex) {}
        }
        return Ranking;
    }
    
    public static float getKD(final String Playername) {
        final float KILLS = getKills(Playername);
        final float DEATHS = getDeaths(Playername);
        if (KILLS == 0.0f && DEATHS == 0.0f) {
            return 0.0f;
        }
        if (KILLS > 0.0f && DEATHS == 0.0f) {
            return KILLS;
        }
        if (DEATHS > 0.0f && KILLS == 0.0f) {
            return 0.0f;
        }
        if (KILLS / DEATHS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(KILLS / DEATHS, 2);
        }
        if (KILLS > DEATHS) {
            return KILLS / DEATHS;
        }
        if (DEATHS / KILLS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(DEATHS / KILLS, 2);
        }
        if (DEATHS > KILLS) {
            return DEATHS / KILLS;
        }
        return KILLS / DEATHS;
    }
    
    public static float getWL(final String Playername) {
        final float KILLS = getWins(Playername);
        final float DEATHS = getGamesPlayed(Playername);
        if (KILLS == 0.0f && DEATHS == 0.0f) {
            return 0.0f;
        }
        if (KILLS > 0.0f && DEATHS == 0.0f) {
            return KILLS;
        }
        if (DEATHS > 0.0f && KILLS == 0.0f) {
            return 0.0f;
        }
        if (KILLS / DEATHS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(KILLS / DEATHS, 2);
        }
        if (KILLS > DEATHS) {
            return KILLS / DEATHS;
        }
        if (DEATHS / KILLS > 1.0E-4) {
            Math.round(0.1);
            return (float)round(DEATHS / KILLS, 2);
        }
        if (DEATHS > KILLS) {
            return DEATHS / KILLS;
        }
        return KILLS / DEATHS;
    }
    
    public static ArrayList<UUID> getTopPlayers() {
        final ArrayList<UUID> top = new ArrayList<UUID>();
        final ResultSet rs = Main.mysql.query("SELECT * FROM 1vs1 ORDER BY WINS desc LIMIT 10");
        try {
            while (rs.next()) {
                top.add(UUID.fromString(rs.getString("UUID")));
            }
        }
        catch (SQLException ex) {}
        return top;
    }
}
