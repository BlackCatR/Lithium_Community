package com.Reveas.Hub.Games;

import com.Reveas.Hub.Main.*;
import java.sql.*;

public class Stats_SG
{
    public static boolean getBoolean(final String database, final String uuid, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getBoolean(database, uuid, param);
        }
        return i;
    }
    
    public static boolean playerExists(final String uuid) {
        try {
            final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
            return rs.next() && rs.getString("UUID") != null;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return (boolean)false;
        }
    }
    
    public static String getString(final String database, final String uuid, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getString(database, uuid, param);
        }
        return i;
    }
    
    public static void createPlayer(final String uuid) {
        if (!playerExists(uuid)) {
            Main.mysqlsg.update("INSERT INTO SGRounds(Players, Kills, Deaths, Time, Points, Winner, GameID, Server, VoteDM, Map) VALUES ('" + (Object)null + "', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'None');");
            Main.mysqlsg.update("INSERT INTO SGStats(UUID, KILLS, DEATHS, PLAYED, POINTS, WINS, CHEST, DEATHMATCH, Achievements, NAME) VALUES ('" + uuid + "', '0', '0', '0', '100', '0', '0', '0', 'Null', 'Null');");
            Main.mysqlsg.update("INSERT INTO SGTraills (UUID, Note, Fairy, Flame, Hearts, Smoke, VillagerThundercloud, EFFECT, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false', 'Null', 'Null');");
            Main.mysqlsg.update("INSERT INTO SGSounds (UUID, Anvil, Burp, DonkeyDeath, FireworkWhizz, HorseScreech, Levelup, CatMeow, RoaringThunnder, VillagerYes, SOUND, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'Null', 'Null');");
            Main.mysqlsg.update("INSERT INTO SGLeather (UUID, Purple, Cyan, White, Pink, Black, Green, Blue, Orange, Red, COLOR, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false','false','false', 'false', 'Null', 'Null');");
            Main.mysqlsg.update("INSERT INTO SGSettings (UUID, AutoToggleRank, AutoScramble, Chest, ChestE, ChestD, MySword , SwordOff, SwordOn, NAME) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'false', 'Null');");
        }
    }
    
    public static String getName(final String uuid) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    Integer.valueOf(rs.getString("NAME"));
                }
                i = rs.getString("NAME");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getName(uuid);
        }
        return i;
    }
    
    public static void setLive(final String database, final String uuid, final String param, final Integer value) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setLive(database, uuid, param, value);
        }
    }
    
    public static void setParam(final String database, final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setParam(database, uuid, param, value);
        }
    }
    
    public static void setName(final String uuid, final String name) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET NAME= '" + name + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setName(uuid, name);
        }
    }
    
    public static Integer getKills(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("KILLS");
                }
                i = rs.getInt("KILLS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getKills(uuid);
        }
        return i;
    }
    
    public static Integer getDeaths(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("DEATHS");
                }
                i = rs.getInt("DEATHS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getDeaths(uuid);
        }
        return i;
    }
    
    public static Integer getPlayed(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("PLAYED");
                }
                i = rs.getInt("PLAYED");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getPlayed(uuid);
        }
        return i;
    }
    
    public static Integer getDeathmatch(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("DEATHMATCH");
                }
                i = rs.getInt("DEATHMATCH");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getDeathmatch(uuid);
        }
        return i;
    }
    
    public static Integer getPoints(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("POINTS");
                }
                i = rs.getInt("POINTS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getPoints(uuid);
        }
        return i;
    }
    
    public static Integer getWins(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("WINS");
                }
                i = rs.getInt("WINS");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getWins(uuid);
        }
        return i;
    }
    
    public static Integer getChest(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.mysqlsg.query("SELECT * FROM SGStats WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("CHEST");
                }
                i = rs.getInt("CHEST");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getChest(uuid);
        }
        return i;
    }
    
    public static void setKills(final String uuid, final Integer kills) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET KILLS= '" + kills + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setKills(uuid, kills);
        }
    }
    
    public static void setDeathmatch(final String uuid, final Integer deathmatch) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET DEATHMATCH= '" + deathmatch + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setDeathmatch(uuid, deathmatch);
        }
    }
    
    public static void setDeaths(final String uuid, final Integer deaths) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET DEATHS= '" + deaths + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setDeaths(uuid, deaths);
        }
    }
    
    public static void setPlayed(final String uuid, final Integer played) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET PLAYED= '" + played + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setPlayed(uuid, played);
        }
    }
    
    public static void setPoints(final String uuid, final Integer points) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET POINTS= '" + points + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setPoints(uuid, points);
        }
    }
    
    public static void setWins(final String uuid, final Integer wins) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET WINS= '" + wins + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setWins(uuid, wins);
        }
    }
    
    public static void setChest(final String uuid, final Integer chest) {
        if (playerExists(uuid)) {
            Main.mysqlsg.update("UPDATE SGStats SET CHEST= '" + chest + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setChest(uuid, chest);
        }
    }
    
    public static void addKills(final String uuid, final Integer kills) {
        if (playerExists(uuid)) {
            setKills(uuid, getKills(uuid) + kills);
        }
        else {
            createPlayer(uuid);
            addKills(uuid, kills);
        }
    }
    
    public static void addDeathmatch(final String uuid, final Integer deathmatch) {
        if (playerExists(uuid)) {
            setDeathmatch(uuid, getDeathmatch(uuid) + deathmatch);
        }
        else {
            createPlayer(uuid);
            addDeathmatch(uuid, deathmatch);
        }
    }
    
    public static void addDeaths(final String uuid, final Integer deaths) {
        if (playerExists(uuid)) {
            setDeaths(uuid, getDeaths(uuid) + deaths);
        }
        else {
            createPlayer(uuid);
            addDeaths(uuid, deaths);
        }
    }
    
    public static void addPlayed(final String uuid, final Integer played) {
        if (playerExists(uuid)) {
            setPlayed(uuid, getPlayed(uuid) + played);
        }
        else {
            createPlayer(uuid);
            addPlayed(uuid, played);
        }
    }
    
    public static void addPoints(final String uuid, final Integer points) {
        if (playerExists(uuid)) {
            setPoints(uuid, getPoints(uuid) + points);
        }
        else {
            createPlayer(uuid);
            addPoints(uuid, points);
        }
    }
    
    public static void addWins(final String uuid, final Integer wins) {
        if (playerExists(uuid)) {
            setWins(uuid, getWins(uuid) + wins);
        }
        else {
            createPlayer(uuid);
            addWins(uuid, wins);
        }
    }
    
    public static void addChest(final String uuid, final Integer chest) {
        if (playerExists(uuid)) {
            setChest(uuid, getChest(uuid) + chest);
        }
        else {
            createPlayer(uuid);
            addChest(uuid, chest);
        }
    }
}
