package com.Reveas.Hub.Games;

import com.Reveas.Hub.Main.*;
import java.sql.*;

public class Stats_Tokens
{
    public static boolean getBoolean(final String database, final String uuid, final String param) {
        boolean i = false;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.StoreRank.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getBoolean(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getBoolean(database, uuid, param);
        }
        return i;
    }
    
    public static boolean playerExists(final String uuid) {
        try {
            final ResultSet rs = Main.StoreRank.query("SELECT * FROM StoreRank WHERE UUID= '" + uuid + "'");
            return rs.next() && rs.getString("UUID") != null;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return (boolean)false;
        }
    }
    
    public static String getString(final String database, final String uuid, final String param) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.StoreRank.query("SELECT * FROM " + database + " WHERE UUID= '" + uuid + "'");
                rs.next();
                i = rs.getString(param);
            }
            catch (SQLException ex) {}
        }
        else {
            createPlayer(uuid);
            getString(database, uuid, param);
        }
        return i;
    }
    
    public static void createPlayer(final String uuid) {
        if (!playerExists(uuid)) {
            Main.StoreRank.update("INSERT INTO StoreRank (UUID, Emerald, Diamond, Gold , Member) VALUES ('" + uuid + "', 'false', 'false', 'false', 'false');");
        }
    }
    
    public static String getName(final String uuid) {
        String i = "";
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.StoreRank.query("SELECT * FROM StoreRank WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    Integer.valueOf(rs.getString("NAME"));
                }
                i = rs.getString("NAME");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getName(uuid);
        }
        return i;
    }
    
    public static void setParam(final String database, final String uuid, final String param, final String value) {
        if (playerExists(uuid)) {
            Main.StoreRank.update("UPDATE " + database + " SET " + param + "= '" + value + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setParam(database, uuid, param, value);
        }
    }
    
    public static void setName(final String uuid, final String name) {
        if (playerExists(uuid)) {
            Main.StoreRank.update("UPDATE StoreRank SET NAME= '" + name + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setName(uuid, name);
        }
    }
    
    public static Integer getChest(final String uuid) {
        Integer i = 0;
        if (playerExists(uuid)) {
            try {
                final ResultSet rs = Main.StoreRank.query("SELECT * FROM StoreRank WHERE UUID= '" + uuid + "'");
                if (rs.next()) {
                    rs.getInt("CHEST");
                }
                i = rs.getInt("CHEST");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            createPlayer(uuid);
            getChest(uuid);
        }
        return i;
    }
    
    public static void setChest(final String uuid, final Integer chest) {
        if (playerExists(uuid)) {
            Main.StoreRank.update("UPDATE StoreRank SET CHEST= '" + chest + "' WHERE UUID= '" + uuid + "';");
        }
        else {
            createPlayer(uuid);
            setChest(uuid, chest);
        }
    }
    
    public static void addChest(final String uuid, final Integer chest) {
        if (playerExists(uuid)) {
            setChest(uuid, getChest(uuid) + chest);
        }
        else {
            createPlayer(uuid);
            addChest(uuid, chest);
        }
    }
}
