package com.Reveas.Hub.Games;

import java.sql.*;

public class TokensRank
{
    private String HOST;
    private String DATABASE;
    private String USER;
    private String PORT;
    private String PASSWORD;
    private Connection con;
    
    public TokensRank(final String host, final String database, final String user, final String password) {
        this.HOST = "localhost";
        this.DATABASE = "ReveasBungee";
        this.USER = "ReveasBungee";
        this.PORT = "3306";
        this.PASSWORD = "13";
        this.connect();
    }
    
    public void connect() {
        try {
            this.con = DriverManager.getConnection("jdbc:mysql://" + this.HOST + ":" + this.PORT + "/" + this.DATABASE + "?autoReconnect=true", this.USER, this.PASSWORD);
            System.out.println("[StoreRank] Connect to Driver Successfully");
        }
        catch (SQLException ex) {
            System.out.println("[StoreRank] Disconnected from Deiver reason :" + ex.getMessage());
        }
    }
    
    public void close() {
        try {
            if (this.con != null) {
                this.con.close();
                System.out.println("[StoreRank] MySQL was closed.");
            }
        }
        catch (SQLException ex) {
            System.out.println("[StoreRank] Erorr while we close MySQL " + ex.getMessage());
        }
    }
    
    public void update(final String s) {
        try {
            final Statement statement = this.con.createStatement();
            statement.executeUpdate(s);
            statement.close();
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
    }
    
    public ResultSet query(final String s) {
        ResultSet executeQuery = null;
        try {
            executeQuery = this.con.createStatement().executeQuery(s);
        }
        catch (SQLException ex) {
            this.connect();
            System.err.println(ex);
        }
        return executeQuery;
    }
}
