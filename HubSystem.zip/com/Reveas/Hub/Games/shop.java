package com.Reveas.Hub.Games;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;

public class shop implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (sender instanceof Player && args.length == 0) {
            final Player p = (Player)sender;
            if (p.hasPermission("RM.permissions.signmode") || p.getName().equals("Hamoood_")) {
                if (!Main.plugin.createSign.contains(p)) {
                    Main.plugin.createSign.add(p);
                    sender.sendMessage(String.valueOf(Main.prefix) + "�aYou are can create Signs <33 !");
                    sender.sendMessage(" ");
                    sender.sendMessage(String.valueOf(Main.prefix) + "�f�lNAME �7asm alserver nfs al bungee");
                    sender.sendMessage(String.valueOf(Main.prefix) + "�f�lDISPLAYNAME �776h asm al server bdwn shr6h");
                    sender.sendMessage(String.valueOf(Main.prefix) + "�f�lIP-ADRESSE �7localhost");
                    sender.sendMessage(String.valueOf(Main.prefix) + "�f�lPORT �7alport 78 alserver");
                }
                else {
                    Main.plugin.createSign.remove(p);
                    sender.sendMessage(String.valueOf(Main.prefix) + "�cYou now can remove Signs (�eLeft Click�c)");
                }
                return true;
            }
        }
        return false;
    }
}
