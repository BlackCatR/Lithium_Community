package com.Reveas.Hub.Inventorys;

import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;

public class Cot0 implements Listener
{
    final Inventory invToc;
    int num;
    
    public Cot0() {
        this.invToc = Bukkit.createInventory((InventoryHolder)null, 9, "�e� Credits to Tokens");
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        try {
            if (e.getRightClicked().getType() == EntityType.VILLAGER) {
                final Villager v = (Villager)e.getRightClicked();
                if (v.getCustomName().equalsIgnoreCase("�e�lCredits to Tokens")) {
                    e.setCancelled(true);
                    final ItemStack item = new ItemStack(Material.IRON_INGOT);
                    final ItemMeta meta = item.getItemMeta();
                    meta.setDisplayName("�a1000 Tokens");
                    final ArrayList list = new ArrayList();
                    list.add("");
                    list.add("�7- Convert 1 Credits to 1000 Tokens.");
                    list.add("");
                    list.add("�3Price: �e1 Credits �6\u272a");
                    list.add("�8� �b Click to Convert");
                    meta.setLore((List)list);
                    item.setItemMeta(meta);
                    final ItemStack itemxx = new ItemStack(Material.IRON_INGOT);
                    final ItemMeta metaxx = item.getItemMeta();
                    metaxx.setDisplayName("�a5000 Tokens");
                    final ArrayList listxx = new ArrayList();
                    listxx.add("");
                    listxx.add("�7- Convert 5 Credits to 5000 Tokens.");
                    listxx.add("");
                    listxx.add("�3Price: �e5 Credits �6\u272a");
                    listxx.add("�8� �bClick to Convert");
                    metaxx.setLore((List)listxx);
                    itemxx.setItemMeta(metaxx);
                    final ItemStack itemxxitemxx = new ItemStack(Material.IRON_INGOT);
                    final ItemMeta metaxxmetaxx = itemxxitemxx.getItemMeta();
                    metaxxmetaxx.setDisplayName("�a10000 Tokens");
                    final ArrayList listxxlistxx = new ArrayList();
                    listxxlistxx.add("");
                    listxxlistxx.add("�7- Convert 10 Credits to 10000 Tokens.");
                    listxxlistxx.add("");
                    listxxlistxx.add("�3Price: �e10 Credits �6\u272a");
                    listxxlistxx.add("�8� �bClick to Convert");
                    metaxxmetaxx.setLore((List)listxxlistxx);
                    itemxxitemxx.setItemMeta(metaxxmetaxx);
                    this.invToc.setItem(2, item);
                    this.invToc.setItem(4, itemxx);
                    this.invToc.setItem(6, itemxxitemxx);
                    p.openInventory(this.invToc);
                }
            }
        }
        catch (Exception ex) {}
    }
}
