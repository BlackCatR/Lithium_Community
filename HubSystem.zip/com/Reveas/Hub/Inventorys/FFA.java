package com.Reveas.Hub.Inventorys;

import com.Reveas.Hub.Main.*;
import org.bukkit.event.player.*;
import org.bukkit.event.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Board.*;
import com.Reveas.Hub.Games.*;
import com.Reveas.Hub.Manager.*;

public class FFA implements Listener
{
    public static Inventory ShopFFA;
    static Inventory Sounds;
    static Inventory Trails;
    static Inventory Perks;
    Main plugin;
    
    public FFA() {
        FFA.ShopFFA = Bukkit.createInventory((InventoryHolder)null, 27, "�e� PVP shop");
        FFA.Sounds = Bukkit.createInventory((InventoryHolder)null, 27, "�e� Customisation Sounds");
        FFA.Perks = Bukkit.createInventory((InventoryHolder)null, 27, "�e� Customisation Perks");
        FFA.Trails = Bukkit.createInventory((InventoryHolder)null, 27, "�e� Customisation Trails");
    }
    
    @EventHandler
    public void onInteract1(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        if (e.getRightClicked().getType() == EntityType.VILLAGER) {
            final Villager v = (Villager)e.getRightClicked();
            if (v.getCustomName().equalsIgnoreCase("�e�lPVP Shop")) {
                e.setCancelled(true);
                p.chat("/FFA-shop");
            }
        }
    }
    
    public static ItemStack Back() {
        final ItemStack g = new ItemStack(Material.ARROW);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&8� &cBack!"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add(Main.F("�eExit to Menu "));
        lore.add("�8� �aClick here?");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Close() {
        final ItemStack g = new ItemStack(Material.BARRIER);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&8� &cExit"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�eClose Menu");
        lore.add("�8� �aClick to here");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Fire() {
        final ItemStack g = new ItemStack(Material.BLAZE_POWDER);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eFire"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Hearts() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)14);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eHearts"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Happy() {
        final ItemStack g = new ItemStack(Material.INK_SACK, 1, (short)1);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eHappy"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Smoke() {
        final ItemStack g = new ItemStack(Material.GOLD_NUGGET);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eSmoke"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Ender() {
        final ItemStack g = new ItemStack(Material.ENDER_PEARL);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eEnder"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Sparks() {
        final ItemStack g = new ItemStack(Material.FIREWORK);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eSparks"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Angry() {
        final ItemStack g = new ItemStack(Material.GLOWSTONE_DUST);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Trail &8� &eAngry"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e1000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Sounds() {
        final ItemStack g = new ItemStack(Material.FIREWORK_CHARGE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&8� &6Sounds"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Perks() {
        final ItemStack g = new ItemStack(Material.NETHER_STAR);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&8� &7Perks"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Trails() {
        final ItemStack g = new ItemStack(Material.BLAZE_POWDER);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&8� &6Trails"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack FireworkSound() {
        final ItemStack g = new ItemStack(Material.FIREWORK_CHARGE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eFirework"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack EnderdragonSound() {
        final ItemStack g = new ItemStack(Material.DRAGON_EGG);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eEnderdragon"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack AnvilSound() {
        final ItemStack g = new ItemStack(Material.ANVIL);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eAnvil"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack VillagerSound() {
        final ItemStack g = new ItemStack(Material.EMERALD);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eVillager"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ZombieSound() {
        final ItemStack g = new ItemStack(Material.FEATHER);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eZombie"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack HorseSound() {
        final ItemStack g = new ItemStack(Material.SADDLE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eHorse"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack WitherSound() {
        final ItemStack g = new ItemStack(Material.NETHER_STAR);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Death Sound &8� &eWither"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e2000 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Cowbeb() {
        final ItemStack g = new ItemStack(Material.WEB);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Perks &8� &eCowbeb"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e350 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack TNT() {
        final ItemStack g = new ItemStack(Material.TNT);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("&3Perks &8� &eTNT"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�3Price: �e350 Tokens �6\u272a");
        lore.add("�8� �bClick to Buy");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Firework(final Player p) {
        final ItemStack i = new ItemStack(Material.FIREWORK);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "FIREWORK")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Allows you to select this,");
            lore.add("�7sound as a Battle Cry!");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7200 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setLore((List)lore);
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setDisplayName("�C�lFirework Whizz");
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Hearts(final Player p) {
        final ItemStack i = new ItemStack(Material.RED_ROSE);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "SMOKE")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Love is in the air,");
            lore.add("�7isn't that beautiful.");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7300 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setLore((List)lore);
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setDisplayName("�C�lHearts");
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Smoke(final Player p) {
        final ItemStack i = new ItemStack(Material.STRING);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "SMOKE")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Will some cloud?.");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7200 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setDisplayName("�f�lSmoke");
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setLore((List)lore);
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Cowbeb(final Player p) {
        final ItemStack i = new ItemStack(Material.WEB);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "Cowbeb")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Allow you to use this.");
            lore.add("�7item to hinder your enemies.");
            lore.add("�2");
            lore.add("�a�lCost");
            lore.add("�7300 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setDisplayName("�f�lCobweb");
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setLore((List)lore);
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack TNT(final Player p) {
        final ItemStack i = new ItemStack(Material.TNT);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "TNT")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Allow you to use this.");
            lore.add("�7item to blow up your enemies.");
            lore.add("�2");
            lore.add("�a�lCost");
            lore.add("�7300 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setDisplayName("�c�lTNT");
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setLore((List)lore);
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack LavaPOP(final Player p) {
        final ItemStack i = new ItemStack(Material.BLAZE_POWDER);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "LAVAPOP")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Okay its drip lava.");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7200 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setDisplayName("�6�lLava POP");
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setLore((List)lore);
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Levelup(final Player p) {
        final ItemStack i = new ItemStack(Material.EXP_BOTTLE);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "LEVELUP")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Allows you to select this,");
            lore.add("�7sound as a Battle Cry!");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7300 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setLore((List)lore);
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setDisplayName("�a�lLevel up Tune");
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Donkey(final Player p) {
        final ItemStack i = new ItemStack(Material.LEASH);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "DONKEY")) {
            lore.add("�2");
            i.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�7Allows you to select this,");
            lore.add("�7sound as a Battle Cry!");
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�7300 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = i.getItemMeta();
        m.setLore((List)lore);
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setDisplayName("�e�lDonkey Death");
        i.setItemMeta(m);
        return i;
    }
    
    public static ItemStack Gold(final Player p) {
        final ItemStack g = new ItemStack(Material.GOLD_CHESTPLATE);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "KitGold")) {
            lore.add("�2");
            g.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
        }
        else {
            lore.add("�e");
            lore.add("�a�lCost");
            lore.add("�71000 Tokens");
            lore.add("�2");
            lore.add("�b\u279d Click to purchase");
        }
        final ItemMeta m = g.getItemMeta();
        m.setDisplayName("�6�lGold Kit");
        m.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m.setLore((List)lore);
        g.setItemMeta(m);
        return g;
    }
    
    @EventHandler
    public void onCustom(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� PVP shop")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getType() == Sounds().getType()) {
            FFA.Sounds.setItem(11, Firework(p));
            FFA.Sounds.setItem(13, Levelup(p));
            FFA.Sounds.setItem(15, Donkey(p));
            FFA.Sounds.setItem(26, Back());
            p.openInventory(FFA.Sounds);
        }
        if (e.getCurrentItem().getType() == Perks().getType()) {
            FFA.Perks.setItem(11, Cowbeb(p));
            FFA.Perks.setItem(13, Gold(p));
            FFA.Perks.setItem(15, TNT(p));
            FFA.Perks.setItem(26, Back());
            p.openInventory(FFA.Perks);
        }
        if (e.getCurrentItem().getType() == Trails().getType()) {
            FFA.Trails.setItem(11, LavaPOP(p));
            FFA.Trails.setItem(13, Hearts(p));
            FFA.Trails.setItem(15, Smoke(p));
            FFA.Trails.setItem(26, Back());
            p.openInventory(FFA.Trails);
        }
        if (e.getCurrentItem().getType() == Close().getType()) {
            p.closeInventory();
        }
    }
    
    @EventHandler
    public void OnExit(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� Customisation Sounds")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getType() == Back().getType()) {
            FFA.ShopFFA.setItem(11, Trails());
            FFA.ShopFFA.setItem(15, Sounds());
            FFA.ShopFFA.setItem(13, Perks());
            FFA.ShopFFA.setItem(26, Close());
            p.openInventory(FFA.ShopFFA);
        }
    }
    
    @EventHandler
    public void onExitT(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� Customisation Trails")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getType() == Back().getType()) {
            FFA.ShopFFA.setItem(11, Trails());
            FFA.ShopFFA.setItem(15, Sounds());
            FFA.ShopFFA.setItem(13, Perks());
            FFA.ShopFFA.setItem(26, Close());
            p.openInventory(FFA.ShopFFA);
        }
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        try {
            if (e.getRightClicked().getType() == EntityType.ARMOR_STAND) {
                final ArmorStand v = (ArmorStand)e.getRightClicked();
                if (v.getCustomName().equalsIgnoreCase("�e�lFFA Shop")) {
                    e.setCancelled(true);
                    Stats_FFA.createPlayer(p.getUniqueId().toString());
                    FFA.ShopFFA.setItem(11, Trails());
                    FFA.ShopFFA.setItem(15, Sounds());
                    FFA.ShopFFA.setItem(13, Perks());
                    FFA.ShopFFA.setItem(26, Close());
                    p.openInventory(FFA.ShopFFA);
                }
            }
        }
        catch (Exception ex) {}
    }
    
    @EventHandler
    public void OnPerks(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� Customisation Perks")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getType() == Back().getType()) {
            FFA.ShopFFA.setItem(11, Trails());
            FFA.ShopFFA.setItem(15, Sounds());
            FFA.ShopFFA.setItem(13, Perks());
            FFA.ShopFFA.setItem(26, Close());
            p.openInventory(FFA.ShopFFA);
        }
        if (e.getCurrentItem().getType() == Gold(p).getType()) {
            if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "KitGold")) {
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this cowbeb."));
                ScoreboardHandler.getBoard(p);
                return;
            }
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 1000) {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                return;
            }
            Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 1000, false);
            Stats_FFA.setParam("PVPSettings", p.getUniqueId().toString(), "KitGold", "true");
            p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Kit Gold."));
            ScoreboardHandler.getBoard(p);
        }
        if (e.getCurrentItem().getType() == Cowbeb(p).getType()) {
            if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "Cowbeb")) {
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this cowbeb."));
                ScoreboardHandler.getBoard(p);
                return;
            }
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 350) {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                return;
            }
            Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 350, false);
            Stats_FFA.setParam("PVPSettings", p.getUniqueId().toString(), "Cowbeb", "true");
            p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Cowbeb."));
            ScoreboardHandler.getBoard(p);
        }
        if (e.getCurrentItem().getType() == TNT(p).getType()) {
            if (Stats_FFA.getBoolean("PVPSettings", p.getUniqueId().toString(), "TNT")) {
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this tnt."));
                ScoreboardHandler.getBoard(p);
                return;
            }
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 350) {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                return;
            }
            Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 350, false);
            Stats_FFA.setParam("PVPSettings", p.getUniqueId().toString(), "TNT", "true");
            p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l TNT."));
            ScoreboardHandler.getBoard(p);
        }
    }
    
    @EventHandler
    public void OnSounds(final InventoryClickEvent e) {
        if (e.getInventory().getTitle().equals("�e� Customisation Sounds")) {
            final Player p = (Player)e.getWhoClicked();
            e.setCancelled(true);
            if (e.getCurrentItem().getType() == Firework(p).getType()) {
                if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "FIREWORK")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this sound."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 200) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 200, false);
                Stats_FFA.setParam("PVPSounds", p.getUniqueId().toString(), "FIREWORK", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Firework."));
                ScoreboardHandler.getBoard(p);
            }
            if (e.getCurrentItem().getType() == Levelup(p).getType()) {
                if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "LEVELUP")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this sound."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 200) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 200, false);
                Stats_FFA.setParam("PVPSounds", p.getUniqueId().toString(), "LEVELUP", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l LevelUp."));
                ScoreboardHandler.getBoard(p);
            }
            if (e.getCurrentItem().getType() == Donkey(p).getType()) {
                if (Stats_FFA.getBoolean("PVPSounds", p.getUniqueId().toString(), "DONKEY")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this sound."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 300) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 300, false);
                Stats_FFA.setParam("PVPSounds", p.getUniqueId().toString(), "DONKEY", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Donkey."));
                ScoreboardHandler.getBoard(p);
            }
        }
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        if (e.getInventory().getTitle().equals("�e� Customisation Trails")) {
            final Player p = (Player)e.getWhoClicked();
            e.setCancelled(true);
            if (e.getCurrentItem().getType() == LavaPOP(p).getType()) {
                if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "LAVAPOP")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this trail."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 200) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 200, false);
                Stats_FFA.setParam("PVPTraills", p.getUniqueId().toString(), "LAVAPOP", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l LavaPOP."));
                ScoreboardHandler.getBoard(p);
            }
            if (e.getCurrentItem().getType() == Hearts(p).getType()) {
                if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "HEARTS")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this trail."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 300) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 300, false);
                Stats_FFA.setParam("PVPTraills", p.getUniqueId().toString(), "HEARTS", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Hearts."));
                ScoreboardHandler.getBoard(p);
            }
            if (e.getCurrentItem().getType() == Smoke(p).getType()) {
                if (Stats_FFA.getBoolean("PVPTraills", p.getUniqueId().toString(), "SMOKE")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this trail."));
                    ScoreboardHandler.getBoard(p);
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 200) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 200, false);
                Stats_FFA.setParam("PVPTraills", p.getUniqueId().toString(), "SMOKE", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Smoke."));
                ScoreboardHandler.getBoard(p);
            }
        }
    }
}
