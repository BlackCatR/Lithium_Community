package com.Reveas.Hub.Inventorys;

import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;

public class Hats implements Listener
{
    Inventory invToc;
    
    public Hats() {
        this.invToc = Bukkit.createInventory((InventoryHolder)null, 9, "�e� Hats");
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        if (e.getRightClicked().getType() == EntityType.VILLAGER) {
            final Villager v = (Villager)e.getRightClicked();
            if (v.getCustomName().equalsIgnoreCase("�e�lHats")) {
                e.setCancelled(true);
                final ItemStack item = new ItemStack(Material.STAINED_GLASS);
                final ItemMeta meta = item.getItemMeta();
                meta.setDisplayName("�aGlassHead");
                final ArrayList list = new ArrayList();
                list.add("");
                list.add("�7- Glass Head.");
                list.add("");
                list.add("�3Price: �e5000 Tokens");
                list.add("�8� �bClick to Convert");
                meta.setLore((List)list);
                item.setItemMeta(meta);
                final ItemStack itemxx = new ItemStack(Material.DAYLIGHT_DETECTOR);
                final ItemMeta metaxx = item.getItemMeta();
                metaxx.setDisplayName("�aBane Mask!");
                final ArrayList listxx = new ArrayList();
                listxx.add("");
                listxx.add("�7- Bane Mask.");
                listxx.add("");
                listxx.add("�3Price: �e5000 Tokens");
                listxx.add("�8� �bClick to Convert");
                metaxx.setLore((List)listxx);
                itemxx.setItemMeta(metaxx);
                final ItemStack itemxxitemxx = new ItemStack(Material.DROPPER);
                final ItemMeta metaxxmetaxx = itemxxitemxx.getItemMeta();
                metaxxmetaxx.setDisplayName("�aDropper Head");
                final ArrayList listxxlistxx = new ArrayList();
                listxxlistxx.add("");
                listxxlistxx.add("�7- Dropper Head.");
                listxxlistxx.add("");
                listxxlistxx.add("�3Price: �e5000 Tokens");
                listxxlistxx.add("�8� �bClick to Convert");
                metaxxmetaxx.setLore((List)listxxlistxx);
                itemxxitemxx.setItemMeta(metaxxmetaxx);
                final ItemStack o = new ItemStack(Material.EMERALD_BLOCK);
                final ItemMeta oMeta = o.getItemMeta();
                oMeta.setDisplayName("�aEmerald Head");
                final ArrayList a = new ArrayList();
                a.add("");
                a.add("�7- Emerald head");
                a.add("");
                a.add("�3Price: �e5000 Tokens");
                a.add("�8� �bClick to Convert");
                o.setItemMeta(oMeta);
                final ItemStack v2 = new ItemStack(Material.MELON_BLOCK);
                final ItemMeta vMeta = v2.getItemMeta();
                vMeta.setDisplayName("�aMelon Head");
                final ArrayList vov = new ArrayList();
                vov.add("");
                vov.add("�7- Emerald head");
                vov.add("");
                vov.add("�3Price: �e5000 Tokens");
                vov.add("�8� �bClick to Convert");
                v2.setItemMeta(vMeta);
                this.invToc.setItem(0, item);
                this.invToc.setItem(1, itemxx);
                this.invToc.setItem(2, itemxxitemxx);
                this.invToc.setItem(3, o);
                this.invToc.setItem(4, v2);
                p.openInventory(this.invToc);
            }
        }
    }
}
