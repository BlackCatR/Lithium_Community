package com.Reveas.Hub.Inventorys;

import org.bukkit.configuration.file.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.*;
import com.Reveas.Hub.Board.*;
import com.Reveas.Hub.Manager.*;
import org.bukkit.inventory.*;
import org.bukkit.event.*;

public class Hats1 implements Listener
{
    private static FileConfiguration config;
    
    static {
        Hats1.config = Main.getInstance().getConfig();
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� Hats")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aGlassHead") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 5000) {
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 5000, false);
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou succesfully bought �a�lGlass �ehat.");
                p.getInventory().setHelmet(new ItemStack(Material.GLASS));
                ScoreboardHandler.getBoard(p);
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
        else if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aBane Mask!") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 5000) {
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 5000, false);
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou succesfully bought �a�lBane Mask �ehat.");
                p.getInventory().setHelmet(new ItemStack(Material.DAYLIGHT_DETECTOR));
                ScoreboardHandler.getBoard(p);
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
        else if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aDropper Head") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 5000) {
                final Inventory inv = (Inventory)p.getInventory();
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 5000, false);
                p.getInventory().setHelmet(new ItemStack(Material.DROPPER));
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou succesfully bought �a�lDrroper �ehat.");
                ScoreboardHandler.getBoard(p);
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
        else if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aMelon Head") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 5000) {
                final Inventory inv = (Inventory)p.getInventory();
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 5000, false);
                p.getInventory().setHelmet(new ItemStack(Material.MELON_BLOCK));
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou succesfully bought �a�lMelon �ehat.");
                ScoreboardHandler.getBoard(p);
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
        else if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aEmerald Head") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 5000) {
                final Inventory inv = (Inventory)p.getInventory();
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 5000, false);
                p.getInventory().setHelmet(new ItemStack(Material.EMERALD_BLOCK));
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou succesfully bought �a�lEmerald �ehat.");
                ScoreboardHandler.getBoard(p);
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
    }
}
