package com.Reveas.Hub.Inventorys;

import org.bukkit.event.player.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;

public class Menu implements Listener
{
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        final Inventory invToc = Bukkit.createInventory((InventoryHolder)null, 9, "�e� Menu");
        e.setCancelled(true);
        final ItemStack item = new ItemStack(Material.STAINED_GLASS);
        final ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("�aGlassHead");
        final ArrayList list = new ArrayList();
        list.add("");
        list.add("�7- Glass Head.");
        list.add("");
        meta.setLore((List)list);
        item.setItemMeta(meta);
        final ItemStack itemxx = new ItemStack(Material.DAYLIGHT_DETECTOR);
        final ItemMeta metaxx = item.getItemMeta();
        metaxx.setDisplayName("�aBane Mask!");
        final ArrayList listxx = new ArrayList();
        listxx.add("");
        listxx.add("�7- Bane Mask.");
        listxx.add("");
        metaxx.setLore((List)listxx);
        itemxx.setItemMeta(metaxx);
        final ItemStack itemxxitemxx = new ItemStack(Material.DROPPER);
        final ItemMeta metaxxmetaxx = itemxxitemxx.getItemMeta();
        metaxxmetaxx.setDisplayName("�aDropper Head");
        final ArrayList listxxlistxx = new ArrayList();
        listxxlistxx.add("");
        listxxlistxx.add("�7- Dropper Head.");
        listxxlistxx.add("");
        metaxxmetaxx.setLore((List)listxxlistxx);
        itemxxitemxx.setItemMeta(metaxxmetaxx);
        final ItemStack o = new ItemStack(Material.EMERALD_BLOCK);
        final ItemMeta oMeta = o.getItemMeta();
        oMeta.setDisplayName("�aEmerald Head");
        final ArrayList a = new ArrayList();
        a.add("");
        a.add("�7- Emerald head");
        a.add("");
        o.setItemMeta(oMeta);
        final ItemStack v3 = new ItemStack(Material.STAINED_GLASS);
        final ItemMeta vMeta = v3.getItemMeta();
        vMeta.setDisplayName("�cYou don't have hats.");
        final ArrayList vov = new ArrayList();
        vov.add("");
        vov.add("");
        v3.setItemMeta(vMeta);
        invToc.setItem(0, item);
        invToc.setItem(1, itemxx);
        invToc.setItem(2, itemxxitemxx);
        invToc.setItem(3, o);
        p.openInventory(invToc);
    }
}
