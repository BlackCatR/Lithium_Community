package com.Reveas.Hub.Inventorys;

import org.bukkit.inventory.*;
import com.Reveas.Hub.Main.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import com.Reveas.Hub.Games.*;
import com.Reveas.Hub.Manager.*;
import org.bukkit.*;

public class SG implements Listener
{
    public static Inventory ShopSG;
    Inventory shop;
    
    public SG() {
        this.shop = Bukkit.createInventory((InventoryHolder)null, 45, "�e�lSurvivalGames shop");
    }
    
    public static ItemStack MySword() {
        final ItemStack g = new ItemStack(Material.IRON_SWORD);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�e�lMY Sword"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Makes all swords that you loot from");
        lore.add("�7chests be named after YOU!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�73000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack DeathCrate() {
        final ItemStack g = new ItemStack(Material.CHEST);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�e�lDeath Crate"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7When active, death crates spawn whenever");
        lore.add("�7you");
        lore.add("�7kill another player for easier looting.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�77000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilNote() {
        final ItemStack g = new ItemStack(Material.JUKEBOX);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lNote"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilFairy() {
        final ItemStack g = new ItemStack(Material.getMaterial(289));
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lFairy (ColouredDust)"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilFlame() {
        final ItemStack g = new ItemStack(Material.BLAZE_POWDER);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lFlame"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilCupid() {
        final ItemStack g = new ItemStack(Material.REDSTONE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lCupid (Hearts)"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilSmoke() {
        final ItemStack g = new ItemStack(Material.COAL_BLOCK);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lSmoke"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack ArrowTrilVillager() {
        final ItemStack g = new ItemStack(Material.EMERALD);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Arrow Trail \u25ba �e�lVillager Thundercloud"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this effect as");
        lore.add("�7an arrow trail.");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryAnvilDing() {
        final ItemStack g = new ItemStack(Material.ANVIL);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lAnvil Ding"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryBurp() {
        final ItemStack g = new ItemStack(Material.COOKIE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lBurp"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryDonkeyDeath() {
        final ItemStack g = new ItemStack(Material.getMaterial(420));
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lDonkey Death"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryFireworkWhizz() {
        final ItemStack g = new ItemStack(Material.FIREWORK);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lDonkey Death"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryHorseScreech() {
        final ItemStack g = new ItemStack(Material.getMaterial(419));
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lHorse Screech"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryLevelUpTune() {
        final ItemStack g = new ItemStack(Material.getMaterial(384));
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lLevel Up Tune"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryCatMeow() {
        final ItemStack g = new ItemStack(Material.getMaterial(349), 1, (short)0);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lCat Meow"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryRoaringThunder() {
        final ItemStack g = new ItemStack(Material.STONE);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lRoaring Thunder"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack BattleCryVillagerYes() {
        final ItemStack g = new ItemStack(Material.EMERALD);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Battle Cry \u25ba �e�lVillager Yes"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this sound as");
        lore.add("�7a Battle Cry!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorPurple() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)10);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lPurple"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorCyan() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)9);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lCyan"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorWhite() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)0);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lWhite"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorPink() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)6);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lPink"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorLime() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)11);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lBlue"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorLightBlue() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)15);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lBlack"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorMagenta() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)2);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lMagenta"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorOrange() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)1);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lOrange"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack LeatherColorRed() {
        final ItemStack g = new ItemStack(Material.WOOL, 1, (short)14);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8Leather Color \u25ba �e�lRed"));
        final ArrayList<String> lore = new ArrayList<String>();
        lore.add("");
        lore.add("�7Allows you to select this color as");
        lore.add("�7a your leather armor dye!");
        lore.add("");
        lore.add("�a�lCost");
        lore.add("�72000 Tokens");
        lore.add("");
        lore.add("�b\u25ba Click to purchase");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        if (e.getRightClicked().getType() == EntityType.VILLAGER) {
            final Villager v = (Villager)e.getRightClicked();
            if (v.getCustomName().equalsIgnoreCase("�e�lReveas�3�lSG �e�lShop")) {
                e.setCancelled(true);
                Stats_SG.createPlayer(p.getUniqueId().toString());
                this.shop.clear();
                this.shop.setItem(0, MySword());
                this.shop.setItem(1, DeathCrate());
                this.shop.setItem(3, ArrowTrilNote());
                this.shop.setItem(4, ArrowTrilFairy());
                this.shop.setItem(5, ArrowTrilFlame());
                this.shop.setItem(6, ArrowTrilCupid());
                this.shop.setItem(7, ArrowTrilSmoke());
                this.shop.setItem(8, ArrowTrilVillager());
                this.shop.setItem(18, BattleCryAnvilDing());
                this.shop.setItem(19, BattleCryBurp());
                this.shop.setItem(20, BattleCryDonkeyDeath());
                this.shop.setItem(21, BattleCryFireworkWhizz());
                this.shop.setItem(22, BattleCryHorseScreech());
                this.shop.setItem(23, BattleCryLevelUpTune());
                this.shop.setItem(24, BattleCryCatMeow());
                this.shop.setItem(25, BattleCryRoaringThunder());
                this.shop.setItem(26, BattleCryVillagerYes());
                this.shop.setItem(36, LeatherColorPurple());
                this.shop.setItem(37, LeatherColorCyan());
                this.shop.setItem(38, LeatherColorWhite());
                this.shop.setItem(39, LeatherColorPink());
                this.shop.setItem(40, LeatherColorLime());
                this.shop.setItem(41, LeatherColorLightBlue());
                this.shop.setItem(42, LeatherColorMagenta());
                this.shop.setItem(43, LeatherColorOrange());
                this.shop.setItem(44, LeatherColorRed());
                p.openInventory(this.shop);
            }
        }
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getTitle().contains("�e�lSurvivalGames shop")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getType() == MySword().getType()) {
                if (Stats_SG.getBoolean("SGSettings", p.getUniqueId().toString(), "MySword")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 3000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 3000, false);
                Stats_SG.setParam("SGSettings", p.getUniqueId().toString(), "MySword", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lMy Sword &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == DeathCrate().getType()) {
                if (Stats_SG.getBoolean("SGSettings", p.getUniqueId().toString(), "Chest")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    p.closeInventory();
                }
                else {
                    if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 7000) {
                        p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                        p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                        p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                        return;
                    }
                    Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 7000, false);
                    Stats_SG.setParam("SGSettings", p.getUniqueId().toString(), "Chest", "true");
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lChest&7 ! "));
                    p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
                }
            }
            if (e.getCurrentItem().getType() == ArrowTrilFairy().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "Fairy")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 7000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 7000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "Fairy", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lFairy &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == ArrowTrilNote().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "Note")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "Note", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lNote &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == ArrowTrilFlame().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "Flame")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "Flame", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lFlame &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == ArrowTrilCupid().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "Hearts")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "Hearts", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Heart &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == ArrowTrilSmoke().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "Smoke")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "Smoke", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Smoke &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == ArrowTrilVillager().getType()) {
                if (Stats_SG.getBoolean("SGTraills", p.getUniqueId().toString(), "VillagerThundercloud")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item"));
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGTraills", p.getUniqueId().toString(), "VillagerThundercloud", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lVillagerThunger&7 ! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryAnvilDing().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "Anvil")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "Anvil", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lAnvil! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryBurp().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "Burp")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "Burp", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Burp! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryDonkeyDeath().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "DonkeyDeath")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "DonkeyDeath", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l DonkeyDeath! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryFireworkWhizz().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "FireworkWhizz")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "FireworkWhizz", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Firework&7 ! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryHorseScreech().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "HorseScreech")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "HorseScreech", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l HorseScreech &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryLevelUpTune().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "Levelup")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "Levelup", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lLevelup &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryCatMeow().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "CatMeow")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "CatMeow", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lCatMeow &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryRoaringThunder().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "RoaringThunnder")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "RoaringThunnder", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lRoaringThunnder &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getCurrentItem().getType() == BattleCryVillagerYes().getType()) {
                if (Stats_SG.getBoolean("SGSounds", p.getUniqueId().toString(), "VillagerYes")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGSounds", p.getUniqueId().toString(), "VillagerYes", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lVillagerYes&7 ! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 36) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Purple")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Purple", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item&b&l Purple &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 37) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Cyan")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Cyan", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lCyan &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 38) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "White")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "White", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lWhite &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 39) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Pink")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Pink", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lPink &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 40) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Blue")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Blue", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lBlue &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 41) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Black")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Black", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lBlack &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 42) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Magenta")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Magenta", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lMagenta &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 43) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Orange")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Orange", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lOrange&7 ! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
            if (e.getSlot() == 44) {
                if (Stats_SG.getBoolean("SGLeather", p.getUniqueId().toString(), "Red")) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this item."));
                    p.closeInventory();
                    return;
                }
                if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) <= 2000) {
                    p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                    p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1.0f, 1.0f);
                    return;
                }
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 2000, false);
                Stats_SG.setParam("SGLeather", p.getUniqueId().toString(), "Red", "true");
                p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought item &b&lRed &7! "));
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
            }
        }
    }
}
