package com.Reveas.Hub.Inventorys;

import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;

public class Speed implements Listener
{
    Inventory invToc;
    
    public Speed() {
        this.invToc = Bukkit.createInventory((InventoryHolder)null, 9, "�e� Speed Shop");
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        try {
            if (e.getRightClicked().getType() == EntityType.VILLAGER) {
                final Villager v = (Villager)e.getRightClicked();
                if (v.getCustomName().equalsIgnoreCase("�e�lSpeed Shop")) {
                    e.setCancelled(true);
                    final ItemStack item = new ItemStack(Material.COOKIE);
                    final ItemMeta meta = item.getItemMeta();
                    meta.setDisplayName("�aSpeed");
                    final ArrayList list = new ArrayList();
                    list.add("");
                    list.add("�7- Gives you speed");
                    list.add("");
                    list.add("�3Price: �e100 Tokens �6\u272a");
                    list.add("�8� �bClick to Convert");
                    meta.setLore((List)list);
                    item.setItemMeta(meta);
                    final ItemStack itemxx = new ItemStack(Material.MILK_BUCKET);
                    final ItemMeta metaxx = item.getItemMeta();
                    metaxx.setDisplayName("�cFresh Milk");
                    final ArrayList listxx = new ArrayList();
                    listxx.add("");
                    listxx.add("�7- Remove your speed.");
                    listxx.add("");
                    listxx.add("�8� �bClick to remove");
                    metaxx.setLore((List)listxx);
                    itemxx.setItemMeta(metaxx);
                    this.invToc.setItem(0, item);
                    this.invToc.setItem(8, itemxx);
                    p.openInventory(this.invToc);
                }
            }
        }
        catch (Exception ex) {}
    }
}
