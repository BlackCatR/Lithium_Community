package com.Reveas.Hub.Inventorys;

import org.bukkit.configuration.file.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.potion.*;
import com.Reveas.Hub.Manager.*;
import org.bukkit.event.*;

public class Speed1 implements Listener
{
    private static FileConfiguration config;
    
    static {
        Speed1.config = Main.getInstance().getConfig();
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        if (!e.getInventory().getTitle().equalsIgnoreCase("�e� Speed Shop")) {
            return;
        }
        if (e.getCurrentItem().getType() == null) {
            return;
        }
        final Player p = (Player)e.getWhoClicked();
        e.setCancelled(true);
        if (e.getCurrentItem().getItemMeta().getDisplayName() == "�aSpeed") {
            if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) >= 100) {
                Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 100, false);
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 9999, 2));
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou succesfully bought �a�lSpeed �ecookie.");
                p.closeInventory();
            }
            else {
                p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                p.closeInventory();
            }
        }
        else if (e.getCurrentItem().getItemMeta().getDisplayName() == "�cFresh Milk") {
            p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cEffects removed.");
            p.removePotionEffect(PotionEffectType.SPEED);
        }
    }
}
