package com.Reveas.Hub.Inventorys;

import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;

public class Toc0 implements Listener
{
    Inventory invToc;
    
    public Toc0() {
        this.invToc = Bukkit.createInventory((InventoryHolder)null, 9, "�e� Tokens to Credits");
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        final Player p = e.getPlayer();
        try {
            if (e.getRightClicked().getType() == EntityType.VILLAGER) {
                final Villager v = (Villager)e.getRightClicked();
                if (v.getCustomName().equalsIgnoreCase("�e�lTokens to Credits")) {
                    e.setCancelled(true);
                    final ItemStack item = new ItemStack(Material.GOLD_INGOT);
                    final ItemMeta meta = item.getItemMeta();
                    meta.setDisplayName("�a1 Credits");
                    final ArrayList list = new ArrayList();
                    list.add("");
                    list.add("�7- Convert 1000 Tokens to 1 Credits.");
                    list.add("");
                    list.add("�3Price: �e1000 Tokens �6\u272a");
                    list.add("�8� �bClick to Convert");
                    meta.setLore((List)list);
                    item.setItemMeta(meta);
                    final ItemStack itemxx = new ItemStack(Material.GOLD_INGOT);
                    final ItemMeta metaxx = item.getItemMeta();
                    metaxx.setDisplayName("�a5 Credits");
                    final ArrayList listxx = new ArrayList();
                    listxx.add("");
                    listxx.add("�7- Convert 5000 Tokens to 5 Credits.");
                    listxx.add("");
                    listxx.add("�3Price: �e5000 Tokens �6\u272a");
                    listxx.add("�8� �bClick to Convert");
                    metaxx.setLore((List)listxx);
                    itemxx.setItemMeta(metaxx);
                    final ItemStack itemxxitemxx = new ItemStack(Material.GOLD_INGOT);
                    final ItemMeta metaxxmetaxx = itemxxitemxx.getItemMeta();
                    metaxxmetaxx.setDisplayName("�a10 Credits");
                    final ArrayList listxxlistxx = new ArrayList();
                    listxxlistxx.add("");
                    listxxlistxx.add("�7- Convert 10000 Tokens to 10 Credits.");
                    listxxlistxx.add("");
                    listxxlistxx.add("�3Price: �e10000 Tokens �6\u272a");
                    listxxlistxx.add("�8� �bClick to Convert");
                    metaxxmetaxx.setLore((List)listxxlistxx);
                    itemxxitemxx.setItemMeta(metaxxmetaxx);
                    this.invToc.setItem(2, item);
                    this.invToc.setItem(4, itemxx);
                    this.invToc.setItem(6, itemxxitemxx);
                    p.openInventory(this.invToc);
                }
            }
        }
        catch (Exception ex) {}
    }
}
