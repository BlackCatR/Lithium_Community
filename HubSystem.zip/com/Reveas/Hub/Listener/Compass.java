package com.Reveas.Hub.Listener;

import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.SuperBoots.*;
import org.bukkit.potion.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.plugin.*;
import com.Reveas.Hub.API.*;
import org.bukkit.inventory.meta.*;

public class Compass implements Listener
{
    public static String Select;
    
    static {
        Compass.Select = "�e�lSelect �b�lGames";
    }
    
    @EventHandler
    public void SelectGames(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack Item = e.getCurrentItem();
        if (e.getInventory().getTitle().equals("�7Where would you like to go?")) {
            e.setCancelled(true);
            if ((!Item.getType().equals((Object)Material.STAINED_GLASS_PANE) || !Item.getType().equals((Object)Material.IRON_FENCE)) && Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�b�lSky�e�lPVP") && Item.getType().equals((Object)Material.DIAMOND_CHESTPLATE)) {
                e.setCancelled(true);
                Main.connect(p, "SkyPVP");
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�e�lHub �b�lSelector") && Item.getType().equals((Object)Material.NETHER_STAR)) {
                e.setCancelled(true);
                InventoryClickListener.SelectHub(p);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�e�lReveas�3�lSG") && Item.getType().equals((Object)Material.ENDER_CHEST)) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp SurvivalGames");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�3�lOne�b�lShot")) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp OneShot");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�e�lGun�b�lGame")) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp GunGame");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�b�l�a�lV�b�lS")) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp VS");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�c�lStaff")) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp Staff");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�3�lMeeting") && Item.getType().equals((Object)Material.BOOK)) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp Meeting");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�d�lEnchanted Crystals") && Item.getType().equals((Object)Material.CLAY_BALL)) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp EnchantedCrystals");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�b�lParty�e�lPVP") && Item.getType().equals((Object)Material.EMERALD)) {
                e.setCancelled(true);
                p.closeInventory();
                p.chat("/warp PartyPVP");
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �3Teamspeak") && Item.getType().equals((Object)Material.GRASS)) {
                e.setCancelled(true);
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + Main.F("&3Teamspeak �8� &7Ts.ReveasMC.com"));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�3�lCreative") && Item.getType().equals((Object)Material.GRASS)) {
                e.setCancelled(true);
                Main.connect(p, "Creative");
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�4�lRedst�c�lonePVP") && Item.getType().equals((Object)Material.REDSTONE_BLOCK)) {
                e.setCancelled(true);
                Main.connect(p, "RedstonePVP");
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�7�lPrison") && Item.getType().equals((Object)Material.DIAMOND_PICKAXE)) {
                e.setCancelled(true);
                Main.connect(p, "Prsion");
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�e�lPVP") && Item.getType().equals((Object)Material.WOOD_SWORD)) {
                e.setCancelled(true);
                p.chat("/warp PVP");
                ActionBar.sendActionBar(p, "�e�lWelcome to �b�l" + e.getCurrentItem().getItemMeta().getDisplayName());
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "�bYou have been Teleported to �7" + e.getCurrentItem().getItemMeta().getDisplayName() + "�3...");
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 30, 999999));
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 999999));
            }
        }
    }
    
    @EventHandler
    public void oabn(final PlayerInteractEvent e) {
        final Player player = e.getPlayer();
        if ((e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) && player.getItemInHand().getType() == Material.COMPASS) {
            e.setCancelled(true);
            Compassa(player);
        }
    }
    
    public static void Compassa(final Player player) {
        final Inventory compass = Bukkit.createInventory((InventoryHolder)null, 54, "�7Where would you like to go?");
        final ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 15, 1);
        compass.setItem(0, placeholder);
        compass.setItem(1, placeholder);
        compass.setItem(2, placeholder);
        compass.setItem(3, placeholder);
        compass.setItem(4, placeholder);
        compass.setItem(5, placeholder);
        compass.setItem(6, placeholder);
        compass.setItem(7, placeholder);
        compass.setItem(8, placeholder);
        compass.setItem(9, placeholder);
        compass.setItem(17, placeholder);
        compass.setItem(18, placeholder);
        compass.setItem(26, placeholder);
        compass.setItem(27, placeholder);
        compass.setItem(28, placeholder);
        compass.setItem(29, placeholder);
        compass.setItem(30, placeholder);
        compass.setItem(31, placeholder);
        compass.setItem(32, placeholder);
        compass.setItem(33, placeholder);
        compass.setItem(34, placeholder);
        compass.setItem(35, placeholder);
        compass.setItem(36, placeholder);
        compass.setItem(37, placeholder);
        compass.setItem(38, placeholder);
        compass.setItem(39, placeholder);
        compass.setItem(41, placeholder);
        compass.setItem(42, placeholder);
        compass.setItem(43, placeholder);
        compass.setItem(10, placeholder);
        compass.setItem(11, placeholder);
        compass.setItem(12, placeholder);
        compass.setItem(13, placeholder);
        compass.setItem(14, placeholder);
        compass.setItem(15, placeholder);
        compass.setItem(16, placeholder);
        compass.setItem(19, placeholder);
        compass.setItem(20, placeholder);
        compass.setItem(21, placeholder);
        compass.setItem(22, placeholder);
        compass.setItem(23, placeholder);
        compass.setItem(24, placeholder);
        compass.setItem(25, placeholder);
        compass.setItem(26, placeholder);
        compass.setItem(27, placeholder);
        compass.setItem(28, placeholder);
        compass.setItem(29, placeholder);
        compass.setItem(30, placeholder);
        compass.setItem(31, placeholder);
        compass.setItem(32, placeholder);
        compass.setItem(34, placeholder);
        compass.setItem(35, placeholder);
        compass.setItem(36, placeholder);
        compass.setItem(37, placeholder);
        compass.setItem(38, placeholder);
        compass.setItem(39, placeholder);
        compass.setItem(40, placeholder);
        compass.setItem(41, placeholder);
        compass.setItem(42, placeholder);
        compass.setItem(43, placeholder);
        compass.setItem(44, placeholder);
        compass.setItem(45, placeholder);
        compass.setItem(46, placeholder);
        compass.setItem(47, placeholder);
        compass.setItem(48, placeholder);
        compass.setItem(49, placeholder);
        compass.setItem(50, placeholder);
        compass.setItem(51, placeholder);
        compass.setItem(52, placeholder);
        compass.setItem(53, placeholder);
        compass.setItem(53, ItemUtils.getItem(Material.PAPER, "�8� �3Teamspeak", "�8� �7Currently Players Ts �7�l\u25bb ", 0, 1));
        final ItemStack GG = ItemUtils.getItem(Material.WOOD_AXE, "�e�lGun�b�lGame", "�7\n�7�7Axe to attack to train your PVP Skills\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + getGG() + "�8\n \n�a�l\u279c�a Click to warp to GunGame", 0, 1);
        compass.setItem(10, GG);
        final ItemStack Bow = ItemUtils.getItem(Material.BOW, "�3�lOne�b�lShot", "�7\n�7�7you can that RobenHod to train your PVP Skills\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + getOS() + "�8\n \n�a�l\u279c�a Click to warp to Bow", 0, 1);
        compass.setItem(16, Bow);
        final ItemStack VS = ItemUtils.getItem(Material.IRON_SWORD, "�b�l�a�lV�b�lS", "�7\n�7The name desccribes everything.\n�7Have a fair fight against one nother player.\n�7The first player to score 3 points wins the game.\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + get1vs1() + "�8\n \n�a�l\u279c�a Click to warp to 1vs1 , 2vs2", 0, 1);
        compass.setItem(13, VS);
        final ItemStack Item14 = ItemUtils.getItem(Material.IRON_FENCE, "�c\u2716", "�8\n\n�a�l\u279c�a Coming soon", 0, 1);
        compass.setItem(45, ItemUtils.getItem(Material.BOOK, "�8� �aStore", "", 0, 1));
        compass.setItem(50, ItemUtils.getItem(Material.SLIME_BALL, "�e�lTelport to spawn", "�7", 0, 1));
        compass.setItem(49, ItemUtils.getItem(Material.NETHER_STAR, "�e�lHub �b�lSelector", "�7", 0, 1));
        compass.setItem(48, ItemUtils.getItem(Material.CLAY_BALL, "�d�lEnchanted Crystals", "�7", 0, 1));
        final ItemStack Item15 = ItemUtils.getItem(Material.ENDER_CHEST, "�e�lReveas�3�lSG", "�7\n�7Our world-famous SurvivalGames. \n�724 players enter a mysterious\n�7world filled with chests. Loot the\n �7chests and survive. The list man\n�7 standing is the winner.\n�2\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + getSG() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack PVP = ItemUtils.getItem(Material.WOOD_SWORD, "�e�lPVP", "�7\n�7Free for all, you can that king the pvp\n�7kits to train your PVP Skills\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + Main.getServerOnlinePlayers("127.0.0.1", 25110) + "�8\n \n�a�l\u279c�a Click to warp to PVP", 0, 1);
        final ItemStack thebridge = ItemUtils.getItem(Material.IRON_FENCE, "�c\u2716", "�7\n�7Coming soon.\n�2\n�7\n�8� �7offline �7�l\u25bb�b �8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Item16 = ItemUtils.getItem(Material.SKULL_ITEM, "�c�lStaff", "\n�b�lOnline Players \n�7" + Bukkit.getWorld("Staff").getPlayers().size() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Item17 = ItemUtils.getItem(Material.IRON_FENCE, "�4�lRedst�c�lonePVP", "\n�b�lOnline Players \n�7" + Main.getServerOnlinePlayers("127.0.0.1", 12345) + "�8\n\n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Item18 = ItemUtils.getItem(Material.BOOK, " �3�lMeeting ", "\n�b�lOnline Players \n�7" + Bukkit.getWorld("Hub2").getPlayers().size() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Item19 = ItemUtils.getItem(Material.EMERALD, "�b�lParty�e�lPVP", "�7\n�7Create Party and invite your friends\n �7to join it or just keep it public and anyone\n �7can join. \n�2\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + getPartyPVP() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Item20 = ItemUtils.getItem(Material.DIAMOND_CHESTPLATE, "�b�lSky�e�lPVP", "�7\n�7Fight in the sky beat your oppenents \n �7and be the richests player. \n�2\n�7\n�8� �7Currently Playing �7�l\u25bb�b " + Main.getServerOnlinePlayers("127.0.0.1", 3030) + "�8\n \n�a�l\u279c�a Offline", 0, 1);
        final ItemStack Item21 = ItemUtils.getItem(Material.GRASS, "�3�lCreative", "\n�b�lOnline Players \n�7" + Main.getServerOnlinePlayers("127.0.0.1", 1000) + "�8\n\n�a�l\u279c�a Click to join", 0, 1);
        Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
            @Override
            public void run() {
                compass.setItem(20, PVP);
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        compass.setItem(22, Item15);
                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 2.0f);
                        Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                compass.setItem(23, Item16);
                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                    @Override
                                    public void run() {
                                        compass.setItem(24, Item17);
                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                        Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                            @Override
                                            public void run() {
                                                compass.setItem(21, Item18);
                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 2.0f);
                                                Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        compass.setItem(29, Item19);
                                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                        Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                compass.setItem(30, Item20);
                                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 2.0f);
                                                                Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        compass.setItem(31, Item21);
                                                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 2.0f);
                                                                        Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                                            @Override
                                                                            public void run() {
                                                                                compass.setItem(32, thebridge);
                                                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                                                Main.SelectGames = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                                                    @Override
                                                                                    public void run() {
                                                                                        compass.setItem(33, Item14);
                                                                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 2.0f);
                                                                                    }
                                                                                }, 1L);
                                                                            }
                                                                        }, 1L);
                                                                    }
                                                                }, 1L);
                                                            }
                                                        }, 1L);
                                                    }
                                                }, 1L);
                                            }
                                        }, 1L);
                                    }
                                }, 1L);
                            }
                        }, 1L);
                    }
                }, 1L);
            }
        }, 1L);
        player.openInventory(compass);
    }
    
    public static int getPartyPVP() {
        final ServerListPing vs1 = new ServerListPing("localhost", 25105);
        final ServerListPing vs2 = new ServerListPing("localhost", 24522);
        final int i = vs1.getPlayersOnline() + vs2.getPlayersOnline();
        return i;
    }
    
    public static int get1vs1() {
        final ServerListPing vs1 = new ServerListPing("localhost", 25120);
        final ServerListPing vs2 = new ServerListPing("localhost", 25121);
        final ServerListPing vs3 = new ServerListPing("localhost", 25122);
        final ServerListPing vs4 = new ServerListPing("localhost", 25123);
        final ServerListPing vs5 = new ServerListPing("localhost", 25124);
        final ServerListPing vs6 = new ServerListPing("localhost", 25125);
        final ServerListPing vs7 = new ServerListPing("localhost", 25126);
        final ServerListPing vs8 = new ServerListPing("localhost", 25127);
        final ServerListPing vs9 = new ServerListPing("localhost", 25128);
        final ServerListPing vs10 = new ServerListPing("localhost", 25129);
        final int i = vs1.getPlayersOnline() + vs2.getPlayersOnline() + vs3.getPlayersOnline() + vs4.getPlayersOnline() + vs5.getPlayersOnline() + vs6.getPlayersOnline() + vs7.getPlayersOnline() + vs8.getPlayersOnline() + vs9.getPlayersOnline() + vs10.getPlayersOnline();
        return i;
    }
    
    public static int getSG() {
        final ServerListPing sg1 = new ServerListPing("localhost", 25131);
        final ServerListPing sg2 = new ServerListPing("localhost", 25132);
        final ServerListPing sg3 = new ServerListPing("localhost", 25133);
        final ServerListPing sg4 = new ServerListPing("localhost", 25134);
        final ServerListPing sg5 = new ServerListPing("localhost", 25135);
        final int i = sg1.getPlayersOnline() + sg2.getPlayersOnline() + sg3.getPlayersOnline() + sg4.getPlayersOnline() + sg5.getPlayersOnline();
        return i;
    }
    
    public static int getGG() {
        final ServerListPing gg1 = new ServerListPing("localhost", 25101);
        final ServerListPing gg2 = new ServerListPing("localhost", 25102);
        final ServerListPing gg3 = new ServerListPing("localhost", 25103);
        final int i = gg1.getPlayersOnline() + gg2.getPlayersOnline() + gg3.getPlayersOnline();
        return i;
    }
    
    public static int getOS() {
        final ServerListPing gg1 = new ServerListPing("localhost", 3001);
        final ServerListPing gg2 = new ServerListPing("localhost", 3002);
        final ServerListPing gg3 = new ServerListPing("localhost", 3003);
        final int i = gg1.getPlayersOnline() + gg2.getPlayersOnline() + gg3.getPlayersOnline();
        return i;
    }
    
    public static ItemStack create(final int id, final int subid, final int amount, final String DisplayName, final String string) {
        final ItemStack is = new ItemStack(id, amount, (short)subid);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName(DisplayName);
        is.setItemMeta(im);
        return is;
    }
}
