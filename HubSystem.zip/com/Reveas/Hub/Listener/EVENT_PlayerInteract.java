package com.Reveas.Hub.Listener;

import org.bukkit.event.player.*;
import org.bukkit.block.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.plugin.*;
import org.bukkit.entity.*;
import java.util.*;
import com.google.common.io.*;
import org.bukkit.event.*;

public class EVENT_PlayerInteract implements Listener
{
    @EventHandler
    public void onInteract(final PlayerInteractEvent e) {
        final Player player = e.getPlayer();
        if (e.getClickedBlock() != null && e.getClickedBlock().getState() != null && e.getClickedBlock().getState() instanceof Sign) {
            if (!Main.plugin.getSignLocs.contains(e.getClickedBlock().getLocation())) {
                return;
            }
            if (((Sign)e.getClickedBlock().getState()).getLine(2).contains("�8�lRestarting")) {
                player.sendMessage(String.valueOf(Main.prefix) + Main.F("&cPlease waiting server is restarting"));
            }
            if (((Sign)e.getClickedBlock().getState()).getLine(1).contains("�8�lWating for")) {
                player.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�cSorry �e" + player.getPlayerListName() + "�c, but this server is offline or restarting.");
                return;
            }
            for (final String s : Main.plugin.getConfig().getStringList("Servers.List")) {
                final String name = s.split(";")[0];
                final String displayname = s.split(";")[1];
                if (((Sign)e.getClickedBlock().getState()).getLine(0).contains(displayname)) {
                    final ByteArrayDataOutput out = ByteStreams.newDataOutput();
                    out.writeUTF("Connect");
                    out.writeUTF(name);
                    player.sendPluginMessage((Plugin)Main.plugin, "BungeeCord", out.toByteArray());
                }
            }
        }
    }
}
