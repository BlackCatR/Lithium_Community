package com.Reveas.Hub.Listener;

import org.bukkit.event.block.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Signsystem.*;
import java.util.*;
import org.bukkit.event.*;

public class EVENT_SignChange implements Listener
{
    @EventHandler
    public void onSignChange(final SignChangeEvent e) {
        if (Main.plugin.createSign.contains(e.getPlayer())) {
            if (e.getLine(0).isEmpty() || e.getLine(1).isEmpty() || e.getLine(2).isEmpty() || e.getLine(3).isEmpty()) {
                e.getPlayer().sendMessage(String.valueOf(Main.prefix) + "�cremovesign!");
                return;
            }
            final String name = e.getLine(0);
            final String displayname = e.getLine(1);
            final String ip = e.getLine(2);
            final Integer port = Integer.valueOf(e.getLine(3));
            final List<String> list = (List<String>)Main.plugin.getConfig().getStringList("Servers.List");
            list.add(String.valueOf(name) + ";" + displayname + ";" + ip + ";" + port);
            Main.plugin.getConfig().set("Servers.List", (Object)list);
            Main.plugin.getConfig().set("Servers.Location." + displayname + ".World", (Object)e.getBlock().getWorld().getName());
            Main.plugin.getConfig().set("Servers.Location." + displayname + ".X", (Object)e.getBlock().getX());
            Main.plugin.getConfig().set("Servers.Location." + displayname + ".Y", (Object)e.getBlock().getY());
            Main.plugin.getConfig().set("Servers.Location." + displayname + ".Z", (Object)e.getBlock().getZ());
            Main.plugin.saveConfig();
            Main.plugin.createSign.remove(e.getPlayer());
            Main.plugin.getSignLocs.add(e.getBlock().getLocation());
            Main.plugin.getRealName.put(e.getBlock().getLocation(), name);
            Main.plugin.getDisplayName.put(e.getBlock().getLocation(), displayname);
            Main.plugin.servers.put(name, new ServerInfo(name, displayname, ip, port, 250, e.getBlock().getLocation()));
            e.getPlayer().sendMessage(String.valueOf(Main.prefix) + " Sign System has been create.");
        }
    }
}
