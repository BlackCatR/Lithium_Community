package com.Reveas.Hub.Listener;

import org.bukkit.entity.*;
import com.Reveas.Hub.Utils.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.event.*;
import com.Reveas.Hub.API.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import org.bukkit.plugin.*;
import org.bukkit.inventory.*;
import org.bukkit.event.inventory.*;
import org.bukkit.potion.*;
import java.util.*;

public class HideListener implements Listener
{
    ArrayList<Player> inShowPlayer;
    ArrayList<Player> inHidePlayer;
    public static String Hide;
    public static FriendsUtils utils;
    
    static {
        HideListener.Hide = "�7�7Players �8� �aShow";
    }
    
    public HideListener() {
        this.inShowPlayer = new ArrayList<Player>();
        this.inHidePlayer = new ArrayList<Player>();
    }
    
    @EventHandler
    public void oabn(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        try {
            if ((e.getAction() == Action.RIGHT_CLICK_AIR && p.getInventory().getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�7�7Players �8� �6Premium")) || p.getInventory().getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�7�7Players �8� �cHiden") || p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�7Players �8\u279f �aVisiblilty") || p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("�7�7Players �8� �aShow")) {
                openPlayerHider(p);
            }
        }
        catch (Exception ex) {}
    }
    
    public static void openPlayerHider(final Player player) {
        final Inventory playerhider = Bukkit.createInventory((InventoryHolder)null, InventoryType.BREWING, "�7Players �8\u279f �aVisiblilty");
        final ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, " ", "", 0, 1);
        Main.HidePlayer = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
            @Override
            public void run() {
                playerhider.setItem(3, ItemUtils.getItemWithID(130, "�7Do you want to hide the players? ", "�afrom here and choose what you want", 0, 1));
                player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1.0f, 1.0f);
                player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0f, 1.0f);
                Main.HidePlayer = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        playerhider.setItem(0, ItemUtils.getItemWithID(351, "�7Players �8� �aShow", "", 10, 1));
                        player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1.0f, 1.0f);
                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0f, 2.0f);
                        Main.HidePlayer = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                playerhider.setItem(1, ItemUtils.getItemWithID(351, "�7Player �8� �6Premium", "", 13, 1));
                                player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1.0f, 1.0f);
                                player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0f, 3.0f);
                                Main.HidePlayer = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                    @Override
                                    public void run() {
                                        playerhider.setItem(2, ItemUtils.getItemWithID(351, "�7Players �8� �cHide", " ", 8, 1));
                                        player.playSound(player.getLocation(), Sound.FIREWORK_BLAST, 1.0f, 1.0f);
                                        player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0f, 4.0f);
                                    }
                                }, 2L);
                            }
                        }, 2L);
                    }
                }, 2L);
            }
        }, 2L);
        player.openInventory(playerhider);
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getTitle().equalsIgnoreCase("�7Players �8\u279f �aVisiblilty")) {
            e.setCancelled(true);
            if (e.getSlot() == 0) {
                if (this.inShowPlayer.contains(p)) {
                    p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �aShow", "�afrom here and choose what you want", 10, 1));
                    p.sendMessage(String.valueOf(Main.prefix) + "�aNow all players all shown.");
                    p.closeInventory();
                }
                else {
                    this.inShowPlayer.add(p);
                    this.inHidePlayer.remove(p);
                    for (final Player all : Bukkit.getOnlinePlayers()) {
                        all.showPlayer(all);
                    }
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �aShow", "�afrom here and choose what you want", 10, 1));
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
                    p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
                    p.sendMessage(String.valueOf(Main.prefix) + "�aNow all players all shown.");
                    p.closeInventory();
                }
            }
            if (e.getSlot() == 1) {
                if (this.inHidePlayer.contains(p)) {
                    p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �cHiden", "�afrom here and choose what you want", 8, 1));
                    p.sendMessage(String.valueOf(Main.prefix) + "�cNow no players will be shown.");
                    p.closeInventory();
                }
                else {
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �cHiden", "�afrom here and choose what you want", 8, 1));
                    this.inHidePlayer.add(p);
                    this.inShowPlayer.remove(p);
                    this.hidePlayers(p);
                    p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
                    p.sendMessage(String.valueOf(Main.prefix) + "�cNow no players will be shown.");
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
                    p.closeInventory();
                }
            }
            if (e.getSlot() == 2) {
                if (this.inHidePlayer.contains(p)) {
                    p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
                    p.sendMessage(String.valueOf(Main.prefix) + "�7Now only players from the server premium will be shown.");
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �6Premium", "�afrom here and choose what you want", 13, 1));
                    p.closeInventory();
                }
                else {
                    this.inHidePlayer.add(p);
                    this.inShowPlayer.remove(p);
                    this.showonlyVIPPlayers(p);
                    p.getInventory().setItem(6, ItemUtils.getItemWithID(351, "�7�7Players �8� �6Premium", "�afrom here and choose what you want", 13, 1));
                    p.sendMessage(String.valueOf(Main.prefix) + "�7Now only players from the server premium will be shown.");
                    p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0f, 1.0f);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
                    p.closeInventory();
                }
            }
        }
    }
    
    public void hidePlayers(final Player p) {
        for (final Player all : Bukkit.getOnlinePlayers()) {
            if (all.hasPermission("Owner")) {
                p.hidePlayer(all);
            }
        }
    }
    
    public void showPlayers(final Player p) {
        for (final Player all : Bukkit.getOnlinePlayers()) {
            p.showPlayer(all);
        }
    }
    
    public void showonlyVIPPlayers(final Player p) {
        for (final Player all : Bukkit.getOnlinePlayers()) {
            if (all.hasPermission("VIP") || all.hasPermission("HeadAdmin") || all.hasPermission("Builder") || all.hasPermission("Mod") || all.hasPermission("Emerald") || all.hasPermission("Diamond") || all.hasPermission("Gold") || all.hasPermission("Owner") || all.hasPermission("Admin") || all.hasPermission("SrMod")) {
                p.showPlayer(all);
            }
            else {
                p.hidePlayer(all);
            }
        }
    }
}
