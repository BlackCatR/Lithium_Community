package com.Reveas.Hub.Listener;

import org.bukkit.entity.*;
import com.Reveas.Hub.API.*;
import org.bukkit.inventory.*;
import org.bukkit.event.inventory.*;
import com.Reveas.Hub.Profile.*;
import org.bukkit.event.*;
import com.Reveas.Hub.Utils.*;
import com.Reveas.api.util.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;

public class InventoryClickListener implements Listener
{
    public static String Premium;
    
    public static void SelectHub(final Player p) {
        final Inventory Hub = Bukkit.createInventory((InventoryHolder)null, 9, "Select a Hub");
        final ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, "�8� �7�lGlass �8�", "", 15, 1);
        final ItemStack Hub2 = ItemUtils.getItem(Material.MAGMA_CREAM, "�8� �eHub-1 �8�", "\n�b�lOnline Players \n�7" + Bukkit.getWorld("Hub").getPlayers().size() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Hub3 = ItemUtils.getItem(Material.SLIME_BALL, "�8� �eHub-2 �8�", "\n�b�lOnline Players \n�7" + Bukkit.getWorld("Hub2").getPlayers().size() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        final ItemStack Hub4 = ItemUtils.getItem(Material.SLIME_BALL, "�8� �eHub-3 �8�", "\n�b�lOnline Players \n�7" + Bukkit.getWorld("Hub3").getPlayers().size() + "�8\n \n�a�l\u279c�a Click to join", 0, 1);
        Hub.setItem(0, Hub2);
        Hub.setItem(1, Hub3);
        Hub.setItem(2, Hub4);
        p.openInventory(Hub);
    }
    
    @EventHandler
    public void Hats(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final Player p2 = (Player)e.getWhoClicked();
        final ItemStack Item = e.getCurrentItem();
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �e�lReveas�7�lGlass �8�")) {
            e.setCancelled(true);
            p.closeInventory();
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�c�lExit") && Item.getType().equals((Object)Material.ARROW)) {
            e.setCancelled(true);
            p.closeInventory();
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�c�lExit to profile") && Item.getType().equals((Object)Material.ARROW)) {
            e.setCancelled(true);
            Profile.openProfil(p);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�c�lHub to Spawn") && Item.getType().equals((Object)Material.ARROW)) {
            e.setCancelled(true);
            p.teleport(Bukkit.getServer().getWorld("Hub").getSpawnLocation());
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �eHub-1 �8�") && Item.getType().equals((Object)Material.MAGMA_CREAM)) {
            e.setCancelled(true);
            p.teleport(Bukkit.getServer().getWorld("Hub").getSpawnLocation());
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �eHub-2 �8�") && Item.getType().equals((Object)Material.SLIME_BALL)) {
            e.setCancelled(true);
            p.teleport(Bukkit.getServer().getWorld("Hub").getSpawnLocation());
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �eHub-3 �8�") && Item.getType().equals((Object)Material.SLIME_BALL)) {
            e.setCancelled(true);
            p.teleport(Bukkit.getServer().getWorld("Hub").getSpawnLocation());
        }
    }
    
    public static void Hatinv(final Player p) {
        final com.Reveas.Hub.Main.Player RS = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        final Inventory compass = Bukkit.createInventory((InventoryHolder)null, 45, "�7[RM] This your gift hats");
        final ItemStack Remove = ItemUtils.getItem(Material.BARRIER, ItemUtil.format("&8� &c&l\u2716 &4Remove Hats &8�"), "", 0, 1);
        compass.setItem(40, Remove);
        p.openInventory(compass);
        final ItemStack Close = ItemUtils.getItem(Material.ARROW, "�cBack!", "", 0, 1);
        compass.setItem(44, Close);
        p.openInventory(compass);
        final ItemStack Store = ItemUtils.getItem(Material.GOLD_INGOT, "�8� �aStore", "", 0, 1);
        compass.setItem(36, Store);
        p.openInventory(compass);
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item1 = ItemUtils.getItem(Material.STAINED_GLASS, "�7White �eHat", "", 0, 1);
            compass.addItem(new ItemStack[] { item1 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item2 = ItemUtils.getItem(Material.STAINED_GLASS, "�6Orange �eHat", "", 1, 1);
            compass.addItem(new ItemStack[] { item2 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item3 = ItemUtils.getItem(Material.STAINED_GLASS, "�5Magenta �eHat", "", 2, 1);
            compass.addItem(new ItemStack[] { item3 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item4 = ItemUtils.getItem(Material.GLASS, "�fGlass �eHat", "", 0, 1);
            compass.addItem(new ItemStack[] { item4 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item5 = ItemUtils.getItem(Material.STAINED_GLASS, "�eYellow �eHat", "", 4, 1);
            compass.addItem(new ItemStack[] { item5 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item6 = ItemUtils.getItem(Material.STAINED_GLASS, "�aLime �eHat", "", 5, 1);
            compass.addItem(new ItemStack[] { item6 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.GOLD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�dPink �eHat", "", 6, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.DIAMOND)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�0Light �1Blue �eHat", "", 3, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.DIAMOND)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�fLight�7 Gray �eHat", "", 8, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.DIAMOND)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�3Cyan �eHat", "", 9, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.DIAMOND)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�5Purple �eHat", "", 10, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.EMERALD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�1Blue �eHat", "", 11, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.EMERALD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�8Brown �eHat", "", 12, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.EMERALD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�aGreen �eHat", "", 13, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.EMERALD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�4Red �eHat", "", 14, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
        if (RS.checkPermission(p.getName(), Rank.EMERALD)) {
            final ItemStack item7 = ItemUtils.getItem(Material.STAINED_GLASS, "�0Black �eHat", "", 15, 1);
            compass.addItem(new ItemStack[] { item7 });
            p.openInventory(compass);
        }
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack clicked = e.getCurrentItem();
        final ItemStack Item = e.getCurrentItem();
        if (e.getInventory().getTitle().contains("�7[RM] This your gift hats")) {
            e.setCancelled(true);
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�7White �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �f�lWhite Glass �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)0));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�6Orange �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �6�lOrange Glass �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)1));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�5Magenta �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �5�lMagenta �bhat�b!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)2));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�fGlass �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �f�lGlass �bhat�b!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(20), 1, (short)0));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�eYellow �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �e�lYellow �bhat�b!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)4));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�aLime �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �a�lLime �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)5));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�dPink �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �d�lPink �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)6));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�0Light �1Blue �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �f�lLight�1�lBlue �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)3));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�fLight�7 Gray �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �f�lLight�7�lGray �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)8));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�3Cyan �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �3�lCyan �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)9));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�5Purple �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �5�lPurple �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)10));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�1Blue �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �1�lBlue �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)11));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8Brown �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �8�lBrown �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)12));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�aGreen �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �a�lGreen �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)13));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�4Red �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �4�lRed �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)14));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�0Black �eHat")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�bEnjoy your �0�lBlack �bhat!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(95), 1, (short)15));
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("&8� &c&l\u2716 &4Remove Hats &8�")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully Clear Hats!");
                e.setCancelled(true);
                p.closeInventory();
                p.getInventory().setHelmet(new ItemStack(Material.getMaterial(0), 1, (short)0));
            }
        }
    }
    
    @EventHandler
    public void onMenu(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        if ((e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) && p.getItemInHand().getType() == Material.REDSTONE_COMPARATOR && e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(Main.Color("&e\u279c &7&lSettings"))) {
            Profile.Settings(p);
        }
        if ((e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) && p.getItemInHand().getType() == Material.SKULL_ITEM) {
            e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(InventoryClickListener.Premium);
            Profile.openProfil(p);
        }
    }
    
    @EventHandler
    public void inv(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final String wings = "";
        final ItemStack Item = e.getCurrentItem();
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�cBack!") && Item.getType().equals((Object)Material.ARROW)) {
            e.setCancelled(true);
            Profile.openProfil(p);
            p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
        }
    }
}
