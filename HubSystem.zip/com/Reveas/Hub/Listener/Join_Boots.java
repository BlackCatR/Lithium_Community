package com.Reveas.Hub.Listener;

import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class Join_Boots implements Listener
{
    @EventHandler
    public void onJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        p.setWalkSpeed(0.2f);
        p.setAllowFlight(false);
    }
}
