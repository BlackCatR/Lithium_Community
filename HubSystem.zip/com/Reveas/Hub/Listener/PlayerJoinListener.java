package com.Reveas.Hub.Listener;

import org.bukkit.entity.*;
import org.bukkit.event.*;
import com.Reveas.api.*;
import org.bukkit.event.player.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.util.*;
import com.Reveas.api.managers.*;
import com.Reveas.Hub.Board.*;
import com.Reveas.Hub.Gadgets.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import com.Reveas.Hub.Utils.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.inventory.meta.*;

public class PlayerJoinListener implements Listener
{
    @EventHandler
    public void onJoin(final PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        if (ArrayAndHash.Lobby.contains(p.getName())) {
            ArrayAndHash.Lobby.remove(p.getName());
        }
    }
    
    public static float getExpPercent(final Player p) {
        final ReveasPlayer hp = Reveas.getPlayer(p.getName());
        if (hp.getLevel() == 0.0f) {
            return 0.0f;
        }
        return (float)(hp.getLevel() / LevelSystem.getMaxXP((int)hp.getLevel()));
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        if (Main.mysqlsg.isclose()) {
            Main.mysql.connect();
            Main.mysqlsg.connect();
        }
        Main.ReveasPets.add(p);
        final com.Reveas.Hub.Main.Player info = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
        Main.addPlayerInfo(p.getName(), info);
        Main.Lobby.add(p.getName());
        if (info.getRank() == Rank.DIAMOND.toString()) {
            p.setAllowFlight(true);
        }
        else {
            p.setAllowFlight(false);
        }
        p.getInventory().clear();
        p.setGameMode(GameMode.ADVENTURE);
        p.setDisplayName(String.valueOf(info.getRankColor()) + p.getName());
        TitleAPI.sendTitle(e.getPlayer(), Integer.valueOf(0), Integer.valueOf(20), Integer.valueOf(0), "�bPlay.�aReveasMC�b.com", "�8� �b�lWelcome �e�o" + p.getDisplayName());
        e.setJoinMessage((String)null);
        p.setGameMode(GameMode.SURVIVAL);
        p.setHealthScale(6.0);
        p.setFoodLevel(20);
        p.setLevel(info.getLevel());
        p.setExp(getExpPercent(p));
        ScoreboardHandler.getJoin(p);
        Bukkit.getOnlinePlayers().forEach(players -> ScoreboardHandler.RegisterTag(players.getScoreboard()));
        p.getInventory().setItem(1, gadget.FunGun());
        Main.normal(new ItemStack(Material.COMPASS), (Inventory)p.getInventory(), null, p, Compass.Select, 0);
        Main.normal(new ItemStack(Material.REDSTONE_COMPARATOR), (Inventory)p.getInventory(), null, p, Main.Color("&e\u279c &7&lSettings"), 8);
        p.getInventory().setItem(4, createSkull(Material.SKULL_ITEM, 1, p.getName(), String.valueOf(p.getDisplayName()) + "'s �7Profile"));
        p.getInventory().setItem(6, (ItemStack)null);
        Main.normal(new ItemStack(Material.getMaterial(351), 1, (short)10), (Inventory)p.getInventory(), "", p, "�7Players �8\u279f �aVisiblilty", 6);
        Main.normal(new ItemStack(Material.EMERALD), (Inventory)p.getInventory(), null, p, String.valueOf(String.valueOf(String.valueOf(String.valueOf(ChatColor.YELLOW.toString())))) + Stats_HubSystem.getCrystals(e.getPlayer().getUniqueId().toString()) + ChatColor.AQUA + " Enchanted Crystals", 7);
        if (!Stats_HubSystem.playerExists(p.getUniqueId().toString())) {
            ConfigManager.warpPlayer(Bukkit.getPlayer(p.getUniqueId().toString()), "Spawn");
            Stats_FFA.createPlayer(p.getUniqueId().toString());
            Stats_HubSystem.createPlayer(p.getUniqueId().toString());
        }
        else {
            Stats_HubSystem.setParam("Hub", p.getUniqueId().toString(), "Rank", info.getRank());
        }
    }
    
    public static ItemStack createSkull(final Material Material, final int Amount, final String Playername, final String Displayname) {
        final ItemStack I = new ItemStack(Material, Amount, (short)3);
        final SkullMeta Im = (SkullMeta)I.getItemMeta();
        Im.setDisplayName(Displayname);
        Im.setOwner(Playername);
        I.setItemMeta((ItemMeta)Im);
        return I;
    }
    
    @EventHandler
    public void onJoina(final PlayerQuitEvent e) {
        e.setQuitMessage((String)null);
    }
}
