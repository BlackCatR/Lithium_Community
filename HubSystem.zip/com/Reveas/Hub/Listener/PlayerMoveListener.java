package com.Reveas.Hub.Listener;

import java.util.*;
import org.bukkit.event.player.*;
import org.bukkit.util.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.*;
import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;

public class PlayerMoveListener implements Listener
{
    public static Integer JJ;
    public ArrayList<String> jump;
    
    public PlayerMoveListener() {
        this.jump = new ArrayList<String>();
    }
    
    @EventHandler
    public void onMov2e(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        final Location loc = p.getLocation();
        if ((loc.subtract(0.0, 0.0, 0.0).getBlock().getType() == Material.GOLD_PLATE || loc.subtract(0.0, 0.0, 0.0).getBlock().getType() == Material.REDSTONE_BLOCK) && !this.jump.contains(p.getName())) {
            p.getWorld().playSound(p.getLocation(), Sound.ORB_PICKUP, 3.0f, 3.0f);
            p.getWorld().playEffect(p.getLocation(), Effect.FLAME, 3);
            final Vector v = new Vector(p.getLocation().getDirection().getX() * 5.0, 4.0, p.getLocation().getDirection().getZ() * 5.0);
            p.setVelocity(v);
            this.jump.add(p.getName());
            PlayerMoveListener.JJ = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                @Override
                public void run() {
                    p.getWorld().playSound(p.getLocation(), Sound.WITHER_IDLE, 3.0f, 3.0f);
                    final Vector v = new Vector(p.getLocation().getDirection().getX() * 5.0, -4.0, p.getLocation().getDirection().getZ() * 5.0);
                    p.setVelocity(v);
                    PlayerMoveListener.this.jump.remove(p.getName());
                }
            }, 30L);
        }
    }
    
    @EventHandler
    public void a(final EntityDamageEvent e) {
        e.setCancelled(true);
    }
}
