package com.Reveas.Hub.Listener;

import org.bukkit.event.player.*;
import com.dsh105.echopet.api.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class PlayerQuitListener implements Listener
{
    @EventHandler
    public void onJoin(final PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        e.setQuitMessage((String)null);
        if (EchoPetAPI.getAPI().hasPet(p)) {
            EchoPetAPI.getAPI().removePet(p, false, false);
        }
    }
}
