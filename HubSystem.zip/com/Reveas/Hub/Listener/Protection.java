package com.Reveas.Hub.Listener;

import org.bukkit.event.block.*;
import org.bukkit.block.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.event.*;
import org.bukkit.event.weather.*;
import org.bukkit.event.hanging.*;
import org.bukkit.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.event.entity.*;

public class Protection implements Listener
{
    @EventHandler
    public void onCraft(final CraftItemEvent e) {
        final Player player = Bukkit.getPlayer(e.getWhoClicked().getName());
        player.closeInventory();
        e.setCancelled(true);
        player.sendMessage("�cYou can't craft");
    }
    
    @EventHandler
    public void onLeave(final LeavesDecayEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onBlockFade(final BlockFadeEvent e) {
        if (e.getBlock().getType() == Material.ICE || e.getBlock().getType() == Material.SNOW || e.getBlock().getType() == Material.SNOW_BLOCK) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onEntityExplore(final EntityExplodeEvent event) {
        event.blockList().clear();
    }
    
    @EventHandler
    public void onFishEvent(final PlayerFishEvent e) {
        if (e.getCaught() != null && !(e.getCaught() instanceof Player)) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEntityEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onInteract(final PlayerInteractEvent e) {
        final Block B = e.getClickedBlock();
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && (B.getType() == Material.ENDER_CHEST || B.getType() == Material.WORKBENCH || B.getType() == Material.DAYLIGHT_DETECTOR || B.getType() == Material.LEVER || B.getType() == Material.TRAPPED_CHEST || B.getType() == Material.CHEST || B.getType() == Material.NOTE_BLOCK || B.getType() == Material.ANVIL || B.getType() == Material.ENCHANTMENT_TABLE || B.getType() == Material.TRAP_DOOR)) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onMob(final SpawnerSpawnEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onEntityDamage(final CreeperPowerEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onDro(final PlayerDropItemEvent e) {
        final Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onDdd(final FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void Hunger(final FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void AntiWeather(final WeatherChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDestroyByEntity(final HangingBreakByEntityEvent e) {
        if (e.getRemover() instanceof Player) {
            final Player p = (Player)e.getRemover();
            if (e.getEntity().getType() == EntityType.ITEM_FRAME && !p.isOp()) {
                e.setCancelled(true);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void OnPlaceByEntity(final HangingPlaceEvent e) {
        final Player p = e.getPlayer();
        if (e.getEntity().getType() == EntityType.ITEM_FRAME && !p.isOp()) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void canRotate(final PlayerInteractEntityEvent e) {
        final Entity entity = e.getRightClicked();
        final Player p = e.getPlayer();
        if (entity.getType().equals((Object)EntityType.HORSE)) {
            e.setCancelled(true);
        }
        if (!entity.getType().equals((Object)EntityType.ITEM_FRAME)) {
            return;
        }
        final ItemFrame iFrame = (ItemFrame)entity;
        if (iFrame.getItem().equals((Object)null) || iFrame.getItem().getType().equals((Object)Material.AIR)) {
            return;
        }
        if (!p.isOp()) {
            e.setCancelled(true);
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void ItemRemoval(final EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player) {
            final Player p = (Player)e.getDamager();
            if (e.getEntity().getType() == EntityType.ITEM_FRAME && !p.isOp()) {
                e.setCancelled(true);
            }
        }
        if (e.getDamager() instanceof Projectile && e.getEntity().getType() == EntityType.ITEM_FRAME) {
            final Projectile p2 = (Projectile)e.getDamager();
            final Player player = (Player)p2.getShooter();
            if (!player.isOp()) {
                e.setCancelled(true);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void on(final InventoryClickEvent event) {
        final Player p = (Player)event.getWhoClicked();
        final ItemStack clicked = event.getCurrentItem();
        if (clicked.getType() == Material.STAINED_GLASS_PANE) {
            p.closeInventory();
        }
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (p.getGameMode() == GameMode.CREATIVE) {
            e.setCancelled(false);
        }
    }
    
    @EventHandler
    public void onHunger(final FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void OnWeather(final WeatherChangeEvent o) {
        o.setCancelled(true);
    }
    
    @EventHandler
    public void onDamaga(final EntityDamageByBlockEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onDamageEnt(final EntityDamageByEntityEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void onDamageAll(final EntityDamageEvent e) {
        e.setCancelled(true);
    }
}
