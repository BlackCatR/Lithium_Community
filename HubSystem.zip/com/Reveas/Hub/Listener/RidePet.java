package com.Reveas.Hub.Listener;

import org.bukkit.event.player.*;
import com.dsh105.echopet.api.*;
import com.Reveas.api.util.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class RidePet implements Listener
{
    @EventHandler
    public void onRidePet(final PlayerInteractEntityEvent e) {
        final org.bukkit.entity.Player p = e.getPlayer();
        final Entity et = e.getRightClicked();
        final EchoPetAPI a = EchoPetAPI.getAPI();
        if (a.hasPet(p)) {
            final Player info = new Player(p.getName(), p.getUniqueId().toString());
            if (et.getCustomName().equals(a.getPet(p).getPetName())) {
                if (info.getRankLevel() >= Rank.EMERALD.getLevel() || info.getRankLevel() >= Rank.VIP.getLevel()) {
                    if (et.getCustomName().equals(a.getPet(p).getPetName())) {
                        a.getPet(p).ownerRidePet(true);
                    }
                }
                else {
                    p.sendMessage(String.valueOf(Main.prefix) + "�cThs feature only for �aPremium �cand and above.");
                    p.sendMessage(String.valueOf(Main.prefix) + "�cYou can buy rank from �8� �estore.ReveasMC.com.");
                }
            }
        }
    }
}
