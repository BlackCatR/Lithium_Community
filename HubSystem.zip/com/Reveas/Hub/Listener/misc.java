package com.Reveas.Hub.Listener;

import org.bukkit.event.weather.*;
import org.bukkit.event.*;
import org.bukkit.*;
import com.Reveas.Hub.Commands.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.entity.*;
import org.bukkit.event.player.*;

public class misc implements Listener
{
    @EventHandler
    public void e(final WeatherChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void colorSign(final SignChangeEvent e) {
        e.setLine(0, ChatColor.translateAlternateColorCodes('&', e.getLine(0)));
        e.setLine(1, ChatColor.translateAlternateColorCodes('&', e.getLine(1)));
        e.setLine(2, ChatColor.translateAlternateColorCodes('&', e.getLine(2)));
        e.setLine(3, ChatColor.translateAlternateColorCodes('&', e.getLine(3)));
    }
    
    @EventHandler
    public void onWeathexr(final PlayerQuitEvent e) {
        e.setQuitMessage((String)null);
    }
    
    @EventHandler
    public void aaa(final PlayerBedEnterEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void food(final FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void aaa(final BlockBurnEvent e) {
        e.setCancelled(true);
    }
    
    @EventHandler
    public void aaa(final BlockPlaceEvent e) {
        if (Build.build.contains(e.getPlayer())) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void aaa(final BlockBreakEvent e) {
        if (Build.build.contains(e.getPlayer())) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void asdasd(final EntityDamageByEntityEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL) {
            e.setCancelled(true);
        }
        else {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void dropitem(final PlayerPickupItemEvent e) {
        final Player p = e.getPlayer();
        if (Build.build.contains(p)) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void dropitem(final PlayerDropItemEvent e) {
        final Player p = e.getPlayer();
        if (Build.build.contains(p)) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
    }
}
