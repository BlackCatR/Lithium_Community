package com.Reveas.Hub.Main;

import org.bukkit.plugin.java.*;
import com.Reveas.Hub.Utils.*;
import com.Reveas.Hub.Friends.*;
import com.Reveas.Hub.Signsystem.*;
import com.Reveas.Hub.RunTask.*;
import org.bukkit.entity.*;
import java.util.*;
import java.sql.*;
import java.io.*;
import org.bukkit.event.*;
import org.bukkit.plugin.*;
import com.Reveas.Hub.Gadgets.*;
import com.Reveas.Hub.SuperBoots.*;
import com.Reveas.Hub.Chat.*;
import com.Reveas.Hub.Profile.*;
import com.Reveas.Hub.TokensAPI.*;
import com.Reveas.Hub.Inventorys.*;
import com.Reveas.Hub.Listener.*;
import org.bukkit.command.*;
import com.Reveas.Hub.TokensCommands.*;
import com.Reveas.Hub.Warp.*;
import com.Reveas.Hub.Commands.*;
import org.bukkit.configuration.file.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import com.Reveas.Hub.API.*;

public class Main extends JavaPlugin
{
    public static Integer SignSystem;
    public static Integer Menu;
    public static Integer Hats;
    public static Integer SelectGames;
    public static Integer Pets;
    public static Integer HidePlayer;
    public static Integer Profile;
    public static HashMap<String, String> Particles;
    public static Integer Crystals;
    public static MySQL_OvO mysql_ovo;
    public static Integer Scoreboard;
    public static Main Instance;
    String message;
    private static FriendsMySQL friendmysql;
    private FriendsUtils api;
    public static Methods methods;
    public static MySQL_OS mysql_os;
    String noperm;
    public static MySQL_OvO ovo;
    String mreload;
    public static Plugin instance;
    public static String building;
    public static ArrayList<Player> buildmode;
    public static Main plugin;
    public static String prefix;
    public static Inventory CompassInv;
    public static String Perm;
    public static File Spawn;
    public static YamlConfiguration Spawncfg;
    public static File Warp;
    public static YamlConfiguration Warpcfg;
    public static ArrayList<String> players;
    public static String F;
    public static MySQL_HubSystem Hubmysql;
    public static MySQL_SG mysqlsg;
    public static Integer Gun;
    public static Integer particels;
    public static ArrayList<Player> muted;
    public static String getPrefix;
    public static ArrayList<String> Lobby;
    public static HashMap<String, Player> Cencelremove;
    public static ArrayList<Player> ReveasPets;
    public static MySQL_GG mysql_gg;
    public HashMap<String, ServerInfo> servers;
    public HashMap<Location, String> getRealName;
    public HashMap<Location, String> getDisplayName;
    public List<Location> getSignLocs;
    public List<Player> createSign;
    public static MySQL_FFA mysql;
    public static TokensRank StoreRank;
    private static HashMap<String, com.Reveas.Hub.Main.Player> PlayerInfo;
    private static HashMap<String, Ranks> RanksInfo;
    private static HashMap<UUID, String> answer3;
    
    static {
        Main.Particles = new HashMap<String, String>();
        Main.prefix = "�cModerator �8\u258f ";
        Main.getPrefix = "�8\u258f �cMod �8\u258f �7";
        Main.ReveasPets = new ArrayList<Player>();
        Main.Cencelremove = new HashMap<String, Player>();
        Main.muted = new ArrayList<Player>();
        Main.players = new ArrayList<String>();
        Main.Lobby = new ArrayList<String>();
        Main.PlayerInfo = new HashMap<String, com.Reveas.Hub.Main.Player>();
        Main.RanksInfo = new HashMap<String, Ranks>();
        Main.Perm = "�8�l\u2503 �e�lNix�6�lMC �8\u2503 �cYou do not have permission to execute this command.";
        Main.prefix = "�8�l\u2503 �e�lNix�6�lMC �8\u2503 ";
    }
    
    public static Main plugin() {
        return Main.plugin;
    }
    
    public Main() {
        Main.Instance = this;
        this.servers = new HashMap<String, ServerInfo>();
        this.getRealName = new HashMap<Location, String>();
        this.getDisplayName = new HashMap<Location, String>();
        this.getSignLocs = new ArrayList<Location>();
        this.createSign = new ArrayList<Player>();
    }
    
    public void onEnable() {
        Main.plugin = this;
        Bukkit.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
        Bukkit.getScheduler().cancelAllTasks();
        new SignUpdater().asyncScheduler();
        new Lobby().runTaskTimer((Plugin)Main.plugin, 20L, 20L);
        this.addSigns();
        this.registerParticles();
        this.Events();
        this.Commands();
        MySQL_HubSystem.connect();
        MySQL_HubSystem.createTables();
        Bukkit.getServer().getConsoleSender().sendMessage("�8------------------------------");
        Bukkit.getServer().getConsoleSender().sendMessage("");
        Bukkit.getServer().getConsoleSender().sendMessage("");
        Bukkit.getServer().getConsoleSender().sendMessage("�7Plugin Made By Hamoood_ Best Hub System <33");
        Bukkit.getServer().getConsoleSender().sendMessage("");
        Bukkit.getServer().getConsoleSender().sendMessage("");
        Bukkit.getServer().getConsoleSender().sendMessage("�8------------------------------");
        this.ConnectMySQLSG();
        this.connectMySQL_GG();
        this.ConnectMySQL();
        ReveasSystem();
        super.onEnable();
        for (final World w : Bukkit.getWorlds()) {
            for (final Entity e : w.getEntities()) {
                if (e.getType() == EntityType.DROPPED_ITEM) {
                    e.remove();
                }
            }
        }
    }
    
    public void onDisable() {
    }
    
    public static FriendsMySQL getMySQL() {
        return Main.friendmysql;
    }
    
    public FriendsUtils getAPI() {
        return this.api;
    }
    
    public static Methods getFriendManager() {
        return Main.methods;
    }
    
    private void connectMySQL_GG() {
        try {
            try {
                MySQL_GG.connect();
                this.saveConfig();
                final PreparedStatement ps = MySQL_GG.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS Stats (UUID VARCHAR(100), POINTS INT(255), KILLS INT(255), DEATHS INT(255), MAXLVL INT(255))");
                ps.executeUpdate();
            }
            catch (SQLException e1) {
                System.out.println("[GunGame] Could not connect to MySQL. Disabling GunGame...");
                Bukkit.getPluginManager().disablePlugin((Plugin)this);
            }
        }
        catch (NullPointerException ex) {}
    }
    
    private void ConnectMySQL() {
        (Main.mysql = new MySQL_FFA("localhost", "ReveasGames", "ReveasGames", "13")).update("CREATE TABLE IF NOT EXISTS PVPStats(UUID varchar(64), KILLS int, DEATHS int, POINTS int, KILLSSTREAK int, NAME varchar(64), TYPE varchar(64), KIT varchar(255));");
        Main.mysql.update("CREATE TABLE IF NOT EXISTS PVPTraills (UUID VARCHAR(100), LAVAPOP varchar(64), SMOKE varchar(64), HEARTS varchar(64), Trail varchar(64), NAME varchar(64));");
        Main.mysql.update("CREATE TABLE IF NOT EXISTS PVPSounds (UUID VARCHAR(100), FIREWORK varchar(64), LEVELUP varchar(64), DONKEY varchar(64), Sound varchar(64), NAME varchar(64));");
        Main.mysql.update("CREATE TABLE IF NOT EXISTS PVPSettings (UUID VARCHAR(64), Save varchar(64), SaveKit varchar(255), KitGold varchar(64), AutoScramble varchar(64), AutoTogglerank varchar(64), TNT varchar(64), Cowbeb varchar(64), NAME varchar(64) );");
    }
    
    public static HashMap<UUID, String> getAnswer3() {
        return Main.answer3;
    }
    
    private void ConnectMySQLSG() {
        (Main.mysqlsg = new MySQL_SG("localhost", "ReveasGames", "ReveasGames", "13")).update("CREATE TABLE IF NOT EXISTS SGStats(UUID varchar(100), KILLS int, DEATHS int, PLAYED int, POINTS int, WINS int, CHEST int, DEATHMATCH int, Achievements varchar(255), NAME varchar(64));");
        Main.mysqlsg.update("CREATE TABLE IF NOT EXISTS SGRounds(Players varchar(255), Kills varchar(255), Deaths varchar(255), Time varchar(255), Points varchar(255), Winner varchar(255), GameID varchar(255), Server varchar(255), VoteDM varchar(255), Map varchar(255));");
        Main.mysqlsg.update("CREATE TABLE IF NOT EXISTS SGTraills (UUID VARCHAR(100), Note varchar(64), Fairy varchar(64), Flame varchar(64), Hearts varchar(64), Smoke varchar(64), VillagerThundercloud varchar(64), EFFECT varchar(64), NAME varchar(64));");
        Main.mysqlsg.update("CREATE TABLE IF NOT EXISTS SGSounds (UUID VARCHAR(100), Anvil varchar(64), Burp varchar(64), DonkeyDeath varchar(64), FireworkWhizz varchar(64), HorseScreech varchar(64), Levelup varchar(64) ,CatMeow varchar(64), RoaringThunnder varchar(64) , VillagerYes varchar(64), SOUND varchar(64), NAME varchar(64));");
        Main.mysqlsg.update("CREATE TABLE IF NOT EXISTS SGLeather (UUID VARCHAR(100), Purple varchar(64), Cyan varchar(64), White varchar(64), Pink varchar(64), Black varchar(64), Green varchar(64), Blue varchar(64), Orange varchar(64), Red varchar(64), COLOR varchar(64), NAME varchar(64));");
        Main.mysqlsg.update("CREATE TABLE IF NOT EXISTS SGSettings(UUID VARCHAR(100), AutoToggleRank varchar(64), AutoScramble varchar(64), Chest varchar(64), ChestE varchar(64), ChestD varchar(64), MySword varchar(64), SwordOff varchar(64), SwordOn varchar(64), NAME varchar(64) );");
    }
    
    public static void tpToFallBackServer(final Player p, final String server) {
        final ByteArrayOutputStream b = new ByteArrayOutputStream();
        final DataOutputStream out = new DataOutputStream(b);
        try {
            out.writeUTF("Connect");
            out.writeUTF(server);
        }
        catch (IOException ex) {}
        p.sendPluginMessage((Plugin)Main.plugin, "BungeeCord", b.toByteArray());
    }
    
    private void registerParticles() {
        final PluginManager pm = Bukkit.getServer().getPluginManager();
        pm.registerEvents((Listener)new EVENT_PlayerInteract(), (Plugin)this);
        pm.registerEvents((Listener)new EVENT_SignChange(), (Plugin)this);
        Bukkit.getServer().getConsoleSender().sendMessage("�aRegister Particels Done");
    }
    
    public void Events() {
        final PluginManager pm = Bukkit.getPluginManager();
        pm.registerEvents((Listener)new Angry_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Ender_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Fire_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new JetPack_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Love_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Musik_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new ParticlesMenu(), (Plugin)this);
        pm.registerEvents((Listener)new wardrobeGUI(), (Plugin)this);
        pm.registerEvents((Listener)new Smoke_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new HideListener(), (Plugin)this);
        pm.registerEvents((Listener)new Wather_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Mystic_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Speed_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Ice_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new Pets(), (Plugin)this);
        pm.registerEvents((Listener)new gadget(), (Plugin)this);
        pm.registerEvents((Listener)new Boots_Config(), (Plugin)this);
        pm.registerEvents((Listener)new Join_Boots(), (Plugin)this);
        pm.registerEvents((Listener)new misc(), (Plugin)this);
        pm.registerEvents((Listener)new Chat(), (Plugin)this);
        Bukkit.getServer().getConsoleSender().sendMessage("�aRegister Events Done");
        pm.registerEvents((Listener)new InventoryClickListener(), (Plugin)this);
        pm.registerEvents((Listener)new PlayerJoinListener(), (Plugin)this);
        pm.registerEvents((Listener)new PlayerMoveListener(), (Plugin)this);
        pm.registerEvents((Listener)new Profile(), (Plugin)this);
        pm.registerEvents((Listener)new Compass(), (Plugin)this);
        pm.registerEvents((Listener)new EventsTokens(), (Plugin)this);
        pm.registerEvents((Listener)new FFA(), (Plugin)this);
        pm.registerEvents((Listener)new Toc0(), (Plugin)this);
        pm.registerEvents((Listener)new Cot0(), (Plugin)this);
        pm.registerEvents((Listener)new Speed(), (Plugin)this);
        pm.registerEvents((Listener)new Speed1(), (Plugin)this);
        pm.registerEvents((Listener)new Hats(), (Plugin)this);
        pm.registerEvents((Listener)new SG(), (Plugin)this);
        pm.registerEvents((Listener)new Hats1(), (Plugin)this);
        pm.registerEvents((Listener)new RidePet(), (Plugin)this);
    }
    
    public void fetchClasses() {
        Main.friendmysql = new FriendsMySQL(this);
        this.api = new FriendsUtils(this);
        Main.methods = new Methods(this);
    }
    
    public static String Color(final String text) {
        return text.replaceAll("&", "�");
    }
    
    public static String F(final String text) {
        return text.replace("&", "�");
    }
    
    public void Commands() {
        Bukkit.getServer().getConsoleSender().sendMessage("�aRegister Commands Done");
        this.getCommand("fly").setExecutor((CommandExecutor)new Fly());
        this.getCommand("fligth").setExecutor((CommandExecutor)new Fly());
        this.getCommand("sign").setExecutor((CommandExecutor)new shop());
        this.getCommand("Removevillager").setExecutor((CommandExecutor)new CommandADMIN());
        this.getCommand("addvillager").setExecutor((CommandExecutor)new CommandADDVILLAGER());
        this.getCommand("tokens").setExecutor((CommandExecutor)new CommandADMIN());
        this.getCommand("addtokens").setExecutor((CommandExecutor)new CommandADDTOKENS());
        this.getCommand("FFA-Shop").setExecutor((CommandExecutor)new CommandADMIN());
        this.getCommand("FFA").setExecutor((CommandExecutor)new NickFFA_CMD());
        this.getCommand("addcrystal").setExecutor((CommandExecutor)new CommandADDCRYSTAL());
        this.getCommand("addcredits").setExecutor((CommandExecutor)new CommandADDCREDITS());
        this.getCommand("build").setExecutor((CommandExecutor)new Build());
        this.getCommand("Lobby").setExecutor((CommandExecutor)new com.Reveas.Hub.Commands.Lobby());
        this.getCommand("Nick").setExecutor((CommandExecutor)new Nick());
        this.getCommand("Rules").setExecutor((CommandExecutor)new Rules());
        this.getCommand("Head").setExecutor((CommandExecutor)new Head());
        this.getCommand("tp").setExecutor((CommandExecutor)new tp());
        this.getCommand("warp").setExecutor((CommandExecutor)new cmd_warp());
        this.getCommand("setwarp").setExecutor((CommandExecutor)new cmd_setwarp());
        this.getCommand("tpall").setExecutor((CommandExecutor)new CommandTp());
        this.getCommand("Poke").setExecutor((CommandExecutor)new Poke());
        this.getCommand("Records").setExecutor((CommandExecutor)new Records());
        this.getCommand("boots").setExecutor((CommandExecutor)new Boots_cmd());
    }
    
    public static File ReveasSystem() {
        return new File("plugins/ReveasSystem");
    }
    
    public void addSigns() {
        for (final String s : Main.plugin.getConfig().getStringList("Servers.List")) {
            final String name = s.split(";")[0];
            final String displayname = s.split(";")[1];
            final String ip = s.split(";")[2];
            final Integer port = Integer.valueOf(s.split(";")[3]);
            final World world = Bukkit.getWorld(this.getConfig().getString("Servers.Location." + displayname + ".World"));
            final double x = this.getConfig().getDouble("Servers.Location." + displayname + ".X");
            final double y = this.getConfig().getDouble("Servers.Location." + displayname + ".Y");
            final double z = this.getConfig().getDouble("Servers.Location." + displayname + ".Z");
            final Location loc = new Location(world, x, y, z);
            this.getSignLocs.add(loc);
            this.getRealName.put(loc, name);
            this.getDisplayName.put(loc, displayname);
            this.servers.put(name, new ServerInfo(name, displayname, ip, port, 250, loc));
        }
    }
    
    public static File getSpawnFile() {
        return new File("plugins/ReveasSystem/Spawn.yml");
    }
    
    public static FileConfiguration getSpawnFileConfiguration() {
        return (FileConfiguration)YamlConfiguration.loadConfiguration(getSpawnFile());
    }
    
    public static String getPlayername(final UUID uuid) {
        return Bukkit.getOfflinePlayer(uuid).getName();
    }
    
    public static String getPlayerSGname(final UUID uuid) {
        return Stats_SG.getName(uuid.toString());
    }
    
    public static String getPlayerGGname(final UUID uuid) {
        return Stats_SG.getName(uuid.toString());
    }
    
    private ItemStack getColorArmor(final Material m, final Color c) {
        final ItemStack i = new ItemStack(m, 1);
        final LeatherArmorMeta meta = (LeatherArmorMeta)i.getItemMeta();
        meta.setColor(c);
        i.setItemMeta((ItemMeta)meta);
        return i;
    }
    
    public static void setWarp(final Location loc, final String path) {
        final FileConfiguration spawn = getSpawnFileConfiguration();
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".World", (Object)loc.getWorld().getName());
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".X", (Object)loc.getX());
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Y", (Object)loc.getY());
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Z", (Object)loc.getZ());
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Yaw", (Object)loc.getYaw());
        spawn.set(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Pitch", (Object)loc.getPitch());
        try {
            spawn.save(getSpawnFile());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static Location getWarp(final String path) {
        final FileConfiguration spawn = getSpawnFileConfiguration();
        if (spawn.get(path) != null) {
            final World world = Bukkit.getWorld(spawn.getString(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".World"));
            final double x = spawn.getDouble(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".X");
            final double y = spawn.getDouble(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Y");
            final double z = spawn.getDouble(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Z");
            final float yaw = (float)spawn.getDouble(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Yaw");
            final float pitch = (float)spawn.getDouble(String.valueOf(String.valueOf(String.valueOf(String.valueOf(path)))) + ".Pitch");
            final Location warp = new Location(world, x, y, z, yaw, pitch);
            return warp;
        }
        return null;
    }
    
    public static void normal(final ItemStack item, final Inventory inv, final String lore, final Player p, final String itemName, final Integer loc) {
        final ItemStack a = new ItemStack(item);
        final ItemMeta aMeta = a.getItemMeta();
        aMeta.setDisplayName(itemName);
        final ArrayList x = new ArrayList();
        x.add(lore);
        aMeta.setLore((List)x);
        a.setItemMeta(aMeta);
        inv.setItem((int)loc, a);
    }
    
    public static void normal1(final ItemStack item, final Inventory inv, final String lore, final int durb, final Player p, final String itemName, final Integer loc) {
        final ItemStack a = new ItemStack(item);
        final ItemMeta aMeta = a.getItemMeta();
        aMeta.setDisplayName(itemName);
        final ArrayList x = new ArrayList();
        x.add(lore);
        a.setDurability((short)durb);
        aMeta.setLore((List)x);
        a.setItemMeta(aMeta);
        inv.setItem((int)loc, a);
    }
    
    public static void Book(final ItemStack item, final List<String> booktext, final Player p, final String itemName, final Integer loc) {
        final ItemStack a = new ItemStack(item);
        final BookMeta aMeta = (BookMeta)a.getItemMeta();
        aMeta.setPages((List)booktext);
        aMeta.setDisplayName(itemName);
        p.getInventory().setItem((int)loc, a);
    }
    
    public static Main getInstance() {
        return Main.Instance;
    }
    
    public static void connect(final Player P, final String Servername) {
        final ByteArrayOutputStream Out = new ByteArrayOutputStream();
        final DataOutputStream Dataout = new DataOutputStream(Out);
        try {
            Dataout.writeUTF("Connect");
            Dataout.writeUTF(Servername);
        }
        catch (Exception ex) {}
        P.sendPluginMessage((Plugin)getInstance(), "BungeeCord", Out.toByteArray());
    }
    
    public static com.Reveas.Hub.Main.Player getPlayerInfo(final String name) {
        if (Main.PlayerInfo.containsKey(name)) {
            return Main.PlayerInfo.get(name);
        }
        return null;
    }
    
    public static void addPlayerInfo(final String name, final com.Reveas.Hub.Main.Player info) {
        if (!Main.PlayerInfo.containsKey(name)) {
            Main.PlayerInfo.put(name, info);
        }
    }
    
    public static void removePlayerInfo(final String name, final com.Reveas.Hub.Main.Player info) {
        Main.PlayerInfo.remove(name);
    }
    
    public static Ranks getRanksinfo(final String name) {
        return Main.RanksInfo.get(name);
    }
    
    public static void addRanksInfo(final String name, final Ranks info) {
        Main.RanksInfo.put(name, info);
    }
    
    public static void removeRanksInfo(final String name) {
        Main.RanksInfo.remove(name);
    }
    
    public static Integer getServerOnlinePlayers(final String serveradress, final int port) {
        try {
            final ServerListPing slp = new ServerListPing(serveradress, port, 2000);
            slp.fetchData();
            final int online = slp.getPlayersOnline();
            return online;
        }
        catch (Exception ex) {
            return 0;
        }
    }
}
