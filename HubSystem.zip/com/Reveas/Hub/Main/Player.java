package com.Reveas.Hub.Main;

import com.Reveas.api.*;
import com.Reveas.api.tokensapi.*;
import com.Reveas.api.util.*;

public class Player
{
    String uuid;
    String name;
    String RankColor;
    String setRank;
    boolean CheckPermission;
    int RankLevel;
    String RankName;
    int Crystals;
    Integer Tokens;
    String rank;
    int Level;
    int Exp;
    int getLevelMax;
    
    public Player(final String name, final String uuid) {
        this.name = "";
        this.uuid = "";
        this.CheckPermission = Reveas.checkPermission(name, Reveas.getPlayer(name).getRank());
        this.Crystals = Stats_HubSystem.getCrystals(uuid);
        this.Tokens = Stats_HubSystem.getTokens(uuid);
        this.RankLevel = Reveas.getPlayer(name).getRank().getLevel();
        this.Exp = Reveas.getPlayer(name).getXP();
        this.RankName = Reveas.getPlayer(name).getRank().getName();
        this.Level = Reveas.getPlayer(name).getRank().getLevel();
        this.getLevelMax = LevelSystem.getMaxXP(this.Level);
        this.RankColor = Reveas.getPlayer(name).getRank().getTabPrefix();
        this.rank = Reveas.getPlayer(name).getRank().toString();
    }
    
    public boolean checkPermission(final String name, final Rank ReveasRank) {
        return this.CheckPermission;
    }
    
    public int getExp() {
        return this.Exp;
    }
    
    public String setParamRank() {
        return this.setRank;
    }
    
    public int getRankLevel() {
        return this.RankLevel;
    }
    
    public int getCrystals() {
        return this.Crystals;
    }
    
    public Integer getTokens() {
        return this.Tokens;
    }
    
    public int getLevelMax() {
        return this.getLevelMax;
    }
    
    public String getRankName() {
        return this.RankName;
    }
    
    public String getRankColor() {
        return this.RankColor;
    }
    
    public int getLevel() {
        return this.Level;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getUUID() {
        return this.uuid;
    }
    
    public String getRank() {
        return this.rank;
    }
}
