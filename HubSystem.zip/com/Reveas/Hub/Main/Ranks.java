package com.Reveas.Hub.Main;

public class Ranks
{
}
