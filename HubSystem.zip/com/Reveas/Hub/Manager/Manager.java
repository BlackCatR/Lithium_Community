package com.Reveas.Hub.Manager;

import org.bukkit.event.*;
import com.Reveas.Hub.Main.*;

public class Manager implements Listener
{
    public static String SQL_CONNECTED;
    public static String SQL_ERROR;
    public static String YOU_NEED_MORE_TOKENS;
    public static String YOU_GET_TOKENS_5;
    public static String YOU_GET_TOKENS_10;
    public static String YOU_GET_TOKENS_100;
    public static String YOU_UNLOCKED_CRYSTAL_1;
    public static String YOU_UNLOCKED_CRYSTAL_2;
    public static String YOU_UNLOCKED_CRYSTAL_3;
    public static String YOU_UNLOCKED_CRYSTAL_4;
    
    static {
        Manager.SQL_CONNECTED = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7Succesfully connected to MySQL�7�o(Tokens)";
        Manager.SQL_ERROR = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cCannot connected to MySQL�7�o(Tokens)";
        Manager.YOU_NEED_MORE_TOKENS = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + Main.F("&c&lNot enough founds. &7Go earn more tokens by playing games!");
        Manager.YOU_GET_TOKENS_5 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7You earned �e5 tokens �7You have now �e";
        Manager.YOU_GET_TOKENS_10 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7You earned �e10 tokens �7You have now �e";
        Manager.YOU_GET_TOKENS_100 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7You earned �e100 tokens �7You have now �e";
        Manager.YOU_UNLOCKED_CRYSTAL_1 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�8�m----------�8�m[�e�lNix�6�lMC�8�m]---------- \n" + Main.prefix + "�7You are �lopening �da crystal...";
        Manager.YOU_UNLOCKED_CRYSTAL_2 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7What lies within? �aLet's see";
        Manager.YOU_UNLOCKED_CRYSTAL_3 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7Congrats! You won �b";
        Manager.YOU_UNLOCKED_CRYSTAL_4 = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�8�m------------------------------------";
    }
}
