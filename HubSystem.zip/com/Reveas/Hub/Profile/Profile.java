package com.Reveas.Hub.Profile;

import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Gadgets.*;
import com.Reveas.Hub.Listener.*;
import com.Reveas.api.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.inventory.meta.*;
import com.Reveas.Hub.Utils.*;
import org.bukkit.*;
import com.Reveas.Hub.Board.*;
import org.bukkit.event.*;
import org.bukkit.enchantments.*;
import java.util.*;
import java.text.*;
import com.Reveas.Hub.Manager.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.inventory.*;
import com.Reveas.Hub.API.*;
import org.bukkit.plugin.*;
import com.Reveas.api.util.*;

public class Profile implements Listener
{
    public static String info;
    
    static {
        Profile.info = "�f\u2751 �7�lProfile �f\u2750";
    }
    
    @EventHandler
    public void SelectGames(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack Item = e.getCurrentItem();
        if (e.getInventory().getName().equalsIgnoreCase("�7[RM] �7This is your profile")) {
            e.setCancelled(true);
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �5Cosmetics �7\u2748") && Item.getType().equals((Object)Material.FIREWORK_CHARGE)) {
                e.setCancelled(true);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �7Gadgets") && Item.getType().equals((Object)Material.PISTON_BASE)) {
                e.setCancelled(true);
                Inventories.openGadgets(p);
                p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �6Wardrobe")) {
                e.setCancelled(true);
                wardrobeGUI.GUI(p);
                p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �a�lStore") && Item.getType().equals((Object)Material.ENDER_CHEST)) {
                e.setCancelled(true);
                p.sendMessage(String.valueOf(Main.prefix) + "�7You have to buy �aPremium �7rank from our store to use this �eStore.�6ReveasMC.�ecom�7.");
                p.closeInventory();
                p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �bPets") && Item.getType().equals((Object)Material.NAME_TAG)) {
                e.setCancelled(true);
                Pets.Petsinv(p);
                p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �7Hats")) {
                e.setCancelled(true);
                InventoryClickListener.Hatinv(p);
                p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
            }
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �aForcefield�8 �") && Item.getType().equals((Object)Material.EYE_OF_ENDER)) {
            e.setCancelled(true);
            p.chat("/forcefield");
            p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�7�lWings") && Item.getType().equals((Object)Material.FEATHER)) {
            e.setCancelled(true);
            p.performCommand("supertrails open wings");
            p.playSound(p.getLocation(), Sound.SUCCESSFUL_HIT, 10.0f, 10.0f);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�3Store�7 \u25ba �6\u272a �a�lTokens") && Item.getType().equals((Object)Material.BOOK)) {
            e.setCancelled(true);
            Store(p);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�a�lSuper �2�lBoots") && Item.getType().equals((Object)Material.GOLD_BOOTS)) {
            e.setCancelled(true);
            p.chat("/boots");
            p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8\u279f �3Records") && Item.getType().equals((Object)Material.PAPER)) {
            e.setCancelled(true);
            p.chat("/Records");
            p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase(Main.F("&e\u279c &a&lSettings"))) {
            Settings(p);
        }
        final ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta m = (SkullMeta)skull.getItemMeta();
        m.setOwner(p.getName());
        final ReveasPlayer hp = Reveas.getPlayer(p.getName());
        m.setDisplayName("�8\u2022 �e�lNix�6�lMC �8\u2022");
        final List<String> lore = Arrays.asList("�3UserName �8� �e" + hp.getRank().getTabPrefix() + p.getName(), "�3Rank �8� " + hp.getRank().getTabPrefix() + hp.getRank().getName(), ChatColor.WHITE + "�3Tokens �8� �e" + Stats_HubSystem.getTokens(p.getUniqueId().toString()), "�3Credits�8 � �e" + Stats_HubSystem.getCredits(p.getUniqueId().toString()), "�3Enchant Crystals�8 � �e" + Stats_HubSystem.getCrystals(p.getUniqueId().toString()));
        m.setLore((List)lore);
        skull.setItemMeta((ItemMeta)m);
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(skull.getItemMeta().getDisplayName())) {
            p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYour stats in website �8� �ehttps://nixmc.com/player/index.php?player=" + p.getName()));
            p.closeInventory();
        }
        if (e.getInventory().getName().equalsIgnoreCase("�7[NM] � This your settings")) {
            e.setCancelled(true);
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ScraOn(p).getItemMeta().getDisplayName())) {
                if (Reveas.getPlayer(p.getName()).getRank() == Rank.MEMBER) {
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&c&lYou must have a premium rank to use to this."));
                    p.closeInventory();
                }
                else {
                    p.closeInventory();
                    Stats_HubSystem.setParam("HubSettings", p.getUniqueId().toString(), "Scramble", "false");
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&cScramble mode disabled everyone can see your point and rank in pvp games."));
                    ArrayAndHash.Scramble.remove(p.getName());
                }
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ScraOff(p).getItemMeta().getDisplayName())) {
                if (Reveas.getPlayer(p.getName()).getRank() == Rank.MEMBER) {
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&c&lYou must have a premium rank to use to this."));
                    p.closeInventory();
                }
                else {
                    p.closeInventory();
                    Stats_HubSystem.setParam("HubSettings", p.getUniqueId().toString(), "Scramble", "true");
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aScramble mode enabled no one can see your rank in pvp games."));
                    ArrayAndHash.Scramble.add(p.getName());
                }
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ToggleOff(p).getItemMeta().getDisplayName())) {
                if (Reveas.getPlayer(p.getName()).getRank() == Rank.MEMBER) {
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&c&lYou must have a premium rank to use to this."));
                    p.closeInventory();
                }
                else {
                    p.closeInventory();
                    Stats_HubSystem.setParam("HubSettings", p.getUniqueId().toString(), "ToggleRank", "true");
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYour rank has become hidden from all players in pvp games."));
                }
            }
            else if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ToggleOn(p).getItemMeta().getDisplayName())) {
                if (Reveas.getPlayer(p.getName()).getRank() == Rank.MEMBER) {
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&c&lYou must have a premium rank to use to this."));
                    p.closeInventory();
                }
                else {
                    p.closeInventory();
                    Stats_HubSystem.setParam("HubSettings", p.getUniqueId().toString(), "ToggleRank", "false");
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&cYour rank has become shown to all players in pvp games."));
                }
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �6Night")) {
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aSueccssfully change to night"));
                p.setPlayerTime(0L, true);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�8� �6Day")) {
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aSueccssfully change to day"));
                p.setPlayerTime(13000L, true);
            }
            if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ScoreOn(p).getItemMeta().getDisplayName())) {
                p.closeInventory();
                p.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
                for (final Player all : Bukkit.getOnlinePlayers()) {
                    ScoreboardHandler.RegisterTag(all.getScoreboard());
                }
                p.sendMessage(String.valueOf(Main.prefix) + Main.F("&cYou are now don't have Scoreboard."));
                ArrayAndHash.Scoreboard.add(p.getName());
            }
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equals(ScoreOff(p).getItemMeta().getDisplayName())) {
            ArrayAndHash.Scoreboard.remove(p.getName());
            p.closeInventory();
            p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou are now have Scoreboard"));
            Scoreboard(p);
        }
        if (Item != null && Item.hasItemMeta() && Item.getItemMeta().getDisplayName().equalsIgnoreCase("�e�lHub �b�lSelector") && Item.getType().equals((Object)Material.IRON_SWORD)) {
            e.setCancelled(true);
            InventoryClickListener.SelectHub(p);
        }
    }
    
    public static ItemStack GoldTokens(final Player p) {
        final ItemStack g = new ItemStack(Material.GOLD_INGOT);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Gold")) {
            g.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
            lore.add("");
        }
        else {
            lore.add("");
            lore.add("�7Allows you to buy to premium free");
            lore.add("�7a �6Gold!");
            lore.add("");
            lore.add("�a�lCost");
            lore.add("�715000 Tokens");
            lore.add("");
            lore.add("�b\u25ba Click to purchase");
        }
        final ItemMeta gm = g.getItemMeta();
        gm.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        gm.setDisplayName("�eStore \u25ba �6�lGold");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack DiamondTokens(final Player p) {
        final ItemStack g = new ItemStack(Material.DIAMOND);
        final ItemMeta gm = g.getItemMeta();
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Diamond")) {
            g.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
            lore.add("");
        }
        else {
            lore.add("");
            lore.add("�7Allows you to buy to premium free");
            lore.add("�7a �bDiamond!");
            lore.add("");
            lore.add("�a�lCost");
            lore.add("�740000 Tokens");
            lore.add("");
            lore.add("�b\u25ba Click to purchase");
        }
        gm.setDisplayName("�eStore \u25ba �b�lDiamond");
        gm.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Time(final Player p) {
        if (p.getPlayerTime() == 0L) {
            final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
            final ItemMeta m3 = i3.getItemMeta();
            m3.setDisplayName("�8� �6Day");
            i3.setItemMeta(m3);
            return i3;
        }
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�8� �6Night");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ToggleOn(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Togglerank �8� �aOn");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ToggleOff(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Togglerank �8� �cOff");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ToggleRank(final Player p) {
        if (Stats_HubSystem.getBoolean("HubSettings", p.getUniqueId().toString(), "ToggleRank")) {
            final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
            final ItemMeta m3 = i3.getItemMeta();
            m3.setDisplayName("�7Togglerank �8� �aOn");
            i3.setItemMeta(m3);
            return i3;
        }
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Togglerank �8� �cOff");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ScraOn(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scramble �8� �aOn");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ScraOff(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scramble �8� �cOff");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack Scramble(final Player p) {
        if (Stats_HubSystem.getBoolean("HubSettings", p.getUniqueId().toString(), "Scramble")) {
            final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
            final ItemMeta m3 = i3.getItemMeta();
            m3.setDisplayName("�7Scramble �8� �aOn");
            i3.setItemMeta(m3);
            return i3;
        }
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scramble �8� �cOff");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack Scoreboard(final Player p) {
        if (ArrayAndHash.Scoreboard.contains(p.getName())) {
            final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
            final ItemMeta m3 = i3.getItemMeta();
            m3.setDisplayName("�7Scoreboard �8� �cOff");
            i3.setItemMeta(m3);
            return i3;
        }
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scoreboard is �8� �aOn");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ScoreOff(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)8);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scoreboard �8� �cOff");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack ScoreOn(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(351), 1, (short)10);
        final ItemMeta m3 = i3.getItemMeta();
        m3.setDisplayName("�7Scoreboard is �8� �aOn");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack EmeraldTokens(final Player p) {
        final ItemStack g = new ItemStack(Material.EMERALD);
        final ArrayList<String> lore = new ArrayList<String>();
        if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Emerald")) {
            g.addUnsafeEnchantment(Enchantment.DURABILITY, 3);
            lore.add("");
        }
        else {
            lore.add("");
            lore.add("�7Allows you to buy to premium free");
            lore.add("�7a �aEmerald!");
            lore.add("");
            lore.add("�a�lCost");
            lore.add("�760000 Tokens");
            lore.add("");
            lore.add("�b\u25ba Click to purchase");
        }
        final ItemMeta gm = g.getItemMeta();
        gm.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        gm.setDisplayName("�eStore \u25ba �a�lEmerald");
        gm.setLore((List)lore);
        g.setItemMeta(gm);
        return g;
    }
    
    public static ItemStack Back() {
        final ItemStack g = new ItemStack(Material.ARROW);
        final ItemMeta gm = g.getItemMeta();
        gm.setDisplayName(Main.F("�8� �c�lExit to Back"));
        g.setItemMeta(gm);
        return g;
    }
    
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        if (e.getInventory().getTitle().equals("[NM] � Store \u25ba Tokens")) {
            final Player p = (Player)e.getWhoClicked();
            final Date date = new Date();
            final String saat = new SimpleDateFormat("HH/mm").format(date);
            final String tarih = new SimpleDateFormat("MM/").format(date);
            e.setCancelled(true);
            if (e.getCurrentItem().getType() == EmeraldTokens(p).getType()) {
                if (Reveas.checkPermission(p.getName(), Rank.EMERALD)) {
                    p.sendMessage(String.valueOf(Main.prefix) + Main.F("&aYou already you have Premium Emerald!"));
                    p.closeInventory();
                }
                else {
                    if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Emerald")) {
                        p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this premium."));
                        return;
                    }
                    if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 60000) {
                        p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                        return;
                    }
                    Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 60000, false);
                    Reveas.getPlayer(p.getName()).setRank(Rank.EMERALD);
                    Stats_HubSystem.setParam("ReveasRank", p.getUniqueId().toString(), "Emerald", "First Time >> " + tarih + saat);
                    p.kickPlayer("�e�lNix�6�lMC �8\u00d7 �7Network\n\n�7Your rank has been updated to �aEmerald�7!\n�8\u27b2 �7Rejoin, in order to get your rank.");
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought Premium Emerald! "));
                }
            }
            if (e.getCurrentItem().getType() == DiamondTokens(p).getType()) {
                if (Reveas.checkPermission(p.getName(), Rank.DIAMOND)) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this premium."));
                    p.closeInventory();
                }
                else {
                    if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Diamond")) {
                        p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this premium."));
                        return;
                    }
                    if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 40000) {
                        p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                        return;
                    }
                    Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 40000, false);
                    p.kickPlayer("�e�lNix�6�lMC �8\u00d7 �7Network\n\n�7Your rank has been updated to �bDiamond�7!\n�8\u27b2 �7Rejoin, in order to get your rank.");
                    Stats_HubSystem.setParam("ReveasRank", p.getUniqueId().toString(), "Diamond", "First Time >> " + tarih + saat);
                    Reveas.getPlayer(p.getName()).setRank(Rank.DIAMOND);
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought Premium Diamond! "));
                }
            }
            if (e.getCurrentItem().getType() == GoldTokens(p).getType()) {
                if (Reveas.checkPermission(p.getName(), Rank.GOLD)) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this premium."));
                    p.closeInventory();
                }
                else {
                    if (Stats_HubSystem.getBoolean("ReveasRank", p.getUniqueId().toString(), "Gold")) {
                        p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&cYou already have this premium."));
                        return;
                    }
                    if (Stats_HubSystem.getTokens(p.getUniqueId().toString()) < 15000) {
                        p.sendMessage(Manager.YOU_NEED_MORE_TOKENS);
                        return;
                    }
                    Stats_HubSystem.removeTokens(p.getUniqueId().toString(), 15000, false);
                    p.kickPlayer("�e�lNix�6�lMC �8\u00d7 �7Network\n\n�7Your rank has been updated to �6Gold�7!\n�8\u27b2 �7Rejoin, in order to get your rank.");
                    Stats_HubSystem.setParam("ReveasRank", p.getUniqueId().toString(), "Gold", "First Time >> " + tarih + saat);
                    Reveas.getPlayer(p.getName()).setRank(Rank.GOLD);
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(Main.prefix)) + "&7Successfully bought Premium Gold! "));
                }
            }
        }
    }
    
    public static ItemStack TimeS(final Player p) {
        final ItemStack i3 = new ItemStack(Material.getMaterial(347), 1, (short)0);
        if (p.getPlayerTime() == 0L) {
            i3.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
        }
        final ItemMeta m3 = i3.getItemMeta();
        m3.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m3.setDisplayName("�7\u267a �e�lTime");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack Toggle(final Player p) {
        final ItemStack i3 = new ItemStack(Material.REDSTONE);
        if (Stats_HubSystem.getBoolean("HubSettings", p.getUniqueId().toString(), "ToggleRank")) {
            i3.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
        }
        final ItemMeta m3 = i3.getItemMeta();
        m3.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m3.setDisplayName("�7\u27a5 �a�lToggleRank");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack Score(final Player p) {
        final ItemStack i3 = new ItemStack(Material.PAPER);
        if (!ArrayAndHash.Scoreboard.contains(p.getName())) {
            i3.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
        }
        final ItemMeta m3 = i3.getItemMeta();
        m3.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m3.setDisplayName("�7\u27a5 �a�lScoreboard");
        i3.setItemMeta(m3);
        return i3;
    }
    
    public static ItemStack Scr(final Player p) {
        final ItemStack i3 = new ItemStack(Material.NAME_TAG);
        if (Stats_HubSystem.getBoolean("HubSettings", p.getUniqueId().toString(), "Scramble")) {
            i3.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
        }
        final ItemMeta m3 = i3.getItemMeta();
        m3.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        m3.setDisplayName("�7\u27a5 �a�lScramble");
        i3.setItemMeta(m3);
        return i3;
    }
    
    @EventHandler
    public void oabn(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        if ((e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) && p.getItemInHand().getType() == Material.BOOK) {
            e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase(Profile.info);
            openProfil(p);
        }
    }
    
    public static void Settings(final Player p) {
        final Inventory Hub = Bukkit.createInventory((InventoryHolder)null, 36, "�7[RM] � This your settings");
        Hub.setItem(11, TimeS(p));
        Hub.setItem(20, Time(p));
        Hub.setItem(12, Toggle(p));
        Hub.setItem(21, ToggleRank(p));
        Hub.setItem(13, Score(p));
        Hub.setItem(22, Scoreboard(p));
        Hub.setItem(14, Scr(p));
        Hub.setItem(23, Scramble(p));
        final ItemStack F5 = new ItemStack(Material.BOOK);
        final ItemMeta m5 = F5.getItemMeta();
        m5.setDisplayName("�8� �a�lStore");
        final List<String> Exit = Arrays.asList(new String[0]);
        m5.setLore((List)Exit);
        F5.setItemMeta(m5);
        Hub.setItem(27, F5);
        p.openInventory(Hub);
    }
    
    public static void Store(final Player p) {
        final Inventory Hub = Bukkit.createInventory((InventoryHolder)null, 27, "[RM] � Store \u25ba Tokens");
        Hub.setItem(11, GoldTokens(p));
        Hub.setItem(13, DiamondTokens(p));
        Hub.setItem(15, EmeraldTokens(p));
        final ItemStack F4 = new ItemStack(Material.ARROW);
        final ItemMeta m4 = F4.getItemMeta();
        m4.setDisplayName("�8� �c�lExit to Back");
        final List<String> Exit = Arrays.asList(new String[0]);
        m4.setLore((List)Exit);
        F4.setItemMeta(m4);
        Hub.setItem(26, F4);
        p.openInventory(Hub);
    }
    
    public static void openProfil(final Player player) {
        final Player p = player.getPlayer();
        final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 45, "�7[RM] �7This is your profile");
        final ItemStack placeholder = ItemUtils.getItem(Material.STAINED_GLASS_PANE, "�8\u2022 �e�lReveas�7�lGlass �8\u2022", "", 15, 1);
        Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
            @Override
            public void run() {
                inv.setItem(20, ItemUtils.getItem(Material.NAME_TAG, "�8� �bPets", null, 0, 1));
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        inv.setItem(24, ItemUtils.getItem(Material.SKULL_ITEM, "�8� �7Hats", "", 0, 1));
                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                        Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                inv.setItem(30, ItemUtils.getItem(Material.DIAMOND_CHESTPLATE, "�8� �6Wardrobe", "�5", 0, 1));
                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                    @Override
                                    public void run() {
                                        inv.setItem(32, ItemUtils.getItem(Material.BOOK, "�3Store�7 \u25ba �6\u272a �a�lTokens", "�5", 0, 1));
                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                        Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                            @Override
                                            public void run() {
                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        inv.setItem(12, ItemUtils.getItem(Material.MAGMA_CREAM, "�8� �5Particles", null, 0, 1));
                                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                        Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                inv.setItem(14, ItemUtils.getItem(Material.GOLD_BOOTS, "�a�lSuper �2�lBoots", "�7", 0, 1));
                                                                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                                Main.Profile = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.getInstance(), (Runnable)new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
                                                                    }
                                                                }, 2L);
                                                            }
                                                        }, 2L);
                                                    }
                                                }, 2L);
                                            }
                                        }, 2L);
                                    }
                                }, 2L);
                            }
                        }, 2L);
                    }
                }, 2L);
            }
        }, 2L);
        inv.setItem(0, placeholder);
        inv.setItem(1, placeholder);
        inv.setItem(2, placeholder);
        inv.setItem(3, placeholder);
        inv.setItem(4, placeholder);
        inv.setItem(5, placeholder);
        inv.setItem(6, placeholder);
        inv.setItem(7, placeholder);
        inv.setItem(8, placeholder);
        inv.setItem(9, placeholder);
        inv.setItem(10, placeholder);
        inv.setItem(11, placeholder);
        inv.setItem(12, placeholder);
        inv.setItem(13, placeholder);
        inv.setItem(14, placeholder);
        inv.setItem(15, placeholder);
        inv.setItem(16, placeholder);
        inv.setItem(17, placeholder);
        inv.setItem(18, placeholder);
        inv.setItem(19, placeholder);
        inv.setItem(20, placeholder);
        inv.setItem(21, placeholder);
        inv.setItem(22, placeholder);
        inv.setItem(23, placeholder);
        inv.setItem(24, placeholder);
        inv.setItem(25, placeholder);
        inv.setItem(26, placeholder);
        inv.setItem(27, placeholder);
        inv.setItem(28, placeholder);
        inv.setItem(29, placeholder);
        inv.setItem(30, placeholder);
        inv.setItem(31, placeholder);
        inv.setItem(32, placeholder);
        inv.setItem(33, placeholder);
        inv.setItem(34, placeholder);
        inv.setItem(35, placeholder);
        inv.setItem(36, placeholder);
        inv.setItem(37, placeholder);
        inv.setItem(38, placeholder);
        inv.setItem(39, placeholder);
        inv.setItem(40, placeholder);
        inv.setItem(41, placeholder);
        inv.setItem(42, placeholder);
        inv.setItem(43, placeholder);
        final ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta m = (SkullMeta)skull.getItemMeta();
        m.setOwner(p.getName());
        final ReveasPlayer hp = Reveas.getPlayer(p.getName());
        m.setDisplayName("�8\u2022 �e�lReveas�6�lMC �8\u2022");
        final List<String> lore = Arrays.asList("�3Username �8� �e" + hp.getRank().getTabPrefix() + p.getName(), "�3Rank �8� " + hp.getRank().getTabPrefix() + hp.getRank().getName(), ChatColor.WHITE + "�3Tokens �8� �e" + Stats_HubSystem.getTokens(p.getUniqueId().toString()), "�3Credits�8 � �e" + Stats_HubSystem.getCredits(p.getUniqueId().toString()), "�3Enchant Crystals�8 � �e" + Stats_HubSystem.getCrystals(p.getUniqueId().toString()), "�3Level �8� �e" + new ReveasPlayer(p.getUniqueId()).getLevel(), "�3XP �8� �e" + new ReveasPlayer(p.getUniqueId()).getXP() + "/" + LevelSystem.getMaxXP((int)new ReveasPlayer(p.getUniqueId()).getLevel()));
        m.setLore((List)lore);
        skull.setItemMeta((ItemMeta)m);
        inv.setItem(22, skull);
        p.openInventory(inv);
    }
}
