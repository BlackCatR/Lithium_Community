package com.Reveas.Hub.RunTask;

import org.bukkit.scheduler.*;
import org.bukkit.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.entity.*;
import org.inventivetalent.bossbar.*;
import com.Reveas.api.util.*;
import com.dsh105.echopet.api.*;
import com.dsh105.echopet.compat.api.entity.*;
import com.Reveas.api.*;
import java.util.*;

public class Lobby extends BukkitRunnable
{
    Integer Day;
    
    public Lobby() {
        this.Day = 86400;
    }
    
    public void run() {
        --this.Day;
        if (Bukkit.getOnlinePlayers().size() <= 5 && this.Day == 3200) {
            Bukkit.getServer().shutdown();
        }
        if (Bukkit.getOnlinePlayers().size() > 0) {
            for (final String ll : Main.Lobby) {
                final Player p = Bukkit.getPlayerExact(ll);
                for (final Player all : Bukkit.getOnlinePlayers()) {
                    BossBarAPI.getBossBar(all);
                    BossBarAPI.setMessage(all, Main.F("&eYou are playing now &6&lPlay.&e&lReveas&e&lMC.&6&lcom."));
                }
                if (Main.ReveasPets.contains(p)) {
                    final com.Reveas.Hub.Main.Player info = new com.Reveas.Hub.Main.Player(p.getName(), p.getUniqueId().toString());
                    if (info.getRank() == Rank.MEMBER.getName() && EchoPetAPI.getAPI().hasPet(p)) {
                        EchoPetAPI.getAPI().removePet(p, false, true);
                        EchoPetAPI.getAPI().givePet(p, (PetType)null, true);
                    }
                    if (info.getRank() != Rank.MEMBER.getName() && EchoPetAPI.getAPI().hasPet(p)) {
                        EchoPetAPI.getAPI().getPet(p).setPetName(String.valueOf(Reveas.getPlayer(p.getName()).getRank().getTabPrefix()) + p.getName() + " �7's Friend");
                    }
                    if (info.getRank() == Rank.MEMBER.getName() && EchoPetAPI.getAPI().hasPet(p)) {
                        EchoPetAPI.getAPI().removePet(p, false, true);
                        EchoPetAPI.getAPI().givePet(p, (PetType)null, true);
                    }
                    Main.ReveasPets.remove(p);
                }
            }
        }
    }
}
