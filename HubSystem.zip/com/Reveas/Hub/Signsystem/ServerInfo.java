package com.Reveas.Hub.Signsystem;

import java.net.*;
import org.bukkit.block.*;
import org.bukkit.*;

public class ServerInfo
{
    private ServerPing ping;
    private String name;
    private InetSocketAddress address;
    private boolean local;
    private boolean online;
    private int timeout;
    private int playerCount;
    private int maxPlayers;
    private String motd;
    private String displayname;
    private String version;
    private String protocol;
    private long pingStart;
    private long pingEnd;
    private Sign signLoc;
    private int count;
    
    public ServerInfo(final String serverName, final String displayname, final String adress, final int port, final int timeout, final Location signLoc) {
        this.count = 0;
        this.online = false;
        this.name = serverName;
        this.displayname = displayname;
        this.address = new InetSocketAddress(adress, port);
        this.timeout = timeout;
        this.pingStart = System.currentTimeMillis();
        this.pingEnd = System.currentTimeMillis();
        if (signLoc.getBlock().getState() instanceof Sign) {
            this.signLoc = (Sign)signLoc.getBlock().getState();
        }
        else {
            this.signLoc = null;
        }
        final ServerPing serverPing = new ServerPing();
        serverPing.setAddress(this.address);
        this.ping = serverPing;
    }
    
    public Integer getCount() {
        return this.count;
    }
    
    public void setCount(final Integer count) {
        this.count = count;
    }
    
    public Sign getSignLoc() {
        return this.signLoc;
    }
    
    public ServerPing getPing() {
        return this.ping;
    }
    
    public void setPing(final ServerPing ping) {
        this.ping = ping;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    public InetSocketAddress getAddress() {
        return this.address;
    }
    
    public void setAddress(final InetSocketAddress address) {
        this.address = address;
    }
    
    public int getTimeout() {
        return this.timeout;
    }
    
    public void setTimeout(final int timeout) {
        this.timeout = timeout;
    }
    
    public boolean isLocal() {
        return this.local;
    }
    
    public void setLocal(final boolean local) {
        this.local = local;
    }
    
    public boolean isOnline() {
        return this.online;
    }
    
    public void setOnline(final boolean online) {
        this.online = online;
    }
    
    public String getProtocol() {
        return this.protocol;
    }
    
    public void setProtocol(final String protocol) {
        this.protocol = protocol;
    }
    
    public String getVersion() {
        return this.version;
    }
    
    public void setVersion(final String version) {
        this.version = version;
    }
    
    public int getPlayerCount() {
        return this.playerCount;
    }
    
    public void setPlayerCount(final int playercount) {
        this.playerCount = playercount;
    }
    
    public int getMaxPlayers() {
        return this.maxPlayers;
    }
    
    public void setMaxPlayers(final int maxplayers) {
        this.maxPlayers = maxplayers;
    }
    
    public String getMotd() {
        return this.motd;
    }
    
    public void setMotd(final String motd) {
        this.motd = motd;
    }
    
    public String getDisplayname() {
        return this.displayname;
    }
    
    public void setDisplayname(final String displayname) {
        this.displayname = displayname;
    }
    
    public long getPingDelay() {
        return this.calculatePingDelay();
    }
    
    public void setPingStart(final long time) {
        this.pingStart = time;
    }
    
    public void setPingEnd(final long time) {
        this.pingEnd = time;
    }
    
    public void resetPingDelay() {
        this.pingStart = System.currentTimeMillis();
    }
    
    private long calculatePingDelay() {
        final long result = this.pingEnd - this.pingStart;
        return result;
    }
}
