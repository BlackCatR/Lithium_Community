package com.Reveas.Hub.Signsystem;

import org.bukkit.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.scheduler.*;
import java.io.*;
import java.util.*;
import org.bukkit.block.*;
import org.bukkit.plugin.*;

public class SignUpdater
{
    public void asyncScheduler() {
        Bukkit.getScheduler().scheduleAsyncRepeatingTask((Plugin)Main.getInstance(), (Runnable)new BukkitRunnable() {
            public void run() {
                for (final ServerInfo serverInfo : Main.plugin.servers.values()) {
                    final ServerPing serverPing = serverInfo.getPing();
                    ServerPing.ServerStatus serverStatus = null;
                    try {
                        serverStatus = serverPing.fetchServerData();
                        serverInfo.setOnline(true);
                        serverInfo.setMotd(serverStatus.getMotd());
                        serverInfo.setPlayerCount(serverStatus.getPlayers().getOnline());
                        serverInfo.setMaxPlayers(serverStatus.getPlayers().getMax());
                    }
                    catch (IOException e) {
                        serverInfo.setOnline(false);
                    }
                    if (serverInfo.isOnline()) {
                        if (serverInfo.getPlayerCount() >= serverInfo.getMaxPlayers()) {
                            final Sign sign = serverInfo.getSignLoc();
                            sign.setLine(0, "�4[FULL-" + serverInfo.getDisplayname() + "]");
                            sign.setLine(1, "�0" + serverInfo.getMotd());
                            sign.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/ " + serverInfo.getMaxPlayers());
                            if (serverInfo.getMotd().contains("Farm") || serverInfo.getMotd().contains("TheFarm") || serverInfo.getMotd().contains("Village") || serverInfo.getMotd().contains("SpongeBob") || serverInfo.getMotd().contains("Mushroom") || serverInfo.getMotd().contains("ice") || serverInfo.getMotd().contains("Desert")) {
                                sign.setLine(3, "�5�l\u25cf �5�lPVP �5�l\u25cf");
                            }
                            else {
                                sign.setLine(3, "�5�l\u25cf �5�lLobby �5�l\u25cf");
                            }
                            SignUpdater.onUpdate(sign);
                        }
                        else if (serverInfo.getSignLoc() != null) {
                            final Sign sign2 = serverInfo.getSignLoc();
                            sign2.setLine(0, "�5[Join-" + serverInfo.getDisplayname() + "]");
                            sign2.setLine(1, "�0" + serverInfo.getMotd());
                            sign2.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            if (serverInfo.getMotd().contains("Aldust") || serverInfo.getMotd().contains("Clay") || serverInfo.getMotd().contains("TheFarm") || serverInfo.getMotd().contains("Desert")) {
                                sign2.setLine(3, "�5�l\u25cf �5�lPVP �5�l\u25cf");
                            }
                            else {
                                sign2.setLine(3, "�5�l\u25cf �5�lLobby �5�l\u25cf");
                            }
                            SignUpdater.onUpdate(sign2);
                        }
                        if (serverInfo.getMotd().contains("GG-SpongeBob")) {
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�d[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("GG-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �dGunGame �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        if (serverInfo.getMotd().contains("Warump-SG4")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0SurvivalGames4");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Lobby")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�5[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Voting");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�5�l\u25cf Lobby �5�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-Revolution")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Revolution");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-Revolution")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Revolution");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-SG7")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0SurvivalGames7");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-CatchingFire")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Catching Fire");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf�7 Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-EauDeSource")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0EauDeSource");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump-Madagascar")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Madagascar");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7Warump �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("DM-Aldust")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Aldust");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7DM �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("DM-BvBees")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0BvBees");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7DM �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("DM-Harmony")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Harmony");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7DM �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-SG4")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0SurvivalGames4");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-Revolution")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Revolution");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-Revolution")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Revolution");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-SG7")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0SurvivalGames7");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-CatchingFire")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Catching Fire");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf�7 In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-EauDeSource")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0EauDeSource");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("SG-Madagascar")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Madagascar");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Harmony")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("VS-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("VS-BvBees")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("VS-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("VS-DustDM")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("VS-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("VS-Aldust")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("VS-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("VS-OldCity")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd().replace("VS-", ""));
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Warump")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�8[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Warump");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�8�l\u25cf �7In game �8�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("DM")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�8[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0Deathmatch");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�8�l\u25cf �7In game �8�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("Maintenance") || serverInfo.getMotd().contains("Maint")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a");
                            sign3.setLine(1, "�3�lMaintenance");
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�7\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a");
                            SignUpdater.onUpdate(sign3);
                        }
                        else if (serverInfo.getMotd().contains("InGame") || serverInfo.getMotd().contains("In game")) {
                            if (serverInfo.getSignLoc() == null) {
                                continue;
                            }
                            final Sign sign3 = serverInfo.getSignLoc();
                            sign3.setLine(0, "�7[Join-" + serverInfo.getDisplayname() + "]");
                            sign3.setLine(1, "�0" + serverInfo.getMotd());
                            sign3.setLine(2, "�8�l" + serverInfo.getPlayerCount() + "/" + serverInfo.getMaxPlayers());
                            sign3.setLine(3, "�0�l\u25cf �7In game �0�l\u25cf");
                            SignUpdater.onUpdate(sign3);
                        }
                        else {
                            if (!serverInfo.getMotd().contains("Restart") && !serverInfo.getMotd().contains("Finishing")) {
                                continue;
                            }
                            final Sign sign4 = serverInfo.getSignLoc();
                            sign4.setLine(0, "�4\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a");
                            sign4.setLine(1, "�4�lWating for");
                            sign4.setLine(2, "�4�lRestarting...");
                            sign4.setLine(3, "�4\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a\u258a");
                            SignUpdater.onUpdate(sign4);
                        }
                    }
                    else {
                        if (serverInfo.getSignLoc() == null) {
                            continue;
                        }
                        final Sign sign2 = serverInfo.getSignLoc();
                        if (serverInfo.getCount() != 0) {
                            continue;
                        }
                        sign2.setLine(0, "�c");
                        sign2.setLine(1, "�8�lWating for ");
                        if (sign2.getWorld().getName().equals("SG") || sign2.getWorld().getName().equals("VS")) {
                            sign2.setLine(2, "�8�lOpen Lobby...");
                        }
                        else {
                            sign2.setLine(2, "�8�lOpen Server...");
                        }
                        sign2.setLine(3, "�c");
                        sign2.update(true);
                        serverInfo.setCount(1);
                    }
                }
            }
        }, 19L, 19L);
    }
    
    public static void onUpdate(final Sign s) {
        new BukkitRunnable() {
            public void run() {
                s.update(true);
            }
        }.runTaskLater((Plugin)Main.getInstance(), 1L);
    }
}
