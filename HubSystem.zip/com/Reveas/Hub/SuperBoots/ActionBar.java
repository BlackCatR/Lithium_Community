package com.Reveas.Hub.SuperBoots;

import org.bukkit.*;
import org.bukkit.entity.*;
import java.lang.reflect.*;

public class ActionBar
{
    private static String nmsver;
    
    static {
        ActionBar.nmsver = Bukkit.getServer().getClass().getPackage().getName();
        ActionBar.nmsver = ActionBar.nmsver.substring(ActionBar.nmsver.lastIndexOf(".") + 1);
    }
    
    public static void sendActionBar(final Player player, final String message) {
        try {
            final Class<?> c1 = Class.forName("org.bukkit.craftbukkit." + ActionBar.nmsver + ".entity.CraftPlayer");
            final Object p = c1.cast(player);
            final Class<?> c2 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".PacketPlayOutChat");
            final Class<?> c3 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".Packet");
            Object ppoc;
            if ((ActionBar.nmsver.equalsIgnoreCase("v1_8_R1") || !ActionBar.nmsver.startsWith("v1_8_")) && !ActionBar.nmsver.startsWith("v1_9_") && !ActionBar.nmsver.startsWith("v1_10_") && !ActionBar.nmsver.startsWith("v1_11_") && !ActionBar.nmsver.startsWith("v1_12_")) {
                final Class<?> c4 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".ChatSerializer");
                final Class<?> c5 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".IChatBaseComponent");
                final Method m3 = c4.getDeclaredMethod("a", String.class);
                final Object cbc = c5.cast(m3.invoke(c4, "{\"text\": \"" + message + "\"}"));
                ppoc = c2.getConstructor(c5, Byte.TYPE).newInstance(cbc, 2);
            }
            else {
                final Class<?> c4 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".ChatComponentText");
                final Class<?> c5 = Class.forName("net.minecraft.server." + ActionBar.nmsver + ".IChatBaseComponent");
                final Object o = c4.getConstructor(String.class).newInstance(message);
                ppoc = c2.getConstructor(c5, Byte.TYPE).newInstance(o, 2);
            }
            final Method m4 = c1.getDeclaredMethod("getHandle", (Class<?>[])new Class[0]);
            final Object h = m4.invoke(p, new Object[0]);
            final Field f1 = h.getClass().getDeclaredField("playerConnection");
            final Object pc = f1.get(h);
            final Method m5 = pc.getClass().getDeclaredMethod("sendPacket", c3);
            m5.invoke(pc, ppoc);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
