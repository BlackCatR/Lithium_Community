package com.Reveas.Hub.SuperBoots;

import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.meta.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.event.*;
import org.bukkit.*;
import com.Reveas.Hub.Profile.*;
import com.Reveas.Hub.Commands.*;

public class Boots_Config implements Listener
{
    @EventHandler
    public void onClick(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack love = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta lovemeta = (LeatherArmorMeta)love.getItemMeta();
        lovemeta.setColor(Color.fromRGB(255, 0, 0));
        lovemeta.setDisplayName("�4Love Boots");
        lovemeta.addEnchant(Enchantment.DURABILITY, 10, true);
        love.setItemMeta((ItemMeta)lovemeta);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Love Boots")) {
                p.getInventory().setBoots(love);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Love Boots!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void ute(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7\u279f�c Remove Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(new ItemStack(0, 0));
                p.getActivePotionEffects().clear();
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.playSound(p.getLocation(), Sound.WOLF_BARK, 1.0f, 1.0f);
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully Clear Boots!");
            }
        }
    }
    
    @EventHandler
    public void Exit(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots") && e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7\u27b4�c Exit to Back")) {
            e.setCancelled(true);
            Profile.openProfil(p);
        }
    }
    
    @EventHandler
    public void Store(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8��a Store")) {
                e.setCancelled(true);
                p.sendMessage(String.valueOf(Main.prefix) + "�7You have to buy premium rank from our store to use this �eStore.ReveasMC.com");
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void fire(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack m = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta mm = (LeatherArmorMeta)m.getItemMeta();
        mm.setColor(Color.fromRGB(205, 133, 63));
        mm.setDisplayName("�6Fire Boots");
        mm.addEnchant(Enchantment.DURABILITY, 10, true);
        m.setItemMeta((ItemMeta)mm);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�6Fire Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(m);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Fire Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void Jetpack(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack j = new ItemStack(Material.DIAMOND_BOOTS);
        final ItemMeta jj = j.getItemMeta();
        jj.setDisplayName("�cJetPack Boots");
        jj.addEnchant(Enchantment.DURABILITY, 10, true);
        j.setItemMeta(jj);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�cJetPack Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(j);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6JetPack Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void angry(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack f = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta ff = (LeatherArmorMeta)f.getItemMeta();
        ff.setColor(Color.fromRGB(100, 100, 100));
        ff.setDisplayName("�8Angry Boots");
        ff.addEnchant(Enchantment.DURABILITY, 10, true);
        f.setItemMeta((ItemMeta)ff);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�3Angry Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(f);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Angry Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void smoke(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack s = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta ss = (LeatherArmorMeta)s.getItemMeta();
        ss.setColor(Color.fromRGB(180, 100, 120));
        ss.setDisplayName("�7Smoke Boots");
        ss.addEnchant(Enchantment.DURABILITY, 10, true);
        s.setItemMeta((ItemMeta)ss);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7Smoke Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(s);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Smoke Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void musik(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack l = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta ll = (LeatherArmorMeta)l.getItemMeta();
        ll.setColor(Color.fromRGB(255, 133, 122));
        ll.setDisplayName("�5Music �6Boots");
        ll.addEnchant(Enchantment.DURABILITY, 10, true);
        l.setItemMeta((ItemMeta)ll);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�5Music �6Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(l);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Music �6Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void mystic(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack t = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta tt = (LeatherArmorMeta)t.getItemMeta();
        tt.setColor(Color.fromRGB(0, 0, 0));
        tt.setDisplayName("�8�lMystic Boots");
        tt.addEnchant(Enchantment.DURABILITY, 10, true);
        t.setItemMeta((ItemMeta)tt);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�8Mystic Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(t);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Mystic Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void wather(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack k = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta kk = (LeatherArmorMeta)k.getItemMeta();
        kk.setColor(Color.fromRGB(85, 255, 255));
        kk.setDisplayName("�3�lWather Boots");
        kk.addEnchant(Enchantment.DURABILITY, 10, true);
        k.setItemMeta((ItemMeta)kk);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�3Wather Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(k);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Wather Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void ender(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack u = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta uu = (LeatherArmorMeta)u.getItemMeta();
        uu.setColor(Color.fromRGB(255, 20, 147));
        uu.setDisplayName("�5Ender Boots");
        uu.addEnchant(Enchantment.DURABILITY, 10, true);
        u.setItemMeta((ItemMeta)uu);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�5Ender Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(u);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Ender Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void Ice(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        if (Build.build.contains(p)) {
            e.setCancelled(false);
        }
        else {
            e.setCancelled(true);
        }
        final ItemStack i = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta ii = (LeatherArmorMeta)i.getItemMeta();
        ii.setColor(Color.fromRGB(255, 255, 255));
        ii.setDisplayName("�f�lEis Boots");
        ii.addEnchant(Enchantment.DURABILITY, 10, true);
        i.setItemMeta((ItemMeta)ii);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�fEis Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(i);
                p.setAllowFlight(false);
                p.setWalkSpeed(0.2f);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Eis Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
    
    @EventHandler
    public void speed(final InventoryClickEvent e) {
        final Player p = (Player)e.getWhoClicked();
        final ItemStack o = new ItemStack(Material.LEATHER_BOOTS);
        final LeatherArmorMeta oo = (LeatherArmorMeta)o.getItemMeta();
        oo.setColor(Color.fromRGB(170, 0, 0));
        oo.setDisplayName("�2�lSpeed Boots");
        oo.addEnchant(Enchantment.DURABILITY, 10, true);
        o.setItemMeta((ItemMeta)oo);
        if (e.getInventory().getName().equalsIgnoreCase("�8\u279f�e Boots")) {
            e.setCancelled(true);
            if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�2Speed Boots")) {
                e.setCancelled(true);
                p.getInventory().setBoots(o);
                p.setAllowFlight(false);
                p.closeInventory();
                p.sendMessage(String.valueOf(Main.prefix) + "�aYou have successfully weared the �6Speed Boots�a!");
            }
            else {
                p.closeInventory();
            }
        }
    }
}
