package com.Reveas.Hub.SuperBoots;

import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.*;

public class Fire_Boots implements Listener
{
    @EventHandler
    public void VulcanB(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        try {
            if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�6Fire Boots")) {
                p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.FLAME, 1);
                p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.LAVA_POP, 1);
            }
        }
        catch (Exception ex) {}
    }
    
    @EventHandler
    public void onSneak(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        if (p.isSneaking()) {
            try {
                if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�6Fire Boots")) {
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.FLAME, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.LAVA_POP, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.MOBSPAWNER_FLAMES, 1);
                    p.playSound(p.getLocation(), Sound.FIRE, 1.0f, 2.0f);
                    p.playSound(p.getLocation(), Sound.LAVA_POP, 1.0f, 2.0f);
                }
            }
            catch (Exception ex) {}
        }
    }
}
