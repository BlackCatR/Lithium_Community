package com.Reveas.Hub.SuperBoots;

import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.*;
import org.bukkit.util.*;

public class JetPack_Boots implements Listener
{
    @EventHandler
    public void onMove(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        try {
            if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�cJetPack Boots")) {
                p.getWorld().playEffect(p.getLocation().add(0.0, 0.0, 0.0), Effect.MOBSPAWNER_FLAMES, 1);
            }
        }
        catch (NullPointerException ex) {}
    }
    
    @EventHandler
    public void onSneak(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        if (p.isSneaking()) {
            try {
                if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�cJetPack Boots")) {
                    p.getWorld().playEffect(p.getLocation().add(0.0, 0.0, 0.0), Effect.LAVA_POP, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 0.0, 0.0), Effect.MOBSPAWNER_FLAMES, 1);
                    p.playSound(p.getLocation(), Sound.EXPLODE, 2.0f, 1.0f);
                    p.setAllowFlight(true);
                    final Vector v = p.getLocation().getDirection().multiply(1.5).setY(0.8);
                    p.setVelocity(v);
                }
            }
            catch (NullPointerException ex) {}
        }
    }
}
