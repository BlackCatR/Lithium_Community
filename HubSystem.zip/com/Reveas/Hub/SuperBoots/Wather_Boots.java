package com.Reveas.Hub.SuperBoots;

import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;

public class Wather_Boots implements Listener
{
    @EventHandler
    public void onMove(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        try {
            if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�3�lWather Boots")) {
                p.getWorld().playEffect(p.getLocation().add(0.0, 1.0, 0.0), Effect.WATERDRIP, 1);
            }
        }
        catch (Exception ex) {}
    }
    
    @EventHandler
    public void onSneak(final PlayerMoveEvent e) {
        final Player p = e.getPlayer();
        if (p.isSneaking()) {
            try {
                if (p.getInventory().getBoots().getItemMeta().getDisplayName().equalsIgnoreCase("�3�lWather Boots")) {
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.8, 0.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(1.0, 1.8, 0.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(-1.0, 1.8, 0.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.8, 1.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.8, -1.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.8, -0.5), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.0, 1.8, 0.5), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(0.5, 1.8, 0.0), Effect.SPLASH, 1);
                    p.getWorld().playEffect(p.getLocation().add(-0.5, 1.8, 0.0), Effect.SPLASH, 1);
                }
            }
            catch (Exception ex) {}
        }
    }
}
