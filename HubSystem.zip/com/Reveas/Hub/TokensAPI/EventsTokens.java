package com.Reveas.Hub.TokensAPI;

import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import com.Reveas.Hub.Games.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.inventory.*;
import com.Reveas.Hub.Board.*;
import com.Reveas.Hub.Manager.*;
import org.bukkit.material.*;
import org.bukkit.scheduler.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.plugin.*;
import org.bukkit.*;
import org.bukkit.block.*;

public class EventsTokens implements Listener
{
    public HashMap<String, Block> inuse;
    
    public EventsTokens() {
        this.inuse = new HashMap<String, Block>();
    }
    
    @EventHandler
    public void blah(final PlayerInteractEntityEvent event) {
        final Entity e = event.getRightClicked();
        if (e instanceof ItemFrame) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void item(final PlayerInteractEvent e) {
        final Player p = e.getPlayer();
        final Block mat = e.getClickedBlock();
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && mat.getType() != Material.AIR && mat.getType() == Material.ENCHANTMENT_TABLE) {
            e.setCancelled(true);
            if (Stats_HubSystem.getCrystals(p.getUniqueId().toString()) <= 0) {
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + Main.F("&c&lYou don't have any Crystals &c&lto use that machine."));
                return;
            }
            Stats_HubSystem.addCrystals(p.getUniqueId().toString(), -1, false);
            Stats_HubSystem.addTokens(p.getUniqueId().toString(), this.getRandomTokens(), false);
            final ItemStack i2 = new ItemStack(Material.EMERALD);
            final ItemMeta m = i2.getItemMeta();
            m.setDisplayName(String.valueOf(String.valueOf(String.valueOf(String.valueOf(ChatColor.YELLOW.toString())))) + Stats_HubSystem.getCrystals(e.getPlayer().getUniqueId().toString()) + ChatColor.AQUA + " Enchanted Crystals");
            i2.setItemMeta(m);
            e.getPlayer().getInventory().setItem(7, i2);
            ScoreboardHandler.getBoard(p);
            p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Manager.YOU_UNLOCKED_CRYSTAL_3))))) + this.getRandomTokens() + " �7tokens!");
            p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Manager.YOU_UNLOCKED_CRYSTAL_4)))));
        }
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && mat.getType() != Material.AIR && mat.getType() == Material.LEVER) {
            e.setCancelled(true);
            if (Stats_HubSystem.getCrystals(p.getUniqueId().toString()) <= 0) {
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + Main.F("&c&lYou don't have any Crystals &c&lto use that machine."));
                return;
            }
            final BlockState state = mat.getState();
            final Lever lever = (Lever)state.getData();
            lever.setPowered(true);
            state.setData((MaterialData)lever);
            state.update();
            if (Stats_HubSystem.getCrystals(p.getUniqueId().toString()) > 0) {
                if (this.inuse.containsValue(mat)) {
                    p.sendMessage(Main.F(String.valueOf(String.valueOf(String.valueOf(Main.prefix))) + "&c&lThis machine is already in use please try on another machine."));
                    return;
                }
                final List<ItemFrame> item = new ArrayList<ItemFrame>();
                final List<Entity> NearEntites = new ArrayList<Entity>();
                for (final Entity ent : mat.getWorld().getEntities()) {
                    if (ent instanceof ItemFrame && ent.getLocation().distance(mat.getLocation()) < 6.0) {
                        NearEntites.add(ent);
                    }
                }
                for (final Entity es : NearEntites) {
                    if (es instanceof ItemFrame) {
                        try {
                            if (((ItemFrame)es).getItem().getType() == Material.ARROW) {
                                continue;
                            }
                            item.add((ItemFrame)es);
                            ((ItemFrame)es).setRotation(Rotation.NONE);
                        }
                        catch (Exception ex) {}
                    }
                }
                this.inuse.put(p.getName(), mat);
                p.sendMessage(Manager.YOU_UNLOCKED_CRYSTAL_1);
                p.sendMessage(Manager.YOU_UNLOCKED_CRYSTAL_2);
                Stats_HubSystem.addCrystals(p.getUniqueId().toString(), -1, true);
                new BukkitRunnable() {
                    long t = 10L;
                    
                    public void run() {
                        this.t += 10L;
                        p.playSound(p.getLocation(), Sound.NOTE_PIANO, 20.0f, 10.0f);
                        for (final ItemFrame items : item) {
                            mat.getWorld().playEffect(items.getLocation().add(0.0, 1.0, 0.0), Effect.COLOURED_DUST, 2);
                            mat.getWorld().playEffect(items.getLocation().add(0.0, 1.0, 0.0), Effect.FIREWORKS_SPARK, 2);
                            final Random rand = new Random();
                            final int i = rand.nextInt(7);
                            if (i == 0) {
                                items.setItem(new ItemStack(Material.GOLD_NUGGET));
                            }
                            if (i == 1) {
                                final ItemStack itemf = new ItemStack(Material.PAPER);
                                final ItemMeta itemmeta = itemf.getItemMeta();
                                itemmeta.setDisplayName(Main.F("&c&l"));
                                itemf.setItemMeta(itemmeta);
                                items.setItem(itemf);
                            }
                            if (i == 2) {
                                items.setItem(new ItemStack(Material.GOLD_NUGGET));
                            }
                            if (i == 3) {
                                final ItemStack itemf = new ItemStack(Material.MELON);
                                final ItemMeta itemmeta = itemf.getItemMeta();
                                itemmeta.setDisplayName(Main.F("&a&l"));
                                itemf.setItemMeta(itemmeta);
                                items.setItem(itemf);
                            }
                            if (i == 4) {
                                items.setItem(new ItemStack(Material.MAGMA_CREAM));
                            }
                            if (i == 6) {
                                final ItemStack itemf = new ItemStack(Material.BLAZE_POWDER);
                                final ItemMeta itemmeta = itemf.getItemMeta();
                                itemmeta.setDisplayName(Main.F("&b&l"));
                                itemf.setItemMeta(itemmeta);
                                items.setItem(itemf);
                            }
                            if (i == 7) {
                                final ItemStack itemf = new ItemStack(Material.NETHER_STAR);
                                final ItemMeta itemmeta = itemf.getItemMeta();
                                itemmeta.setDisplayName(Main.F("&b&l"));
                                itemf.setItemMeta(itemmeta);
                                items.setItem(itemf);
                            }
                            if (i == 8) {
                                final ItemStack itemf = new ItemStack(Material.FEATHER);
                                final ItemMeta itemmeta = itemf.getItemMeta();
                                itemmeta.setDisplayName(Main.F("&f&l"));
                                itemf.setItemMeta(itemmeta);
                                items.setItem(itemf);
                            }
                        }
                        if (this.t >= 500L) {
                            this.cancel();
                        }
                    }
                }.runTaskTimer((Plugin)Main.plugin, 0L, 1L);
                Main.Crystals = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)Main.plugin, (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        int rand = 0;
                        for (final ItemFrame items : item) {
                            try {
                                if (items.getItem().getItemMeta().getDisplayName().equals(Main.F("&c&l"))) {
                                    rand += new Random().nextInt(15);
                                }
                                if (items.getItem().getItemMeta().getDisplayName().equals(Main.F("&a&l"))) {
                                    rand += new Random().nextInt(30);
                                }
                                if (items.getItem().getItemMeta().getDisplayName().equals(Main.F("&7&l"))) {
                                    rand += new Random().nextInt(30);
                                }
                                if (items.getItem().getItemMeta().getDisplayName().equals(Main.F("&f&l"))) {
                                    rand += new Random().nextInt(30);
                                }
                                if (items.getItem().getItemMeta().getDisplayName().equals(Main.F("&f&l"))) {
                                    rand += new Random().nextInt(30);
                                }
                                if (!items.getItem().getItemMeta().getDisplayName().equals(Main.F("&b&l"))) {
                                    continue;
                                }
                                rand += new Random().nextInt(30);
                            }
                            catch (Exception ex) {}
                        }
                        EventsTokens.this.inuse.clear();
                        EventsTokens.this.inuse.keySet().clear();
                        EventsTokens.this.inuse.values().clear();
                        final int randint = rand + new Random().nextInt(10) + 30;
                        Stats_HubSystem.addTokens(p.getUniqueId().toString(), EventsTokens.this.getRandomTokens(), true);
                        ScoreboardHandler.getBoard(p);
                        p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Manager.YOU_UNLOCKED_CRYSTAL_3))))) + EventsTokens.this.getRandomTokens() + " �7tokens!");
                        p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Manager.YOU_UNLOCKED_CRYSTAL_4)))));
                        final ItemStack i2 = new ItemStack(Material.EMERALD);
                        final ItemMeta m = i2.getItemMeta();
                        m.setDisplayName(String.valueOf(String.valueOf(String.valueOf(String.valueOf(ChatColor.YELLOW.toString())))) + Stats_HubSystem.getCrystals(e.getPlayer().getUniqueId().toString()) + ChatColor.AQUA + " Enchanted Crystals");
                        i2.setItemMeta(m);
                        e.getPlayer().getInventory().setItem(7, i2);
                        p.playSound(p.getLocation(), Sound.LEVEL_UP, 10.0f, 10.0f);
                        e.getClickedBlock().setType(Material.LEVER);
                        e.getClickedBlock().getFace(mat);
                        final BlockState state = mat.getState();
                        lever.setPowered(false);
                        state.setData((MaterialData)lever);
                        state.update();
                        for (final ItemFrame items2 : item) {
                            items2.setItem(new ItemStack(Material.CLAY_BALL));
                        }
                    }
                }, 60L);
            }
            else {
                e.setCancelled(true);
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + Main.F("&c&lYou don't have any &lCrystals &c&lto use that machine."));
            }
        }
    }
    
    public Integer getRandomTokens() {
        final ArrayList localArrayList = new ArrayList();
        final Random localRandom = new Random();
        localArrayList.add(45);
        localArrayList.add(35);
        localArrayList.add(25);
        localArrayList.add(15);
        localArrayList.add(5);
        localArrayList.add(14);
        localArrayList.add(34);
        localArrayList.add(74);
        localArrayList.add(34);
        localArrayList.add(23);
        localArrayList.add(13);
        localArrayList.add(19);
        localArrayList.add(52);
        localArrayList.add(37);
        localArrayList.add(69);
        localArrayList.add(121);
        localArrayList.add(143);
        localArrayList.add(169);
        localArrayList.add(238);
        localArrayList.add(314);
        localArrayList.add(397);
        localArrayList.add(421);
        localArrayList.add(591);
        localArrayList.add(103);
        localArrayList.add(121);
        localArrayList.add(143);
        localArrayList.add(169);
        localArrayList.add(238);
        localArrayList.add(314);
        localArrayList.add(397);
        localArrayList.add(421);
        localArrayList.add(591);
        localArrayList.add(1);
        localArrayList.add(1000);
        localArrayList.add(1000);
        final int i = localArrayList.size();
        int j = 0;
        if (i == 0) {
            return 0;
        }
        if (i >= 1) {
            j = localRandom.nextInt(i);
        }
        return localArrayList.get(j);
    }
}
