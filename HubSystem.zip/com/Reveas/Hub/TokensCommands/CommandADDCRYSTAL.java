package com.Reveas.Hub.TokensCommands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.util.*;
import com.Reveas.api.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import com.Reveas.Hub.Board.*;
import org.bukkit.inventory.meta.*;

public class CommandADDCRYSTAL implements CommandExecutor
{
    public boolean onCommand(final CommandSender paramCommandSender, final Command paramCommand, final String paramString, final String[] paramArrayOfString) {
        if (!(paramCommandSender instanceof Player)) {
            paramCommandSender.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou must be a player to use this command.");
            return false;
        }
        final Player localPlayer1 = (Player)paramCommandSender;
        if (paramCommand.getName().equalsIgnoreCase("addcrystal")) {
            if (!Reveas.checkPermission(localPlayer1.getName(), Rank.HEADADMIN)) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou are not allowed to use this.");
                return false;
            }
            if (paramArrayOfString.length == 0) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�").replaceAll("&", "�"))))) + "�e/addcrystal [Player] [Amount]");
                return false;
            }
            if (paramArrayOfString.length == 1) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�e/addcrystal [Player] [Amount]");
                return false;
            }
            if (paramArrayOfString.length == 2) {
                if (this.isInt(paramArrayOfString[1])) {
                    final Player localPlayer2 = Bukkit.getPlayerExact(paramArrayOfString[0]);
                    if (localPlayer2 != null) {
                        final int i = Integer.parseInt(paramArrayOfString[1]);
                        Stats_HubSystem.addCrystals(localPlayer2.getUniqueId().toString(), i, false);
                        localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou give �5" + i + " �ecrystal �eto �a" + localPlayer2.getName() + "�e.");
                        final ItemStack i2 = new ItemStack(Material.EMERALD);
                        final ItemMeta m = i2.getItemMeta();
                        m.setDisplayName(String.valueOf(String.valueOf(String.valueOf(String.valueOf(ChatColor.YELLOW.toString())))) + Stats_HubSystem.getCrystals(localPlayer2.getUniqueId().toString()) + ChatColor.AQUA + " Enchanted Crystals");
                        i2.setItemMeta(m);
                        localPlayer2.getInventory().setItem(7, i2);
                        localPlayer2.updateInventory();
                        ScoreboardHandler.getBoard(localPlayer1);
                        ScoreboardHandler.getBoard(localPlayer2);
                        return true;
                    }
                    localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�ePlayer not found.");
                    return false;
                }
                else {
                    localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�e/addcrystal [Player] [Amount]");
                }
            }
        }
        return false;
    }
    
    public boolean isInt(final String paramString) {
        try {
            Integer.parseInt(paramString);
            return true;
        }
        catch (NumberFormatException ex) {
            return false;
        }
    }
}
