package com.Reveas.Hub.TokensCommands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.api.util.*;
import com.Reveas.api.*;
import org.bukkit.*;
import com.Reveas.Hub.Games.*;
import com.Reveas.Hub.Board.*;

public class CommandADDTOKENS implements CommandExecutor
{
    public boolean onCommand(final CommandSender paramCommandSender, final Command paramCommand, final String paramString, final String[] paramArrayOfString) {
        if (!(paramCommandSender instanceof Player)) {
            paramCommandSender.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou must be a player to use this command.");
            return false;
        }
        final Player localPlayer1 = (Player)paramCommandSender;
        if (paramCommand.getName().equalsIgnoreCase("addtokens")) {
            if (!Reveas.checkPermission(localPlayer1.getName(), Rank.HEADADMIN)) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou are not allowed to use this.");
                return false;
            }
            if (paramArrayOfString.length == 0) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�e/addtokens [Player] [Amount]");
                return false;
            }
            if (paramArrayOfString.length == 1) {
                localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�e/addtokens [Player] [Amount]");
                return false;
            }
            if (paramArrayOfString.length == 2) {
                if (this.isInt(paramArrayOfString[1])) {
                    final Player localPlayer2 = Bukkit.getPlayerExact(paramArrayOfString[0]);
                    if (localPlayer2 != null) {
                        final int i = Integer.parseInt(paramArrayOfString[1]);
                        Stats_HubSystem.addTokens(localPlayer2.getUniqueId().toString(), i, false);
                        localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou give �5" + i + " �eTokens �eto �a" + localPlayer2.getName() + "�e.");
                        ScoreboardHandler.getBoard(localPlayer1);
                        ScoreboardHandler.getBoard(localPlayer2);
                        return true;
                    }
                    localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�ePlayer not found.");
                    return false;
                }
                else {
                    localPlayer1.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�e/addtokens [Player] [Amount]");
                }
            }
        }
        return false;
    }
    
    public boolean isInt(final String paramString) {
        try {
            Integer.parseInt(paramString);
            return true;
        }
        catch (NumberFormatException ex) {
            return false;
        }
    }
}
