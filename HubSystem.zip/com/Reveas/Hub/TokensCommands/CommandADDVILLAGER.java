package com.Reveas.Hub.TokensCommands;

import org.bukkit.command.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.potion.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Inventorys.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.*;
import org.bukkit.craftbukkit.v1_8_R3.entity.*;
import net.minecraft.server.v1_8_R3.*;

public class CommandADDVILLAGER implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        final Player p2 = (Player)sender;
        if (args.length == 0) {
            sender.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eUsage: /addVillager < type >");
        }
        else if (args.length == 1) {
            try {
                if (args[0].equalsIgnoreCase("toc")) {
                    if (sender instanceof Player) {
                        final Player p3 = (Player)sender;
                        final Location loc = p3.getLocation();
                        final Villager v = (Villager)loc.getWorld().spawnCreature(loc, CreatureType.VILLAGER);
                        v.setCustomName("�e�lTokens to Credits");
                        v.setCustomNameVisible(true);
                        v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 10000));
                        freezeEntity((Entity)v);
                        p3.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou spawned �eTokens to Credits �3Villager.");
                    }
                    else {
                        sender.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou have to be a Player to use this!");
                    }
                }
                else {
                    if (args[0].equalsIgnoreCase("cot")) {
                        final Player p3 = (Player)sender;
                        final Location loc = p3.getLocation();
                        final Villager v = (Villager)loc.getWorld().spawnCreature(loc, CreatureType.VILLAGER);
                        v.setCustomName("�e�lCredits to Tokens");
                        v.setCustomNameVisible(true);
                        v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 10000));
                        freezeEntity((Entity)v);
                        p3.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou spawned �eCredits to Tokens �3Villager.");
                    }
                    if (args[0].equalsIgnoreCase("skywars")) {
                        final Player p3 = (Player)sender;
                        final Location loc = p3.getLocation();
                        final Villager v = (Villager)loc.getWorld().spawnCreature(loc, CreatureType.VILLAGER);
                        v.setCustomName("�e�lSkywars Shop");
                        v.setCustomNameVisible(true);
                        v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 10000));
                        freezeEntity((Entity)v);
                        p3.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou spawned �eSkywars shop �3Villager.");
                    }
                    if (args[0].equalsIgnoreCase("ffa")) {
                        final Player p3 = (Player)sender;
                        FFA.ShopFFA.setItem(11, FFA.Trails());
                        FFA.ShopFFA.setItem(15, FFA.Sounds());
                        FFA.ShopFFA.setItem(13, FFA.Perks());
                        FFA.ShopFFA.setItem(26, FFA.Close());
                        p3.openInventory(FFA.ShopFFA);
                        p3.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou spawned �eFFA shop �3Villager.");
                    }
                    if (args[0].equalsIgnoreCase("hats")) {
                        final Player p4 = (Player)sender;
                        final Location loc = p4.getLocation();
                        final Villager v = (Villager)loc.getWorld().spawnCreature(loc, CreatureType.VILLAGER);
                        v.setCustomName("�e�lHats");
                        v.setCustomNameVisible(true);
                        v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 10000));
                        v.setProfession(Villager.Profession.BLACKSMITH);
                        p4.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�eYou spawned Hats �3Villager.");
                    }
                    if (args[0].equalsIgnoreCase("speed")) {
                        final Player p3 = (Player)sender;
                        final Location loc = p3.getLocation();
                        final Villager v = (Villager)loc.getWorld().spawnCreature(loc, CreatureType.VILLAGER);
                        v.setCustomName("�e�lSpeed Shop");
                        v.setCustomNameVisible(true);
                        v.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000, 10000));
                        final ItemStack i = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
                        final SkullMeta m = (SkullMeta)i.getItemMeta();
                        m.setOwner("dogs4life");
                        i.setItemMeta((ItemMeta)m);
                        v.getEquipment().setHelmet(i);
                        freezeEntity((Entity)v);
                        this.setFreeze((Entity)v);
                        p3.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou spawned Speed �3Villager.");
                    }
                }
            }
            catch (Exception ex) {}
        }
        else {
            sender.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�eYou are not allowed to use this.");
        }
        return false;
    }
    
    public void setFreeze(final Entity en) {
        final net.minecraft.server.v1_8_R3.Entity nmsEn = ((CraftEntity)en).getHandle();
        final NBTTagCompound compound = new NBTTagCompound();
        nmsEn.c(compound);
        compound.setByte("NoAI", (byte)1);
        compound.setInt("Silent", 1);
        nmsEn.f(compound);
    }
    
    public static void freezeEntity(final Entity en) {
        final net.minecraft.server.v1_8_R3.Entity nmsEn = ((CraftEntity)en).getHandle();
        final NBTTagCompound compound = new NBTTagCompound();
        nmsEn.c(compound);
        compound.setByte("NoAI", (byte)1);
        compound.setInt("Silent", 1);
        nmsEn.f(compound);
    }
}
