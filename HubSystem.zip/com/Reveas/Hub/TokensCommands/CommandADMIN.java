package com.Reveas.Hub.TokensCommands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Inventorys.*;
import com.Reveas.Hub.Games.*;
import com.Reveas.Hub.Board.*;
import org.bukkit.*;

public class CommandADMIN implements CommandExecutor
{
    public boolean onCommand(final CommandSender s, final Command cmd, final String commandLabel, final String[] args) {
        if (!(s instanceof Player)) {
            s.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�cYou must be a player to use this command.");
            return false;
        }
        final Player p = (Player)s;
        if (cmd.getName().equalsIgnoreCase("removevillager")) {
            p.sendMessage(String.valueOf(Main.prefix) + "�aClick villager on remove.");
        }
        if (cmd.getName().equalsIgnoreCase("ffa-shop")) {
            FFA.ShopFFA.setItem(11, FFA.Trails());
            FFA.ShopFFA.setItem(15, FFA.Sounds());
            FFA.ShopFFA.setItem(13, FFA.Perks());
            FFA.ShopFFA.setItem(26, FFA.Close());
            p.openInventory(FFA.ShopFFA);
        }
        if (cmd.getName().equalsIgnoreCase("tokens")) {
            if (args.length == 0) {
                p.sendMessage("�8�l\u258f �aTokens �8\u258f �7You Have �a" + Stats_HubSystem.getTokens(p.getUniqueId().toString()) + "�7 Of Tokens");
                ScoreboardHandler.getBoard(p);
                return true;
            }
            if (args.length == 1) {
                final Player target = Bukkit.getPlayerExact(args[0]);
                if (target != null) {
                    p.sendMessage("�8�l\u258f �aTokens �8\u258f �7You Have �a" + Stats_HubSystem.getTokens(target.getUniqueId().toString()) + "�7 Of Tokens");
                    ScoreboardHandler.getBoard(target);
                    ScoreboardHandler.getBoard(p);
                    return true;
                }
                p.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix).replaceAll("&", "�"))))) + "�7Player not found.");
                return false;
            }
        }
        return false;
    }
}
