package com.Reveas.Hub.TokensCommands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Games.*;
import org.bukkit.*;

public class NickFFA_CMD implements CommandExecutor
{
    public boolean onCommand(final CommandSender Sender, final Command Cmd, final String Label, final String[] Args) {
        if (Sender instanceof Player) {
            final Player P = (Player)Sender;
            if (Cmd.getName().equalsIgnoreCase("FFA") && P.hasPermission("sg.admin")) {
                if (Args.length == 0) {
                    P.sendMessage(String.valueOf(Main.prefix) + "�8�m--------------[�e�lFFA �5�lNick�8�m]--------------");
                    P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�5/FFANick set �7set the nick of you a player.");
                    P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�5/FFANick Random �7set the nick of you a nick random.");
                    P.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�5/FFANick unNick �7Reset your a players nick.");
                    P.sendMessage(String.valueOf(Main.prefix) + "�8�m-------------------------------------");
                }
                if (Args.length > 0) {
                    if (Args[0].equalsIgnoreCase("Random")) {
                        Stats_FFA.setParam("FFASettings", P.getUniqueId().toString(), "Nick", "NULL");
                        P.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�aYour name has been �enick random �asuccessfully!");
                        P.playSound(P.getLocation(), Sound.ANVIL_BREAK, 1.0f, 1.0f);
                    }
                    if (Args[0].equalsIgnoreCase("set")) {
                        Stats_FFA.setParam("FFASettings", P.getUniqueId().toString(), "Nick", "true");
                        Stats_FFA.setParam("FFASettings", P.getUniqueId().toString(), "NickID", Args[1]);
                        P.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�aYour name has been �enick " + Args[1] + " �asuccessfullya3.");
                        P.playSound(P.getLocation(), Sound.ANVIL_BREAK, 1.0f, 1.0f);
                    }
                    if (Args[0].equalsIgnoreCase("unNick")) {
                        Stats_FFA.setParam("FFASettings", P.getUniqueId().toString(), "Nick", "false");
                        P.sendMessage(String.valueOf(String.valueOf(String.valueOf(String.valueOf(Main.prefix)))) + "�aYour name has been reset �asuccessfully!");
                        P.playSound(P.getLocation(), Sound.ANVIL_BREAK, 1.0f, 1.0f);
                    }
                    else {
                        P.sendMessage(String.valueOf(Main.prefix) + "�c�lYou must have a �aEmerald �c�l,�5 VIP�c�l rank to use this nick.");
                    }
                }
            }
        }
        return false;
    }
}
