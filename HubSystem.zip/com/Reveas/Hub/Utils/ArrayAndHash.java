package com.Reveas.Hub.Utils;

import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.inventory.*;

public class ArrayAndHash
{
    public static ArrayList<String> build;
    public static ArrayList<String> Playing;
    public static ArrayList<String> Scoreboard;
    public static ArrayList<String> AllPlayers;
    public static ArrayList<String> noTeleport;
    public static ArrayList<String> Lobby;
    public static ArrayList<String> Spawn;
    public static HashMap<String, Player> Range;
    public static Map<UUID, ItemStack[]> save;
    public static Map<UUID, ItemStack[]> armor;
    public static ArrayList<Player> jumb;
    public static HashMap<Player, Integer> killstreaks;
    public static ArrayList<String> ToggleRank;
    public static ArrayList<String> DeathonSpec;
    public static ArrayList<String> Scramble;
    public static HashMap<String, Player> target;
    
    static {
        ArrayAndHash.noTeleport = new ArrayList<String>();
        ArrayAndHash.Lobby = new ArrayList<String>();
        ArrayAndHash.AllPlayers = new ArrayList<String>();
        ArrayAndHash.target = new HashMap<String, Player>();
        ArrayAndHash.build = new ArrayList<String>();
        ArrayAndHash.Playing = new ArrayList<String>();
        ArrayAndHash.save = new HashMap<UUID, ItemStack[]>();
        ArrayAndHash.armor = new HashMap<UUID, ItemStack[]>();
        ArrayAndHash.Spawn = new ArrayList<String>();
        ArrayAndHash.Scoreboard = new ArrayList<String>();
        ArrayAndHash.Range = new HashMap<String, Player>();
        ArrayAndHash.DeathonSpec = new ArrayList<String>();
        ArrayAndHash.killstreaks = new HashMap<Player, Integer>();
        ArrayAndHash.ToggleRank = new ArrayList<String>();
        ArrayAndHash.Scramble = new ArrayList<String>();
    }
}
