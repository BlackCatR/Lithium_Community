package com.Reveas.Hub.Utils;

import org.bukkit.*;
import org.bukkit.potion.*;
import net.minecraft.server.v1_8_R3.*;
import org.bukkit.craftbukkit.v1_8_R3.entity.*;
import com.Reveas.Hub.Gadgets.*;
import org.bukkit.entity.*;

public class BallonFunc
{
    Bat bat;
    Player player;
    Material mat;
    byte sID;
    
    public BallonFunc(final Player p, final Material mat, final int subID) {
        final FallingBlock block = p.getWorld().spawnFallingBlock(p.getLocation().add(0.0, 2.0, 0.0), mat, (byte)subID);
        block.setDropItem(false);
        final Bat bat = (Bat)p.getWorld().spawnEntity(p.getLocation().add(0.0, 2.0, 0.0), EntityType.BAT);
        bat.setPassenger((Entity)block);
        bat.setRemoveWhenFarAway(false);
        bat.setLeashHolder((Entity)p);
        bat.setCanPickupItems(false);
        bat.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 255));
        final NBTTagCompound compound = new NBTTagCompound();
        ((CraftEntity)bat).getHandle().e(compound);
        compound.setInt("Silent", 1);
        ((CraftEntity)bat).getHandle().f(compound);
        Data.ballon.put(p.getUniqueId(), this);
        this.bat = bat;
        this.mat = mat;
        this.player = p;
        this.sID = (byte)subID;
    }
    
    public Material getMat() {
        return this.mat;
    }
    
    public Bat getBat() {
        return this.bat;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public byte getsID() {
        return this.sID;
    }
    
    public boolean hasPassenger() {
        return this.bat.getPassenger() != null;
    }
    
    public void setPassenger(final Material mat, final int subID) {
        final FallingBlock block = this.player.getWorld().spawnFallingBlock(this.player.getLocation().add(0.0, 2.0, 0.0), mat, (byte)subID);
        block.setDropItem(false);
        this.bat.setPassenger((Entity)block);
    }
    
    public void removeBallon() {
        this.bat.getPassenger().remove();
        this.bat.remove();
        Data.ballon.remove(this.player.getUniqueId());
        Data.ballon.remove(this);
    }
}
