package com.Reveas.Hub.Utils;

import java.io.*;
import org.bukkit.configuration.file.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class ConfigManager
{
    public static File file;
    public static FileConfiguration cfg;
    
    static {
        ConfigManager.file = new File("plugins/ReveasSystem/Warps", "spawn.yml");
        ConfigManager.cfg = (FileConfiguration)YamlConfiguration.loadConfiguration(ConfigManager.file);
    }
    
    public static void loadCfg() {
        ConfigManager.cfg.options().copyDefaults(true);
        try {
            ConfigManager.cfg.save(ConfigManager.file);
        }
        catch (Exception ex) {}
    }
    
    public static Boolean locationExists(final String name) {
        if (ConfigManager.cfg.contains(name)) {
            return true;
        }
        return false;
    }
    
    public static void setWarp(final Player p, final String name) {
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".world", (Object)p.getWorld().getName());
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".x", (Object)p.getLocation().getBlockX());
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".y", (Object)p.getLocation().getBlockY());
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".z", (Object)p.getLocation().getBlockZ());
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".yaw", (Object)p.getLocation().getYaw());
        ConfigManager.cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".pitch", (Object)p.getLocation().getPitch());
        try {
            ConfigManager.cfg.save(ConfigManager.file);
        }
        catch (Exception ex) {}
    }
    
    public static void warpPlayer(final Player p, final String warpname) {
        if (ConfigManager.cfg.contains(warpname)) {
            final String w = ConfigManager.cfg.getString(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".world");
            final int x = ConfigManager.cfg.getInt(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".x");
            final int y = ConfigManager.cfg.getInt(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".y");
            final int z = ConfigManager.cfg.getInt(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".z");
            final Location loc = new Location(Bukkit.getWorld(w), (double)x, (double)y, (double)z);
            loc.setYaw((float)ConfigManager.cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".yaw"));
            loc.setPitch((float)ConfigManager.cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(warpname))) + ".pitch"));
            p.teleport(loc);
        }
    }
}
