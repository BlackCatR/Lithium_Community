package com.Reveas.Hub.Utils;

import com.Reveas.Hub.Main.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.entity.*;
import org.bukkit.potion.*;
import java.util.*;
import org.bukkit.plugin.*;
import com.google.common.io.*;
import java.io.*;
import org.bukkit.configuration.file.*;
import org.bukkit.*;
import java.lang.reflect.*;

public class FriendsUtils
{
    Main friends;
    
    public FriendsUtils(final Main friends) {
        this.friends = friends;
    }
    
    public ItemStack createItemwithID(final int id, final int subid, final int amount, final String DisplayName, final ArrayList<String> lore) {
        final ItemStack is = new ItemStack(id, amount, (short)subid);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName(DisplayName);
        im.setLore((List)lore);
        is.setItemMeta(im);
        return is;
    }
    
    public ItemStack createItemwithMaterial(final Material m, final int subid, final int amount, final String DisplayName, final ArrayList<String> lore) {
        final ItemStack is = new ItemStack(m, amount, (short)subid);
        final ItemMeta im = is.getItemMeta();
        im.setDisplayName(DisplayName);
        im.setLore((List)lore);
        is.setItemMeta(im);
        return is;
    }
    
    public ItemStack createHead(final String owner, final ArrayList<String> lore) {
        final ItemStack i = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta sm = (SkullMeta)i.getItemMeta();
        sm.setOwner(owner);
        sm.setLore((List)lore);
        i.setItemMeta((ItemMeta)sm);
        return i;
    }
    
    public ItemStack createHead(final String owner, final ArrayList<String> lore, final String name) {
        final ItemStack i = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta sm = (SkullMeta)i.getItemMeta();
        sm.setOwner(owner);
        sm.setDisplayName(name);
        sm.setLore((List)lore);
        i.setItemMeta((ItemMeta)sm);
        return i;
    }
    
    public boolean isNumeric(final String number) {
        try {
            Integer.parseInt(number);
        }
        catch (Exception exception) {
            return false;
        }
        return true;
    }
    
    public int getRandom(final int max) {
        final Random r = new Random();
        return r.nextInt(max);
    }
    
    public String getTime(final int time) {
        final int minutes = time / 60;
        String min;
        if (minutes <= 9) {
            min = "0" + minutes;
        }
        else {
            min = new StringBuilder().append(minutes).toString();
        }
        final int seconds = time - minutes * 60;
        String sec;
        if (seconds <= 9) {
            sec = "0" + seconds;
        }
        else {
            sec = new StringBuilder().append(seconds).toString();
        }
        return String.valueOf(String.valueOf(String.valueOf(min))) + ":" + sec;
    }
    
    public String getKD(final int kills, final int deaths, final int splitafter) {
        if (kills == 0 && deaths == 0) {
            return "0.0";
        }
        if (kills >= 1 && deaths == 0) {
            return new StringBuilder().append((double)kills).toString();
        }
        if (splitafter == 0) {
            return new StringBuilder().append(kills / deaths).toString();
        }
        String kd = new StringBuilder().append(kills / deaths).toString();
        if (kd.length() >= splitafter) {
            kd = kd.substring(0, splitafter);
            return kd;
        }
        return new StringBuilder().append(kills / deaths).toString();
    }
    
    public String getPercentof(final int hundredpercent, final int div, final int splitafter) {
        String percent = "0.00%";
        if (hundredpercent == 0) {
            return percent;
        }
        final double first = div / hundredpercent;
        final double end = first * 100.0;
        percent = new StringBuilder().append(end).toString();
        if (splitafter == 0) {
            return String.valueOf(String.valueOf(String.valueOf(percent))) + "%";
        }
        String wl = percent;
        if (wl.length() >= splitafter) {
            wl = wl.substring(0, splitafter);
            return String.valueOf(String.valueOf(String.valueOf(wl))) + "%";
        }
        return String.valueOf(String.valueOf(String.valueOf(percent))) + "%";
    }
    
    public List<String> convertStringArrayToArraylist(final String str, final String splitby) {
        final List<String> strFragments = new ArrayList<String>();
        final String[] strArray = str.split(splitby);
        for (int i = 0; i < strArray.length; ++i) {
            strFragments.add(strArray[i]);
        }
        return strFragments;
    }
    
    public long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }
    
    public int getRemainingSeconds(final long currenttimemillis, final long timemillisbefore) {
        long millis;
        int seconds;
        for (millis = timemillisbefore - currenttimemillis, seconds = 0; millis > 1000L; millis -= 1000L, ++seconds) {}
        return seconds;
    }
    
    public int getRemainingMinutes(int seconds) {
        int minutes;
        for (minutes = 0; seconds > 60; seconds -= 60, ++minutes) {}
        return minutes;
    }
    
    public int getRemainingHours(int minutes) {
        int hours;
        for (hours = 0; minutes > 60; minutes -= 60, ++hours) {}
        return hours;
    }
    
    public int getRemainingDays(int hours) {
        int days;
        for (days = 0; hours > 24; hours -= 24, ++days) {}
        return days;
    }
    
    public int getRemainingWeeks(int days) {
        int weeks;
        for (weeks = 0; days > 7; days -= 7, ++weeks) {}
        return weeks;
    }
    
    public String getRemainingTime(final long start, final long timemillisbefore, final String nullresult, final String color) {
        if (timemillisbefore == -1L) {
            return nullresult;
        }
        long millis = timemillisbefore - start;
        long seconds = 0L;
        long minutes = 0L;
        long hours = 0L;
        long days = 0L;
        long weeks = 0L;
        while (millis > 1000L) {
            millis -= 1000L;
            ++seconds;
        }
        while (seconds > 60L) {
            seconds -= 60L;
            ++minutes;
        }
        while (minutes > 60L) {
            seconds -= 60L;
            ++hours;
        }
        while (hours > 24L) {
            seconds -= 24L;
            ++days;
        }
        while (days > 7L) {
            days -= 7L;
            ++weeks;
        }
        return String.valueOf(String.valueOf(String.valueOf(color))) + weeks + " Woche(n) " + days + " Tag(e) " + hours + " Stunde(n) " + minutes + " Minute(n) " + seconds + " Sekunde(n)";
    }
    
    public String getRemainingHours(final long currenttimemillis, final long timemillisbefore, final String nullresult, final String color) {
        if (timemillisbefore == -1L) {
            return nullresult;
        }
        long millis = timemillisbefore - currenttimemillis;
        long seconds = 0L;
        long minutes = 0L;
        long hours = 0L;
        while (millis > 1000L) {
            millis -= 1000L;
            ++seconds;
        }
        while (seconds > 60L) {
            seconds -= 60L;
            ++minutes;
        }
        while (minutes > 60L) {
            seconds -= 60L;
            ++hours;
        }
        return String.valueOf(String.valueOf(String.valueOf(color))) + hours + " Stunde(n) " + minutes + " Minute(n) " + seconds + " Sekunde(n)";
    }
    
    public void refreshPlayer(final Player player) {
        player.setExp(0.0f);
        player.setFoodLevel(20);
        player.setHealth(20.0);
        player.setExp(0.0f);
        player.setLevel(0);
        player.setFireTicks(0);
        player.setGameMode(GameMode.SURVIVAL);
        for (final PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
    }
    
    public void removePotionEffects(final Player player) {
        for (final PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
    }
    
    public Player getRandomOnlinePlayer() {
        final List<Player> list = new ArrayList<Player>();
        for (final Player player : Bukkit.getOnlinePlayers()) {
            list.add(player);
        }
        final int rn = this.getRandom(list.size());
        return list.get(rn);
    }
    
    public String getRandomString(final List<String> list) {
        final int rn = this.getRandom(list.size());
        return list.get(rn);
    }
    
    public Player getRandomPlayer(final List<Player> list) {
        final int rn = this.getRandom(list.size());
        return list.get(rn);
    }
    
    public Object getRandomObject(final List<Object> list) {
        final int rn = this.getRandom(list.size());
        return list.get(rn);
    }
    
    public void connect(final Player player, final String servername) {
        final ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("Connect");
        out.writeUTF(servername);
        player.sendPluginMessage((Plugin)this.friends, "BungeeCord", out.toByteArray());
    }
    
    public void hidePlayer(final Player player) {
        for (final Player player2 : Bukkit.getOnlinePlayers()) {
            player2.hidePlayer(player);
        }
    }
    
    public void showPlayer(final Player player) {
        for (final Player player2 : Bukkit.getOnlinePlayers()) {
            player2.showPlayer(player);
        }
    }
    
    public void hidePlayertoIngames(final Player player, final List<Player> spectators) {
        for (final Player player2 : Bukkit.getOnlinePlayers()) {
            if (!spectators.contains(player2)) {
                player2.hidePlayer(player);
            }
        }
    }
    
    public void showPlayertoIngames(final Player player, final List<Player> spectators) {
        for (final Player player2 : Bukkit.getOnlinePlayers()) {
            if (!spectators.contains(player2)) {
                player2.showPlayer(player);
            }
        }
    }
    
    public void createNewFile(final String filename, final String path) {
        final File file = new File("plugins/" + path, filename);
        if (file.exists()) {
            return;
        }
        try {
            file.createNewFile();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public File getFile(final String filename, final String path) {
        final File file = new File("plugins/" + path, filename);
        return file;
    }
    
    public void deleteFile(final String filename, final String path) {
        final File file = new File("plugins/" + path, filename);
        file.delete();
    }
    
    public FileConfiguration getConfiguration(final String filename, final String path) {
        return (FileConfiguration)YamlConfiguration.loadConfiguration(this.getFile(filename, path));
    }
    
    public Location getLocation(final String ymlname, final String name, final String path) {
        final FileConfiguration cfg = this.getConfiguration(ymlname, path);
        final double x = cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(name))) + ".X");
        final double y = cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(name))) + ".Y");
        final double z = cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(name))) + ".Z");
        final double yaw = cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(name))) + ".Yaw");
        final double pitch = cfg.getDouble(String.valueOf(String.valueOf(String.valueOf(name))) + ".Pitch");
        final String world = cfg.getString(String.valueOf(String.valueOf(String.valueOf(name))) + ".World");
        final Location l = new Location(Bukkit.getWorld(world), x, y, z);
        l.setYaw((float)yaw);
        l.setPitch((float)pitch);
        return l;
    }
    
    public void saveLocation(final Player p, final String ymlname, final String name, final String path) {
        final FileConfiguration cfg = this.getConfiguration(ymlname, path);
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".X", (Object)p.getLocation().getX());
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".Y", (Object)p.getLocation().getY());
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".Z", (Object)p.getLocation().getZ());
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".Yaw", (Object)p.getLocation().getYaw());
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".Pitch", (Object)p.getLocation().getPitch());
        cfg.set(String.valueOf(String.valueOf(String.valueOf(name))) + ".World", (Object)p.getWorld().getName());
        try {
            cfg.save(this.getFile(ymlname, path));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendPacket(final Player player, final Object packet) {
        try {
            final Object handle = player.getClass().getMethod("getHandle", (Class<?>[])new Class[0]).invoke(player, new Object[0]);
            final Object playerConnection = handle.getClass().getField("playerConnection").get(handle);
            playerConnection.getClass().getMethod("sendPacket", this.getNMSClass("Packet")).invoke(playerConnection, packet);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Class<?> getNMSClass(final String name) {
        final String version = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
        try {
            return Class.forName("net.minecraft.server." + version + "." + name);
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void sendTitle(final Player player, String title, String subtitle) {
        final int fadeIn = 1;
        final int stay = 1;
        final int fadeOut = 1;
        try {
            if (title != null) {
                title = ChatColor.translateAlternateColorCodes('&', title);
                title = title.replaceAll("%p%", player.getDisplayName());
                final Object enumTitle = this.getNMSClass("PacketPlayOutTitle").getDeclaredClasses()[0].getField("TITLE").get(null);
                final Object chatTitle = this.getNMSClass("IChatBaseComponent").getDeclaredClasses()[0].getMethod("a", String.class).invoke(null, "{\"text\":\"" + title + "\"}");
                final Constructor<?> titleConstructor = this.getNMSClass("PacketPlayOutTitle").getConstructor(this.getNMSClass("PacketPlayOutTitle").getDeclaredClasses()[0], this.getNMSClass("IChatBaseComponent"), Integer.TYPE, Integer.TYPE, Integer.TYPE);
                final Object titlePacket = titleConstructor.newInstance(enumTitle, chatTitle, 1, 1, 1);
                this.sendPacket(player, titlePacket);
            }
            if (subtitle != null) {
                subtitle = ChatColor.translateAlternateColorCodes('&', subtitle);
                subtitle = subtitle.replaceAll("%p%", player.getDisplayName());
                final Object enumSubtitle = this.getNMSClass("PacketPlayOutTitle").getDeclaredClasses()[0].getField("SUBTITLE").get(null);
                final Object chatSubtitle = this.getNMSClass("IChatBaseComponent").getDeclaredClasses()[0].getMethod("a", String.class).invoke(null, "{\"text\":\"" + subtitle + "\"}");
                final Constructor<?> subtitleConstructor = this.getNMSClass("PacketPlayOutTitle").getConstructor(this.getNMSClass("PacketPlayOutTitle").getDeclaredClasses()[0], this.getNMSClass("IChatBaseComponent"), Integer.TYPE, Integer.TYPE, Integer.TYPE);
                final Object subtitlePacket = subtitleConstructor.newInstance(enumSubtitle, chatSubtitle, 1, 1, 1);
                this.sendPacket(player, subtitlePacket);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ItemStack createHead(final String friend, final Object object, final String string) {
        return null;
    }
}
