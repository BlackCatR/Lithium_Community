package com.Reveas.Hub.Utils;

import org.bukkit.inventory.*;
import org.bukkit.*;
import java.util.*;
import com.mojang.authlib.*;
import org.bukkit.inventory.meta.*;
import java.lang.reflect.*;

public class HeadsAPI
{
    public static ItemStack getSkull(final String url) {
        final ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        if (url.isEmpty()) {
            return head;
        }
        final SkullMeta headMeta = (SkullMeta)head.getItemMeta();
        final GameProfile profile = new GameProfile(UUID.randomUUID(), (String)null);
        Field profileField = null;
        try {
            profileField = headMeta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(headMeta, profile);
        }
        catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException ex5) {
            final Exception ex4;
            final Exception ex2 = ex4;
            final Exception e1;
            final Exception ex3 = e1 = null;
            e1.printStackTrace();
        }
        head.setItemMeta((ItemMeta)headMeta);
        return head;
    }
}
