package com.Reveas.Hub.Utils;

import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.meta.*;

public class ItemUtil
{
    public static ItemStack makeItem(final Material m, final String name, final String lore) {
        final ItemStack item = new ItemStack(m);
        final ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore((List)Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }
    
    public static ItemStack makeSkull(final String owner, final String name, final String lore1, final String lore2) {
        final ItemStack item = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
        final SkullMeta skull = (SkullMeta)item.getItemMeta();
        skull.setOwner(owner);
        skull.setDisplayName(name);
        skull.setLore((List)Arrays.asList(lore1, lore2));
        item.setItemMeta((ItemMeta)skull);
        return item;
    }
    
    public static ItemStack giveAmount(final Material m, final int amount, final String name) {
        final ItemStack item = new ItemStack(m, amount);
        final ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }
    
    public static boolean containsDisplayName(final ItemStack currentItem) {
        return currentItem != null && currentItem.hasItemMeta() && currentItem.getItemMeta().hasDisplayName();
    }
    
    public static void removeItem(final Player p) {
        if (p.getItemInHand().getAmount() <= 64) {
            p.getItemInHand().setAmount(p.getItemInHand().getAmount() - 1);
        }
        if (p.getItemInHand().getAmount() == 1) {
            p.setItemInHand(new ItemStack(Material.AIR, 5));
        }
    }
    
    public static Firework spawnFireWork(final Location location, final boolean flicker, final boolean trail, final Color color) {
        final Firework fw = (Firework)location.getWorld().spawn(location, (Class)Firework.class);
        final FireworkMeta fwMeta = fw.getFireworkMeta();
        fwMeta.addEffects(new FireworkEffect[] { FireworkEffect.builder().flicker(flicker).trail(trail).withColor(color).build() });
        fwMeta.setPower(0);
        fw.setFireworkMeta(fwMeta);
        return fw;
    }
    
    public static String format(final String text) {
        return text.replaceAll("&", "�");
    }
}
