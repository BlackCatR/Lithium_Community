package com.Reveas.Hub.Utils;

import org.bukkit.*;
import org.bukkit.entity.*;

public class SoundUtil
{
    public static void playSound(final Location location, final Sounds sound, final float volume, final float speed) {
        location.getWorld().playSound(location, sound.bukkitSound(), volume, speed);
    }
    
    public static void playSound(final Location location, final Sounds sound, final float volume) {
        playSound(location, sound, volume, 1.0f);
    }
    
    public static void playSound(final Location location, final Sounds sound) {
        playSound(location, sound, 1.0f, 1.0f);
    }
    
    public static void playSound(final Player player, final Sounds sound, final float volume, final float speed) {
        player.playSound(player.getLocation(), sound.bukkitSound(), volume, speed);
    }
    
    public static void playSound(final Player player, final Sounds sound, final float volume) {
        playSound(player, sound, volume, 1.0f);
    }
    
    public static void playSound(final Player player, final Sounds sound) {
        playSound(player, sound, 1.0f, 1.0f);
    }
}
