package com.Reveas.Hub.Warp;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import com.Reveas.Hub.Utils.*;

public class cmd_setwarp implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String cmdLabel, final String[] args) {
        if (!(sender instanceof Player)) {
            final Player p = (Player)sender;
            p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "You do not have permission to execute this comand");
            return false;
        }
        if (args.length == 0) {
            final Player p = (Player)sender;
            if (p.hasPermission("Warp.*")) {
                p.sendMessage(String.valueOf(Main.prefix) + "�8�m--------------[�e�lRM�8�m]--------------");
                p.sendMessage(String.valueOf(Main.prefix) + "�e/warp �aname in setwarp in server");
                p.sendMessage(String.valueOf(Main.prefix) + "�e/setwarp �aselected the loaction on the world");
                p.sendMessage(String.valueOf(Main.prefix) + "�e/world <World_name> �aimport or loaded the world ");
                p.sendMessage(String.valueOf(Main.prefix) + "�8�m--------------�8�m--------------");
            }
        }
        if (args.length == 1) {
            final Player p = (Player)sender;
            if (p.hasPermission("Warp.*")) {
                ConfigManager.setWarp(p, args[0]);
                p.sendMessage(String.valueOf(String.valueOf(Main.prefix)) + "�7Done Warp �4" + args[0] + "�7!");
                return true;
            }
        }
        return false;
    }
}
