package com.Reveas.Hub.Warp;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.Reveas.Hub.Main.*;
import org.bukkit.*;
import com.Reveas.Hub.Utils.*;

public class cmd_warp implements CommandExecutor
{
    public boolean onCommand(final CommandSender sender, final Command cmd, final String cmdLabel, final String[] args) {
        if (sender instanceof Player) {
            final Player p = (Player)sender;
            if (cmd.getName().equalsIgnoreCase("warp")) {
                if (args.length == 0) {
                    p.sendMessage(String.valueOf(Main.prefix) + "�aUsage /warp <name>");
                }
                if (args.length == 1) {
                    if (ConfigManager.locationExists(args[0])) {
                        ConfigManager.warpPlayer(p, args[0]);
                        p.playSound(p.getLocation(), Sound.ENDERMAN_TELEPORT, 5.0f, 1.0f);
                        p.setGameMode(GameMode.ADVENTURE);
                        ParticleEffect.CRIT_MAGIC.display(0.5f, 0.5f, 0.5f, 0.3f, 20, p.getLocation().add(0.5, 0.5, 0.5), 500.0);
                        ParticleEffect.FLAME.display(0.5f, 0.5f, 0.5f, 0.3f, 20, p.getLocation().add(0.5, 0.5, 0.5), 500.0);
                        ParticleEffect.PORTAL.display(0.5f, 0.5f, 0.5f, 0.3f, 20, p.getLocation().add(0.5, 0.5, 0.5), 500.0);
                        ParticleEffect.FIREWORKS_SPARK.display(0.5f, 0.5f, 0.5f, 0.3f, 20, p.getLocation().add(0.5, 0.5, 0.5), 500.0);
                    }
                    else {
                        p.sendMessage(String.valueOf(Main.prefix) + "�cThis warp does not exist " + args[0]);
                    }
                }
            }
        }
        return false;
    }
}
